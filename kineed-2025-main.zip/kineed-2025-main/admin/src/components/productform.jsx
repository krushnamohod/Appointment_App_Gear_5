"use client";

import { useState, useEffect } from "react";
import { Trash2, Plus } from "lucide-react";
import Button from "./uic/button";
import ImageUploader from "./uic/ImageUploader";
import MultiImageUploader from "./uic/MultiImageUploader";
import InfoTooltip from "./uic/InfoTooltip";
import Dropdown from "../components/Dropdown";

const MEDIA_Download =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";
const MEDIA_Upload =
  "https://media.bizonance.in/api/v1/image/upload/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

export default function ProductForm({
  product,
  categories = [],
  brands = [],
  onSuccess,
}) {
  const [formData, setFormData] = useState({
    name: "",
    originalPrice: "",
    price: "",
    rating: "",
    category: "",
    sku: "",
    brand: "",
    description: "",
    features: [],
    specifications: [],
    images: [],
    mainImage: "",
  });

  const [logoFile, setLogoFile] = useState(null);
  const [imagesFiles, setImagesFiles] = useState([]);
  const [allImages, setAllImages] = useState(product?.images || []);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (product) {
      setFormData({
        ...product,
        features: product.features || [],
        specifications:
          product.specifications?.map((item) => {
            if (typeof item === "string") {
              const parts = item.split("/");
              return {
                label: parts[0]?.trim() || "",
                value: parts[1]?.trim() || "",
              };
            }
            return item; // if already object
          }) || [],
      });
      setAllImages(product.images || []);
      setLogoFile(null);
    } else {
      setFormData({
        name: "",
        originalPrice: "",
        price: "",
        rating: "",
        category: "",
        sku: "",
        brand: "",
        description: "",
        features: [],
        specifications: [],
        images: [],
        mainImage: "",
      });
      setAllImages([]);
      setLogoFile(null);
    }
  }, [product]);

  const handleChange = (key, value) =>
    setFormData((prev) => ({ ...prev, [key]: value }));

  const handleFeatureChange = (index, value) => {
    const updated = [...formData.features];
    updated[index] = value;
    handleChange("features", updated);
  };
  const addFeature = () => handleChange("features", [...formData.features, ""]);
  const removeFeature = (index) =>
    handleChange(
      "features",
      formData.features.filter((_, i) => i !== index)
    );

  const handleSpecificationChange = (index, field, newValue) => {
    const updated = [...formData.specifications];
    updated[index][field] = newValue;
    setFormData({ ...formData, specifications: updated });
  };

  const addSpecification = () => {
    setFormData({
      ...formData,
      specifications: [...formData.specifications, { label: "", value: "" }],
    });
  };

  const removeSpecification = (index) => {
    const updated = formData.specifications.filter((_, i) => i !== index);
    setFormData({ ...formData, specifications: updated });
  };

  const handleImagesChange = (updatedImages) => {
    const limited = updatedImages.slice(0, 4);
    setAllImages(limited);

    const newFiles = limited.filter((img) => img instanceof File);
    setImagesFiles(newFiles);
  };

  const uploadImage = async (file) => {
    const fd = new FormData();
    fd.append("file", file);

    const res = await fetch(MEDIA_Upload, { method: "POST", body: fd });

    if (!res.ok) throw new Error("Image upload failed");

    const data = await res.json();
    const filename = data.uploadedImages[0].filename;

    return `${MEDIA_Download}/${filename}`;
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Unauthorized: No token found.");

      let mainImageUrl = formData.mainImage;
      if (logoFile) mainImageUrl = await uploadImage(logoFile);

      const uploadedImages = [];
      for (const file of imagesFiles) {
        const url = await uploadImage(file);
        uploadedImages.push(url);
      }

      const finalImages = [
        ...allImages.filter((img) => typeof img === "string"),
        ...uploadedImages,
      ];

      const finalSpecifications = formData.specifications.map(
        (spec) => `${spec.label} / ${spec.value}`
      );

      const payload = {
        ...formData,
        specifications: finalSpecifications, // << IMPORTANT
        mainImage: mainImageUrl,
        images: finalImages,
        originalPrice: parseFloat(formData.originalPrice) || 0,
        price: parseFloat(formData.price) || 0,
        rating: formData.rating ? parseFloat(formData.rating) : null,
      };

      const url = product
        ? `https://api.kineed.in/api/products/${product.id}`
        : "https://api.kineed.in/api/products";
      const method = product ? "PATCH" : "POST";

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to save product");

      alert("Product saved successfully!");
      onSuccess?.();
    } catch (err) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="w-full h-full overflow-hidden">
      {/* FULL SCROLLABLE INNER WRAPPER */}
      <div className="w-full h-full overflow-y-auto px-4 pb-20">
        {/* Images Section */}
        <div className="flex flex-col md:flex-row gap-8 mb-6">
          <div className="">
            <div className="flex gap-2 mb-2">
              <h3 className="text-sm font-medium mb-1">Main Product Image</h3>
              <InfoTooltip
                points={[
                  "Upload a high-quality, square image (1:1 aspect ratio).",
                  "Preferred formats: JPEG, PNG, WEBP.",
                  "Image size should be less than 5 MB.",
                  "Recommended minimum resolution: 800×800 pixels.",
                  "Avoid blurry or stretched images.",
                ]}
              />
            </div>

            <ImageUploader
              image={
                logoFile
                  ? URL.createObjectURL(logoFile)
                  : formData.mainImage || null
              }
              onImageChange={(file) => setLogoFile(file)}
            />
          </div>

          <div className="">
            <div className="flex gap-2 mb-2">
              <h3 className="text-sm font-medium mb-1">Additional Images</h3>
              <InfoTooltip
                points={[
                  "You can upload up to 4 additional product images.",
                  "Use square images (1:1 aspect ratio) for best display.",
                  "Preferred formats: JPEG, PNG, WEBP.",
                  "Each image should be less than 5 MB.",
                  "Show the product from different angles for better clarity.",
                ]}
              />
            </div>

            <MultiImageUploader
              images={allImages}
              onImagesChange={handleImagesChange}
              maxImages={4}
            />
          </div>
        </div>

        {/* Basic Info */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1">
              Product Name
            </label>
            <input
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className="w-full border p-2 rounded-md"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">SKU</label>
            <input
              value={formData.sku}
              onChange={(e) => handleChange("sku", e.target.value)}
              className="w-full border p-2 rounded-md"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">MRP</label>
            <input
              type="number"
              value={formData.originalPrice}
              onChange={(e) => handleChange("originalPrice", e.target.value)}
              className="w-full border p-2 rounded-md"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Discounted Price
            </label>
            <input
              type="number"
              value={formData.price}
              onChange={(e) => handleChange("price", e.target.value)}
              className="w-full border p-2 rounded-md"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Rating</label>
            <input
              type="number"
              step="0.1"
              value={formData.rating}
              onChange={(e) => handleChange("rating", e.target.value)}
              className="w-full border p-2 rounded-md"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Category</label>
            <Dropdown
              options={categories}
              value={formData.category}
              onChange={(val) => handleChange("category", val)}
              label="Select category"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Brand</label>
            <Dropdown
              options={brands}
              value={formData.brand}
              onChange={(val) => handleChange("brand", val)}
              label="Select brand"
            />
          </div>
        </div>

        {/* Description */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-1">Description</label>
          <textarea
            rows={8}
            value={formData.description}
            onChange={(e) => handleChange("description", e.target.value)}
            className="w-full border p-2 rounded-md scrollbar-custom"
          />
        </div>

        {/* Features */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium">Highlights</h3>
            <Button text="Add" icon={<Plus size={16} />} onClick={addFeature} />
          </div>

          <div className="space-y-2">
            {formData.features.map((f, i) => (
              <div key={i} className="flex items-center gap-2">
                <input
                  value={f}
                  onChange={(e) => handleFeatureChange(i, e.target.value)}
                  className="flex-1 border p-2 rounded-md"
                  placeholder={`Highlight ${i + 1}`}
                />
                <button
                  onClick={() => removeFeature(i)}
                  className="p-2 text-red-600"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Specifications */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium">Product Details</h3>
            <Button
              text="Add"
              icon={<Plus size={16} />}
              onClick={addSpecification}
            />
          </div>

          <div className="space-y-2">
            {formData.specifications.map((spec, i) => (
              <div key={i} className="flex items-center gap-2">
                {/* Label Field */}
                <input
                  value={spec.label}
                  onChange={(e) =>
                    handleSpecificationChange(i, "label", e.target.value)
                  }
                  className="flex-1 border p-2 rounded-md"
                  placeholder="Label"
                />

                {/* Value Field */}
                <input
                  value={spec.value}
                  onChange={(e) =>
                    handleSpecificationChange(i, "value", e.target.value)
                  }
                  className="flex-1 border p-2 rounded-md"
                  placeholder="Value "
                />

                <button
                  onClick={() => removeSpecification(i)}
                  className="p-2 text-red-600"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Save */}
        <Button
          text={saving ? "Saving..." : "Save Product"}
          onClick={handleSave}
          variant="blue"
          className="w-full mb-10"
          disabled={saving}
        />
      </div>
    </div>
  );
}
