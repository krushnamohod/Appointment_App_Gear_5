import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";

import logo from "../assets/ghrutikalogo.jpg";
import bizologo from "../assets/bizonance_logo.png";

const Login = () => {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await fetch(
        "https://api.kineed.in/api/auth/login",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: userId, password }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Login failed");
        setIsLoading(false);
        return;
      }

      localStorage.setItem("token", data.token);
      localStorage.setItem("admin", JSON.stringify(data.admin));

      navigate("/main");
    } catch (err) {
      console.error("Login error:", err);
      setError("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="flex relative flex-col items-center justify-center min-h-screen bg-amber-50 px-4 py-8 sm:px-6 lg:px-8 overflow-hidden">
      <div className="bg-[#FDEAD4] h-[400px] w-[400px] rounded-full absolute -top-[250px] -right-40  "></div>
      <div className="bg-[#FEF5D8] h-[400px] w-[400px] rounded-full absolute top-[250px] right-40"></div>
      <div className="bg-[#d8deec71] h-[150px] w-[150px] rounded-full absolute top-[200px] right-[190px]"></div>

      <div className="absolute top-[100px] left-[130px]">
        <svg
          width="7006" // doubled from 3503
          height="151"
          viewBox="0 0 7006 151" // doubled width in viewBox
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M0 0H410.34L706 72L410.34 151H0V0Z" fill="#FEE9DA" />
        </svg>
      </div>

      <div className="bg-white overflow-hidden relative w-full max-w-5xl rounded p-6 sm:p-8 md:p-10">
        {/* Top logo */}
        <img
          src={bizologo || "/placeholder.svg"}
          alt="Biz Logo"
          className="h-12 w-12 sm:h-14 sm:w-14 mt-1 object-contain"
        />

        {/* Grid Container */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-10 sm:mt-12">
          {/* Left Text Section */}
          <div className="flex flex-col  md:text-left px-2 sm:px-4">
            <p className="text-2xl sm:text-3xl font-semibold text-gray-600">
              Sign in to Dashboard
            </p>
            <p className="text-md sm:text-lg text-gray-600 mt-2">
              Use your Login Credentials
            </p>
          </div>

          {/* Right Login Form */}
          <div className="flex flex-col items-center mt-6 md:mt-0">
            <form
              onSubmit={handleLogin}
              className="w-full max-w-sm sm:max-w-md md:max-w-lg"
            >
              {error && <p className="text-red-500 text-sm mb-4">{error}</p>}

              {/* Username Field */}
              <div className="mb-4 relative">
                <label
                  htmlFor="userId"
                  className="absolute -top-2.5 left-2 bg-white px-1 block text-sm font-semibold text-gray-700"
                >
                  Username
                </label>
                <input
                  id="userId"
                  type="text"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="Enter Username"
                  className="w-full px-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              {/* Password Field */}
              <div className="mb-6 relative">
                <label
                  htmlFor="password"
                  className="absolute -top-2.5 left-2 bg-white px-1 block text-sm font-semibold text-gray-700 z-10"
                >
                  Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full px-3 py-3 pr-10 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={toggleShowPassword}
                    className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-400/30 hover:bg-blue-400/40 text-blue-900 font-medium py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 transition"
              >
                {isLoading ? "Logging in..." : "Login"}
              </button>
            </form>

            {/* Bottom Gradient Bar */}
            <div className="absolute bottom-0 left-0 w-full flex h-[6px]">
              <div className="w-1/3 bg-gradient-to-r from-yellow-300 to-orange-400"></div>
              <div className="w-1/3 bg-blue-800"></div>
              <div className="w-1/3 bg-red-600"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
