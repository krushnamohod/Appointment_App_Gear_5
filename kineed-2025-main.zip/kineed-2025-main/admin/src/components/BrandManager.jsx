"use client";

import { useState, useEffect } from "react";
import { Pencil, Trash2, LoaderCircle, GripVertical } from "lucide-react";
import ImageUploader from "./uic/ImageUploader";
import Button from "./uic/button";
import ConfirmModal from "./uic/confirmdel";
import ActionButtons from "./uic/ActionButtons";

import {
  DndContext,
  PointerSensor,
  TouchSensor,
  KeyboardSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";

import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from "@dnd-kit/sortable";

import { CSS } from "@dnd-kit/utilities";

const MEDIA_UPLOAD =
  "https://media.bizonance.in/api/v1/image/upload/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";
const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

const API_BASE = "https://api.kineed.in/api/products/brands";

/* BRAND ITEM - FIXED CARD - INLINE EDIT */
function SortableBrandItem({
  brand,
  editing,
  startEdit,
  cancelEdit,
  updateEditing,
  saveEdit,
  openDelete,
}) {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: brand.id });

  const isEditing = editing?.id === brand.id;

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white p-3 border rounded-xl shadow-sm h-[90px] flex items-center gap-3 overflow-hidden"
    >
      {/* Drag Handle (like Category) */}
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab text-gray-400"
      >
        <GripVertical className="w-5 h-5" />
      </button>

      {/* IMAGE UPLOADER INLINE (same as Category) */}
      <ImageUploader
        image={isEditing ? editing.preview || editing.image : brand.image}
        onImageChange={(file) =>
          updateEditing({
            ...editing,
            imageFile: file,
            preview: file ? URL.createObjectURL(file) : editing.image,
          })
        }
        className="!w-14 !h-14 border-none"
      />

      {/* TEXT + BUTTONS */}
      <div className="flex-1 space-y-2">
        {!isEditing ? (
          <p className="font-medium text-sm truncate">{brand.name}</p>
        ) : (
          <input
            className="w-full border p-1 text-sm rounded-md"
            value={editing.name}
            onChange={(e) =>
              updateEditing({ ...editing, name: e.target.value })
            }
          />
        )}

        {/* ACTION BUTTONS */}
        {!isEditing ? (
          <div className="flex gap-2">
            <button
              className="text-blue-600 bg-blue-100 text-xs px-3 py-1 rounded-md"
              onClick={() =>
                startEdit({
                  id: brand.id,
                  name: brand.name,
                  image: brand.image,
                })
              }
            >
              <Pencil className="h-3 w-3" />
            </button>
            <button
              className="text-red-600 bg-red-100 text-xs px-3 py-2 rounded-md"
              onClick={() => openDelete(brand.id)}
            >
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <button
              className="text-blue-700 bg-blue-100 text-xs px-3 py-1 rounded-md"
              onClick={saveEdit}
            >
              Save
            </button>
            <button
              className="text-gray-600 bg-gray-200 text-xs px-3 py-1 rounded-md"
              onClick={cancelEdit}
            >
              Cancel
            </button>
            
          </div>
        )}
      </div>
    </div>
  );
}

/* MAIN BRAND MANAGER - SAME PATTERN AS CATEGORY MANAGER */
export default function BrandManager() {
  const [brands, setBrands] = useState([]);
  const [editState, setEditState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "",
    imageFile: null,
    preview: null,
  });

  const [deleteModal, setDeleteModal] = useState({
    open: false,
    id: null,
  });

  const token =
    typeof window !== "undefined" ? localStorage.getItem("token") : null;

  const apiHeaders = {
    Authorization: token ? `Bearer ${token}` : "",
    "Content-Type": "application/json",
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(TouchSensor),
    useSensor(KeyboardSensor)
  );

  /* API: upload image */
  const uploadImage = async (file) => {
    if (!file) return "";
    const fd = new FormData();
    fd.append("file", file);

    const res = await fetch(MEDIA_UPLOAD, { method: "POST", body: fd });
    const data = await res.json();
    const filename = data?.uploadedImages?.[0]?.filename;
    return filename ? `${MEDIA_DOWNLOAD}/${filename}` : "";
  };

  /* API: fetch brands */
  const fetchBrands = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/all`, { headers: apiHeaders });
      const data = await res.json();
      const list = data.data?.brands || [];
      // Keep sorted by order if backend provides
      list.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      setBrands(list);
    } catch {
      setError("Failed to fetch brands.");
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchBrands();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ADD BRAND */
  const handleAdd = async () => {
    if (!form.name.trim()) return setError("Brand name required");
    setSaving(true);

    try {
      const imageUrl = form.imageFile ? await uploadImage(form.imageFile) : "";

      await fetch(API_BASE, {
        method: "POST",
        headers: apiHeaders,
        body: JSON.stringify({
          name: form.name.trim(),
          image: imageUrl,
        }),
      });

      setForm({ name: "", imageFile: null, preview: null });
      fetchBrands();
    } catch {
      setError("Failed to add brand.");
    }
    setSaving(false);
  };

  /* INLINE EDIT SAVE */
  const saveEdit = async () => {
    if (!editState) return;
    setSaving(true);

    try {
      const imageUrl = editState.imageFile
        ? await uploadImage(editState.imageFile)
        : editState.image;

      await fetch(`${API_BASE}/${editState.id}`, {
        method: "PATCH",
        headers: apiHeaders,
        body: JSON.stringify({
          name: editState.name,
          image: imageUrl,
        }),
      });

      setEditState(null);
      fetchBrands();
    } catch {
      setError("Failed to update brand.");
    }
    setSaving(false);
  };

  const cancelEdit = () => setEditState(null);

  /* DELETE */
  const handleDelete = async (id) => {
    await fetch(`${API_BASE}/${id}`, {
      method: "DELETE",
      headers: { Authorization: token ? `Bearer ${token}` : "" },
    });
    fetchBrands();
  };

  /* REORDER */
  const handleDragEnd = async ({ active, over }) => {
    if (!over || active.id === over.id) return;

    const oldIndex = brands.findIndex((b) => b.id === active.id);
    const newIndex = brands.findIndex((b) => b.id === over.id);

    const reordered = arrayMove(brands, oldIndex, newIndex);
    setBrands(reordered);

    await fetch(`${API_BASE}/reorder`, {
      method: "POST",
      headers: apiHeaders,
      body: JSON.stringify({
        list: reordered.map((b, i) => ({ id: b.id, order: i })),
      }),
    });
  };

  return (
    <div className="w-full p-4">
      {error && (
        <div className="text-red-600 p-2 bg-red-50 rounded mb-3">
          {error}
        </div>
      )}

      {/* ADD BRAND (same UI as Add Category) */}
      <div className="mb-6 flex gap-4 items-center">
        <ImageUploader
          image={form.preview}
          onImageChange={(file) =>
            setForm({
              ...form,
              imageFile: file,
              preview: file ? URL.createObjectURL(file) : null,
            })
          }
          className="w-16 h-16"
        />

        <input
          placeholder="Brand Name"
          className="border p-2 rounded w-60 text-sm"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />

        <Button
          variant="blue"
          text={saving ? "Saving..." : "Add"}
          onClick={handleAdd}
          disabled={saving}
        />
      </div>

      {/* LIST */}
      <h3 className="font-semibold text-md mb-3">
        Existing Brands ({brands.length})
      </h3>

      {loading ? (
        <div className="flex items-center gap-2">
          <LoaderCircle className="animate-spin" /> Loading...
        </div>
      ) : (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={brands.map((x) => x.id)}
            strategy={verticalListSortingStrategy}
          >
            <div className="grid grid-cols-3 gap-4">
              {brands.map((b) => (
                <SortableBrandItem
                  key={b.id}
                  brand={b}
                  editing={editState}
                  startEdit={(data) =>
                    setEditState({
                      ...data,
                      imageFile: null,
                      preview: null,
                    })
                  }
                  cancelEdit={cancelEdit}
                  updateEditing={setEditState}
                  saveEdit={saveEdit}
                  openDelete={(id) =>
                    setDeleteModal({ open: true, id })
                  }
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}

      {/* DELETE MODAL */}
      <ConfirmModal
        open={deleteModal.open}
        title="Delete Brand?"
        message="The brand will be permanently removed."
        onConfirm={() => {
          handleDelete(deleteModal.id);
          setDeleteModal({ open: false, id: null });
        }}
        onCancel={() => setDeleteModal({ open: false, id: null })}
      />
    </div>
  );
}
