"use client";

import { useEffect, useState } from "react";
import { Mail, Phone, Calendar, ChevronDown, ChevronUp } from "lucide-react";
import Button from "./uic/button";
import SectionHeader from "./uic/SectionHeader";
import FormattedDate from "./uic/FormattedDate";

export default function ContactFormAdmin() {
  const [contacts, setContacts] = useState([]);
  const [expandedId, setExpandedId] = useState(null);
  const [loading, setLoading] = useState(true);

  const API_URL = "https://api.kineed.in/api/contactfrom";

  useEffect(() => {
    fetchContacts();
  }, []);

  // -----------------------
  // FETCH CONTACT MESSAGES
  // -----------------------
  const fetchContacts = async () => {
    try {
      setLoading(true);
      const res = await fetch(API_URL);
      const data = await res.json();

      if (res.ok) {
        setContacts(data);
      }
    } catch (err) {
      console.error("Failed to fetch contacts", err);
    } finally {
      setLoading(false);
    }
  };

  // -----------------------
  // TOGGLE EXPAND
  // -----------------------
  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  // -----------------------
  // WHATSAPP REPLY
  // -----------------------
  const sendWhatsAppReply = (contact) => {
    const phone = contact.mobile.replace(/[^0-9]/g, "");

    const message = encodeURIComponent(
      `Hello ${contact.name},\n\nRegarding your message:\n"${contact.message}"\n\nHow may I assist you further?`
    );

    window.open(`https://wa.me/${phone}?text=${message}`, "_blank");
  };

  // -----------------------
  // UPDATE STATUS
  // -----------------------
  const updateStatus = async (id, status) => {
    try {
      const res = await fetch(`${API_URL}/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (res.ok) await fetchContacts();
    } catch (err) {
      console.error("Failed to update status", err);
    }
  };

  if (loading) {
    return (
      <div className="p-7 text-center text-gray-500">
        Loading contact messages...
      </div>
    );
  }

  return (
    <div className="space-y-6 p-7">
      <SectionHeader
        title="Contact Messages"
        subtitle="Manage customer contact submissions."
      />

      {contacts.length === 0 && !loading && (
        <div className="p-10 text-center text-gray-500 text-sm border-gray-200 rounded-lg bg-gray-50">
          No contacts messages found.
        </div>
      )}

      <div className="grid gap-4">
        {contacts.map((contact) => {
          const isExpanded = expandedId === contact.id;

          return (
            <div
              key={contact.id}
              onClick={() => toggleExpand(contact.id)}
              className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-gray-900 text-md">
                        {contact.name}
                      </h3>

                      <span
                        className={`px-3 py-1 text-xs font-medium rounded-full ${
                          contact.status === "UNREAD"
                            ? "bg-blue-100 text-blue-800"
                            : contact.status === "IN_PROGRESS"
                            ? "bg-yellow-100 text-yellow-800"
                            : contact.status === "RESOLVED"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-200 text-gray-700"
                        }`}
                      >
                        {contact.status.replace("_", " ")}
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-4 text-xs text-gray-600">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" /> {contact.email}
                      </div>

                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4" /> {contact.mobile}
                      </div>

                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <FormattedDate date={contact.createdAt} />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleExpand(contact.id)}
                    className="ml-4 p-2 hover:bg-gray-100 rounded-lg transition"
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-gray-600" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-600" />
                    )}
                  </button>
                </div>

                {isExpanded && (
                  <div className="mt-4 pt-4 text-sm border-t border-gray-200">
                    <h4 className="font-medium text-gray-900 mb-2">Message:</h4>
                    <p className="text-gray-700 mb-4">{contact.message}</p>

                    <div className="flex gap-2 flex-wrap">
                      <Button
                        text="Reply on WhatsApp"
                        variant="blue"
                        onClick={() => sendWhatsAppReply(contact)}
                      />

                      <Button
                        text="Mark In-Progress"
                        variant="yellow"
                        onClick={() => updateStatus(contact.id, "IN_PROGRESS")}
                      />

                      <Button
                        text="Mark Resolved"
                        variant="green"
                        onClick={() => updateStatus(contact.id, "RESOLVED")}
                      />

                      <Button
                        text="Mark Closed"
                        variant="gray"
                        onClick={() => updateStatus(contact.id, "CLOSED")}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
