"use client";

import { useEffect, useState } from "react";
import {
  PlusCircle,
  Pencil,
  Trash2,
  LoaderCircle,
  X,
  GripVertical,
} from "lucide-react";

import ConfirmModal from "./uic/confirmdel";
import Button from "./uic/button";
import SectionHeader from "./uic/SectionHeader";
import ImageUploader from "./uic/ImageUploader";
import Alert from "./uic/Alert";
import { motion, AnimatePresence } from "framer-motion";

/* DND KIT IMPORTS */
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  rectSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

const MEDIA_UPLOAD =
  "https://media.bizonance.in/api/v1/image/upload/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

/* ----------------------------------------------
   SORTABLE CARD COMPONENT
---------------------------------------------- */
function SortableBlogCard({ blog, onEdit, onDelete }) {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: blog.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white rounded-lg border p-5 shadow-sm hover:shadow-md transition flex flex-col relative"
    >
      {/* DRAG HANDLE */}
      <div
        {...attributes}
        {...listeners}
        className="absolute top-3 right-3 cursor-grab active:cursor-grabbing"
      >
        <GripVertical className="text-gray-400" />
      </div>

      <img
        src={
          blog.image
            ? `${MEDIA_DOWNLOAD}/${blog.image}`
            : "/no-image-placeholder.png"
        }
        className="w-full h-40 object-cover rounded-lg"
      />

      <h3 className="font-semibold mt-4 line-clamp-1">{blog.title}</h3>

      <p className="text-sm text-gray-600 mt-2 line-clamp-3">
        {blog.description}
      </p>

      <p className="text-xs mt-2 text-gray-500">By {blog.author}</p>

      <div className="flex gap-3 mt-auto pt-4">
        <button
          onClick={onEdit}
          className="flex items-center gap-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 flex-1 justify-center"
        >
          <Pencil className="w-4 h-4" />
          Edit
        </button>

        <button
          onClick={onDelete}
          className="flex items-center gap-2 px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

/* ----------------------------------------------
   MAIN COMPONENT
---------------------------------------------- */
export default function BlogsManager() {
  const API_BASE_URL = "https://api.kineed.in/api/blogs";

  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);

  // SIDEBAR PANEL
  const [panelOpen, setPanelOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    title: "",
    author: "",
    description: "",
  });

  const [imagePreview, setImagePreview] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [initialImage, setInitialImage] = useState(null);

  // DELETE MODAL
  const [deleteId, setDeleteId] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const [alert, setAlert] = useState({
    show: false,
    type: "",
    message: "",
  });

  /* DND SENSORS */
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 5 },
    })
  );

  /* ----------------------------------------------
     Fetch Blogs
  ---------------------------------------------- */
  const fetchBlogs = async () => {
    try {
      setLoading(true);
      const res = await fetch(API_BASE_URL);
      const data = await res.json();
      setBlogs(data);
    } catch (err) {
      console.error("Error fetching blogs:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  /* ----------------------------------------------
     Open Create Panel
  ---------------------------------------------- */
  const openCreatePanel = () => {
    setEditingId(null);
    setForm({ title: "", author: "", description: "" });
    setImagePreview(null);
    setImageFile(null);
    setInitialImage(null);
    setPanelOpen(true);
  };

  /* ----------------------------------------------
     Open Edit Panel
  ---------------------------------------------- */
  const openEditPanel = async (id) => {
    setEditingId(id);

    const res = await fetch(`${API_BASE_URL}/${id}`);
    const blog = await res.json();

    setForm({
      title: blog.title,
      author: blog.author,
      description: blog.description,
    });

    setInitialImage(blog.image);
    setImagePreview(blog.image ? `${MEDIA_DOWNLOAD}/${blog.image}` : null);
    setImageFile(null);

    setPanelOpen(true);
  };

  /* ----------------------------------------------
     Upload Image
  ---------------------------------------------- */
  const uploadToMedia = async (file) => {
    const fd = new FormData();
    fd.append("file", file);

    const res = await fetch(MEDIA_UPLOAD, { method: "POST", body: fd });
    const data = await res.json();
    return data?.uploadedImages?.[0]?.filename || null;
  };

  /* ----------------------------------------------
     Save Blog
  ---------------------------------------------- */
  const saveBlog = async () => {
    try {
      let finalImage = initialImage;

      if (imageFile) {
        finalImage = await uploadToMedia(imageFile);
      }

      const payload = JSON.stringify({
        ...form,
        image: finalImage,
      });

      const method = editingId ? "PUT" : "POST";
      const url = editingId ? `${API_BASE_URL}/${editingId}` : API_BASE_URL;

      await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: payload,
      });

      setAlert({
        show: true,
        type: "success",
        message: editingId ? "Blog Updated" : "Blog Created",
      });

      setPanelOpen(false);
      fetchBlogs();
    } catch (err) {
      console.error("Error saving blog:", err);
    }
  };

  /* ----------------------------------------------
     Delete Blog
  ---------------------------------------------- */
  const handleDeleteConfirm = async () => {
    try {
      await fetch(`${API_BASE_URL}/${deleteId}`, {
        method: "DELETE",
      });

      setBlogs((prev) => prev.filter((b) => b.id !== deleteId));
    } catch (err) {
      console.error("Error deleting blog:", err);
    } finally {
      setIsDeleteModalOpen(false);
      setDeleteId(null);
    }
  };

  /* ----------------------------------------------
     DND MOVE HANDLER
  ---------------------------------------------- */
  const handleDragEnd = async (event) => {
    const { active, over } = event;

    if (!over || active.id === over.id) return;

    const oldIndex = blogs.findIndex((b) => b.id === active.id);
    const newIndex = blogs.findIndex((b) => b.id === over.id);

    const newOrder = arrayMove(blogs, oldIndex, newIndex);

    // update local UI instantly
    setBlogs(newOrder);

    // prepare payload
    const payload = newOrder.map((item, index) => ({
      id: item.id,
      order: index + 1,
    }));

    // SEND TO BACKEND
    try {
      await fetch(`${API_BASE_URL}/order`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: payload }),
      });
    } catch (err) {
      console.error("Order update failed:", err);
    }
  };

  /* ----------------------------------------------
     Loading
  ---------------------------------------------- */
  if (loading)
    return (
      <div className="flex h-screen flex-col items-center justify-center py-10">
        <LoaderCircle className="animate-spin" />
        <p className="text-gray-700 font-medium text-center mt-3">
          Loading blogs, please wait...
        </p>
      </div>
    );

  return (
    <>
      {/* DELETE MODAL */}
      <ConfirmModal
        open={isDeleteModalOpen}
        title="Delete Blog?"
        message="This action cannot be undone."
        onConfirm={handleDeleteConfirm}
        onCancel={() => setIsDeleteModalOpen(false)}
      />

      {/* SIDEBAR PANEL */}
      <AnimatePresence>
        {panelOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black z-40"
              onClick={() => setPanelOpen(false)}
            />

            {/* Panel */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{
                type: "spring",
                stiffness: 240,
                damping: 30,
              }}
              className="fixed top-0 right-0 w-full max-w-3xl h-full bg-white z-50 shadow-xl overflow-y-auto p-6"
            >
              {/* Header */}
              <div className="flex justify-between items-center border-b pb-3 mb-4">
                <h2 className="text-xl font-semibold">
                  {editingId ? "Edit Blog" : "Create Blog"}
                </h2>

                <button
                  className="p-2 hover:bg-gray-100 rounded-full"
                  onClick={() => setPanelOpen(false)}
                >
                  <X size={20} />
                </button>
              </div>

              {/* Image + Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <ImageUploader
                  image={imagePreview}
                  onImageChange={(file) => {
                    setImagePreview(file ? URL.createObjectURL(file) : null);
                    setImageFile(file);
                  }}
                />

                <div className="flex flex-col gap-4">
                  <input
                    className="border p-2 rounded w-full"
                    placeholder="Blog Title"
                    value={form.title}
                    onChange={(e) =>
                      setForm({ ...form, title: e.target.value })
                    }
                  />

                  <input
                    className="border p-2 rounded w-full"
                    placeholder="Author Name"
                    value={form.author}
                    onChange={(e) =>
                      setForm({ ...form, author: e.target.value })
                    }
                  />
                </div>
              </div>

              {/* Description */}
              <div className="mt-4">
                <textarea
                  className="border p-2 rounded w-full min-h-[160px]"
                  placeholder="Short Description (max 400 characters)"
                  maxLength={400}
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                />
                <p className="text-xs text-gray-500 text-right">
                  {form.description.length} / 400
                </p>
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <Button
                  text="Cancel"
                  variant="outline"
                  onClick={() => setPanelOpen(false)}
                />
                <Button text="Save" variant="blue" onClick={saveBlog} />
              </div>

              <Alert
                show={alert.show}
                message={alert.message}
                type={alert.type}
                onClose={() => setAlert({ ...alert, show: false })}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* MAIN PAGE */}
      <div className="space-y-6 p-7">
        {/* Header */}
        <div className="flex items-center justify-between">
          <SectionHeader
            title="Blogs"
            subtitle="Manage your blog posts and website content"
          />
          <Button text="Add Blog" onClick={openCreatePanel} variant="blue" />
        </div>

        {/* DRAG-AND-DROP GRID */}
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={blogs.map((b) => b.id)}
            strategy={rectSortingStrategy}
          >
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {blogs.map((blog) => (
                <SortableBlogCard
                  key={blog.id}
                  blog={blog}
                  onEdit={() => openEditPanel(blog.id)}
                  onDelete={() => {
                    setDeleteId(blog.id);
                    setIsDeleteModalOpen(true);
                  }}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      </div>
    </>
  );
}
