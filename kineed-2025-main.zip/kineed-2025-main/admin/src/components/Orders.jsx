"use client";

import { useState, useEffect } from "react";
import { Search, Filter, X, Package, Eye, CheckCircle, Clock, AlertCircle, Truck, Ban, RefreshCw, Loader2 } from "lucide-react";
import SectionHeader from "./uic/SectionHeader";
import Dropdown from "./Dropdown";
import axios from "axios";

export default function Orders() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const API_BASE_URL = "https://api.kineed.in/api";

  // Format currency
  const formatINR = (n) => {
    try {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      }).format(n);
    } catch {
      return `₹${n}`;
    }
  };

  // Format date
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateString;
    }
  };

  // Status options
  const statusOptions = [
    { value: "all", label: "All Status" },
    { value: "PENDING", label: "Pending" },
    { value: "PROCESSING", label: "Processing" },
    { value: "COMPLETED", label: "Completed" },
    { value: "CANCELLED", label: "Cancelled" }
  ];

  // Payment status options
  const paymentStatusOptions = [
    { value: "all", label: "All Payments" },
    { value: "PAYMENT_PENDING", label: "Payment Pending" },
    { value: "PAYMENT_INITIATED", label: "Payment Initiated" },
    { value: "PAYMENT_SUCCESS", label: "Payment Success" },
    { value: "PAYMENT_FAILED", label: "Payment Failed" },
    { value: "PAYMENT_REFUNDED", label: "Refunded" }
  ];

  // Fetch orders from API
  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/checkout/orders`, {
        params: {
          search: searchTerm || undefined,
          status: statusFilter !== "all" ? statusFilter : undefined,
          paymentStatus: paymentFilter !== "all" ? paymentFilter : undefined,
          page: 1,
          limit: 50
        }
      });

      if (response.data.success) {
        setOrders(response.data.data.orders);
      }
    } catch (error) {
      console.error("Error fetching orders:", error);
    } finally {
      setLoading(false);
    }
  };

  // Update order status
  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      setUpdatingStatus(true);
      const response = await axios.patch(
        `${API_BASE_URL}/checkout/order/${orderId}/status`,
        { status: newStatus }
      );

      if (response.data.success) {
        // Update local state
        setOrders(prevOrders =>
          prevOrders.map(order =>
            order.orderId === orderId
              ? { ...order, status: newStatus }
              : order
          )
        );

        // Update selected order if open
        if (selectedOrder && selectedOrder.orderId === orderId) {
          setSelectedOrder(prev => ({ ...prev, status: newStatus }));
        }
      }
    } catch (error) {
      console.error("Error updating order status:", error);
    } finally {
      setUpdatingStatus(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchOrders();
  }, []);

  // Fetch when filters change
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      fetchOrders();
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, statusFilter, paymentFilter]);

  // Filter orders locally (as backup)
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.orderId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.transactionId?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" ||
      order.status === statusFilter;

    const matchesPayment =
      paymentFilter === "all" ||
      order.paymentStatus === paymentFilter;

    return matchesSearch && matchesStatus && matchesPayment;
  });

  const openDetails = (order) => {
    setSelectedOrder(order);
    setIsDetailsOpen(true);
  };

  const closeDetails = () => {
    setSelectedOrder(null);
    setIsDetailsOpen(false);
  };

  // Get status badge color
  const getStatusBadge = (status) => {
    switch (status) {
      case 'COMPLETED':
        return { bg: 'bg-green-100', text: 'text-green-800', icon: CheckCircle };
      case 'PROCESSING':
        return { bg: 'bg-blue-100', text: 'text-blue-800', icon: Truck };
      case 'PENDING':
        return { bg: 'bg-yellow-100', text: 'text-yellow-800', icon: Clock };
      case 'CANCELLED':
        return { bg: 'bg-red-100', text: 'text-red-800', icon: Ban };
      default:
        return { bg: 'bg-gray-100', text: 'text-gray-800', icon: AlertCircle };
    }
  };

  // Get payment status badge
  const getPaymentBadge = (paymentStatus) => {
    switch (paymentStatus) {
      case 'PAYMENT_SUCCESS':
        return { bg: 'bg-green-100', text: 'text-green-800', label: 'Paid' };
      case 'PAYMENT_INITIATED':
        return { bg: 'bg-blue-100', text: 'text-blue-800', label: 'Initiated' };
      case 'PAYMENT_PENDING':
        return { bg: 'bg-yellow-100', text: 'text-yellow-800', label: 'Pending' };
      case 'PAYMENT_FAILED':
        return { bg: 'bg-red-100', text: 'text-red-800', label: 'Failed' };
      case 'PAYMENT_REFUNDED':
        return { bg: 'bg-purple-100', text: 'text-purple-800', label: 'Refunded' };
      default:
        return { bg: 'bg-gray-100', text: 'text-gray-800', label: paymentStatus?.replace('PAYMENT_', '') || 'Unknown' };
    }
  };

  // Parse items JSON
  const parseItems = (items) => {
    try {
      if (Array.isArray(items)) return items;
      if (typeof items === 'string') return JSON.parse(items);
      return [];
    } catch {
      return [];
    }
  };

  return (
    <div className="space-y-6 p-7">
      {/* Header */}
      <SectionHeader
        title="Orders"
        subtitle="Manage and track all customer orders"
      />

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search by order ID, customer, email, or transaction ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Refresh Button */}
            <button
              onClick={fetchOrders}
              disabled={loading}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              {loading ? 'Loading...' : 'Refresh'}
            </button>

            {/* Status Filter */}
            <div className="w-full md:w-48">
              <Dropdown
                options={statusOptions}
                value={statusFilter}
                onChange={(val) => setStatusFilter(val)}
                label="Order Status"
              />
            </div>

            {/* Payment Filter */}
            <div className="w-full md:w-48">
              <Dropdown
                options={paymentStatusOptions}
                value={paymentFilter}
                onChange={(val) => setPaymentFilter(val)}
                label="Payment Status"
              />
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center">
              <Loader2 className="animate-spin h-8 w-8 text-blue-500 mx-auto mb-4" />
              <p className="text-gray-600">Loading orders...</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  {[
                    "Order ID",
                    "Customer",
                    "Amount",
                    "Order Status",
                    "Payment Status",
                    "Transaction ID",
                    "Date",
                    "Actions",
                  ].map((head) => (
                    <th
                      key={head}
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      {head}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredOrders.map((order) => {
                  const StatusIcon = getStatusBadge(order.status).icon;
                  const paymentBadge = getPaymentBadge(order.paymentStatus);
                  
                  return (
                    <tr
                      key={order.id}
                      className="hover:bg-gray-50 cursor-pointer text-xs"
                      onClick={() => openDetails(order)}
                    >
                      <td className="px-6 py-4 font-medium text-gray-900 ">
                        {order.orderId}
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-medium">{order.customerName}</div>
                          <div className="text-sm text-gray-500 text-xs truncate block max-w-[120px]">{order.customerEmail}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-medium text-gray-900">
                        {formatINR(order.totalAmount)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <StatusIcon className="w-4 h-4" />
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(order.status).bg} ${getStatusBadge(order.status).text}`}>
                            {order.status?.replace(/_/g, ' ')}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${paymentBadge.bg} ${paymentBadge.text}`}>
                          {paymentBadge.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-600 font-mono text-xs">
                        {order.transactionId ? (
                          <span className="truncate block max-w-[120px]">{order.transactionId}</span>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-gray-600 text-xs">
                        {formatDate(order.createdAt)}
                      </td>
                      <td className="px-6 py-4">
                        <button
                          className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            openDetails(order);
                          }}
                        >
                          <Eye className="w-4 h-4" />
                          View
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {!loading && filteredOrders.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">No orders found</p>
              <p className="text-sm">
                {searchTerm || statusFilter !== 'all' || paymentFilter !== 'all'
                  ? 'Try changing your search or filters'
                  : 'No orders have been placed yet'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Order Details Modal */}
      {isDetailsOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={closeDetails}
          />
          <div className="relative bg-white w-full max-w-4xl mx-auto rounded-2xl shadow-xl border border-gray-200 flex flex-col max-h-[90vh]">
  <div className="flex items-center justify-between p-6 border-b">

              <div>
                <h3 className="text-xl font-semibold text-gray-900">
                  Order #{selectedOrder.orderId}
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  Created on {formatDate(selectedOrder.createdAt)}
                </p>
              </div>
              <button
                onClick={closeDetails}
                className="p-2 rounded-md text-gray-600 hover:bg-gray-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              {/* Order Status Bar */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex flex-wrap gap-4 justify-between items-center">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Order Status</h4>
                    <div className="flex items-center gap-3">
                      <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusBadge(selectedOrder.status).bg} ${getStatusBadge(selectedOrder.status).text}`}>
                        {selectedOrder.status?.replace(/_/g, ' ')}
                      </span>
                      {updatingStatus ? (
                        <Loader2 className="animate-spin h-4 w-4" />
                      ) : (
                        <select
                          value={selectedOrder.status}
                          onChange={(e) => updateOrderStatus(selectedOrder.orderId, e.target.value)}
                          className="text-sm border border-gray-300 rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <option value="PENDING">Pending</option>
                          <option value="PROCESSING">Processing</option>
                          <option value="COMPLETED">Completed</option>
                          <option value="CANCELLED">Cancelled</option>
                        </select>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Payment Status</h4>
                    <span className={`px-3 py-1 text-sm font-medium rounded-full ${getPaymentBadge(selectedOrder.paymentStatus).bg} ${getPaymentBadge(selectedOrder.paymentStatus).text}`}>
                      {getPaymentBadge(selectedOrder.paymentStatus).label}
                    </span>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Total Amount</h4>
                    <p className="text-xl font-bold text-gray-900">{formatINR(selectedOrder.totalAmount)}</p>
                  </div>
                </div>
              </div>

              {/* Customer Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Customer Information</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p className="font-medium">{selectedOrder.customerName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="font-medium">{selectedOrder.customerEmail}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Phone</p>
                      <p className="font-medium">{selectedOrder.customerPhone || 'Not provided'}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Shipping Information</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Address</p>
                      <p className="font-medium">{selectedOrder.customerAddress || 'Not provided'}</p>
                    </div>
                    {(selectedOrder.shippingCity || selectedOrder.shippingState || selectedOrder.shippingPincode) && (
                      <div>
                        <p className="text-sm text-gray-500">Location</p>
                        <p className="font-medium">
                          {[selectedOrder.shippingCity, selectedOrder.shippingState, selectedOrder.shippingPincode]
                            .filter(Boolean)
                            .join(', ')}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Transaction Details */}
              {selectedOrder.transactionId && (
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Transaction Details</h4>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Transaction ID</p>
                        <p className="font-medium font-mono text-sm">{selectedOrder.transactionId}</p>
                      </div>
                      {selectedOrder.merchantOrderId && (
                        <div>
                          <p className="text-sm text-gray-500">Merchant Order ID</p>
                          <p className="font-medium font-mono text-sm">{selectedOrder.merchantOrderId}</p>
                        </div>
                      )}
                      {selectedOrder.paymentInitiatedAt && (
                        <div>
                          <p className="text-sm text-gray-500">Payment Initiated</p>
                          <p className="font-medium">{formatDate(selectedOrder.paymentInitiatedAt)}</p>
                        </div>
                      )}
                      {selectedOrder.paidAt && (
                        <div>
                          <p className="text-sm text-gray-500">Paid At</p>
                          <p className="font-medium">{formatDate(selectedOrder.paidAt)}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Order Items */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Order Items
                </h4>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {parseItems(selectedOrder.items).map((item, index) => (
                        <tr key={index}>
                          <td className="px-4 py-3">
                            <div>
                              <p className="font-medium text-gray-900">{item.name}</p>
                              {item.image && (
                                <div className="mt-1 w-12 h-12 bg-gray-100 rounded overflow-hidden">
                                  <img
                                    src={item.image}
                                    alt={item.name}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      e.target.style.display = 'none';
                                    }}
                                  />
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center">{item.quantity}</td>
                          <td className="px-4 py-3 text-right">{formatINR(item.price)}</td>
                          <td className="px-4 py-3 text-right font-medium">{formatINR(item.price * item.quantity)}</td>
                        </tr>
                      ))}
                      <tr className="bg-gray-50 font-bold">
                        <td colSpan="3" className="px-4 py-3 text-right">Total Amount</td>
                        <td className="px-4 py-3 text-right text-lg">{formatINR(selectedOrder.totalAmount)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="p-6 border-t flex justify-end gap-3 bg-white">
    <button
      onClick={closeDetails}
      className="px-4 py-2 rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50 font-medium"
    >
      Close
    </button>
    <button
      onClick={() => window.print()}
      className="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 font-medium"
    >
      Print Receipt
    </button>
  </div>
          </div>
        </div>
      )}
    </div>
  );
}