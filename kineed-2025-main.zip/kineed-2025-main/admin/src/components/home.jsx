"use client";
import React, { useState, useRef, useEffect } from "react";
import {
  Image as ImageIcon,
  Mail,
  MapPin,
  Phone,
  Trash2,
  Plus,
  Upload,
  Save,
  X,
  Settings,
  Info,
  Globe,
  BookOpen,
  Inbox,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ActionButtons from "./uic/ActionButtons";
import Alert from "./uic/Alert";

const HomeDashboard = () => {
  const [alert, setAlert] = useState({
    show: false,
    message: "",
    type: "success",
  });
  const [contact, setContact] = useState({
    address: ["", ""], // 👈 Two address lines
    phone: "",
    email: "",
    social: {
      facebook: "",
      instagram: "",
      youtube: "",
      google: "",
    },
    apps: {
      playStore: "",
      appStore: "",
    },
  });

  const [activeSection, setActiveSection] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [itemToDelete, setItemToDelete] = useState({ id: null, type: null });
  const [pendingChanges, setPendingChanges] = useState({
    contact: false,
  });

  useEffect(() => {
    fetchContactInfo();
  }, []);

  const fetchContactInfo = async () => {
    const res = await fetch("https://api.jarayuayurved.com/api/contact");
    const data = await res.json();

    if (data && data.length > 0) {
      const contactData = data[0]; // 👈 Take first record
      setContact({
        address: [
          contactData.address?.[0] || "",
          contactData.address?.[1] || "",
        ],
        phone: contactData.phone || "",
        email: contactData.email || "",
        social: {
          facebook: contactData.facebook || "",
          instagram: contactData.instagram || "",
          youtube: contactData.youtube || "",
          google: contactData.google || "",
          whatsapp: contactData.whatsapp || "",
        },
        apps: {
          playStore: contactData.playStore || "",
          appStore: contactData.appStore || "",
        },
      });
    }
  };

  const saveContactInfo = async () => {
    const payload = {
      address: contact.address, // 👈 send as array
      phone: contact.phone,
      email: contact.email,
      facebook: contact.social.facebook,
      instagram: contact.social.instagram,
      youtube: contact.social.youtube,
      google: contact.social.google,
    };

    try {
      const res = await fetch(
        "https://api.jarayuayurved.com/api/contact/9009c83b-d217-4067-92dc-2adfba2b543c",
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );

      if (res.ok) {
        setAlert({
          show: true,
          message: "Contact updated successfully!",
          type: "success",
        });
        setPendingChanges((prev) => ({ ...prev, contact: false }));
        fetchContactInfo();
      } else {
        throw new Error("Failed to save contact info");
      }
    } catch (error) {
      console.error("Error saving contact:", error);
      setAlert({
        show: true,
        message: "Failed to save contact information",
        type: "error",
      });
    }
  };

  const cancelContactChanges = () => {
    fetchContactInfo();
    setPendingChanges((prev) => ({ ...prev, contact: false }));
  };

  const sections = [
    {
      id: "contact",
      title: "Contact Information",
      icon: <Settings size={20} />,
      stats: "Edit contact details",
      action: "Update contact info",
      content: (
        <div className="space-y-6">
          <div className="space-y-5">
            {/* Address Line 1 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <MapPin className="mr-2" size={16} />
                Clinic Address 1
              </label>
              <input
                type="text"
                value={contact.address[0]}
                onChange={(e) => {
                  const updated = [...contact.address];
                  updated[0] = e.target.value;
                  setContact({ ...contact, address: updated });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            {/* Address Line 2 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <MapPin className="mr-2" size={16} />
                Clinic Address 2
              </label>
              <input
                type="text"
                value={contact.address[1]}
                onChange={(e) => {
                  const updated = [...contact.address];
                  updated[1] = e.target.value;
                  setContact({ ...contact, address: updated });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Phone className="mr-2" size={16} /> Phone number
              </label>
              <input
                type="text"
                value={contact.phone}
                onChange={(e) => {
                  setContact({ ...contact, phone: e.target.value });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full  p-3 border border-gray-300 rounded-lg text-sm"
                maxLength={10}
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Mail className="mr-2" size={16} /> Email ID
              </label>
              <input
                type="text"
                value={contact.email}
                onChange={(e) => {
                  setContact({ ...contact, email: e.target.value });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
            </div>
          </div>

          {/* Social + Apps */}
          <div className="pt-4 border-t border-gray-200">
            <h3 className="font-medium mb-4 flex items-center text-sm text-gray-700">
              <Globe className="mr-2" size={16} /> Social Media Links
            </h3>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Facebook"
                value={contact.social.facebook}
                onChange={(e) => {
                  setContact({
                    ...contact,
                    social: { ...contact.social, facebook: e.target.value },
                  });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
              <input
                type="text"
                placeholder="Instagram"
                value={contact.social.instagram}
                onChange={(e) => {
                  setContact({
                    ...contact,
                    social: { ...contact.social, instagram: e.target.value },
                  });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
              <input
                type="text"
                placeholder="YouTube"
                value={contact.social.youtube}
                onChange={(e) => {
                  setContact({
                    ...contact,
                    social: { ...contact.social, youtube: e.target.value },
                  });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
              <input
                type="text"
                placeholder="Google"
                value={contact.social.google}
                onChange={(e) => {
                  setContact({
                    ...contact,
                    social: { ...contact.social, google: e.target.value },
                  });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              />
              {/* <input
                type="text"
                placeholder="WhatsApp"
                value={contact.social.whatsapp}
                onChange={(e) => {
                  setContact({
                    ...contact,
                    social: { ...contact.social, whatsapp: e.target.value },
                  });
                  setPendingChanges((prev) => ({ ...prev, contact: true }));
                }}
                className="w-full p-3 border border-gray-300 rounded-lg text-sm"
              /> */}
            </div>

            <ActionButtons
              // isAdding={isAdding}
              onSave={saveContactInfo}
              onCancel={cancelContactChanges}
            />
            {/* <div className="mt-8 flex grid grid-cols-2 mb-16 gap-3">
              <button
                onClick={saveContactInfo}
                className="bg-blue-400/30 hover:bg-blue-400/40 text-blue-900 px-4 py-2 rounded-lg flex items-center justify-center"
                disabled={!pendingChanges.contact}
              >
                Save Changes
              </button>
              <button
                onClick={cancelContactChanges}
                className="bg-gray-200 hover:bg-gray-400 text-sm text-gray-900 px-4 py-2 rounded-lg"
                disabled={!pendingChanges.contact}
              >
                Cancel
              </button>
            </div> */}
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-10">
          <h1 className="text-xl font-semibold text-gray-800">
            Home Dashboard
          </h1>
          <p className="text-gray-600 mt-2 text-sm">
            Manage your homepage content
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sections.map((section) => (
            <motion.div
              key={section.id}
              className="bg-white rounded-xl shadow border border-gray-200 p-6 cursor-pointer group"
              whileHover={{ y: -5 }}
              onClick={() => {
                setActiveSection(section.id);
                setIsEditing(true);
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="bg-blue-100 text-blue-800 p-3 rounded-xl mr-4">
                    {section.icon}
                  </div>
                  <h2 className="text-sm font-medium text-gray-900">
                    {section.title}
                  </h2>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500">{section.stats}</p>
                <div className="mt-4 flex items-center text-sm text-orange-600 font-medium">
                  <span>{section.action}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Delete Confirmation Modal */}
        <AnimatePresence>
          {showDeleteModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-white rounded-xl p-6 max-w-md w-full mx-4 shadow-xl"
              >
                <h2 className="text-xl font-bold text-red-600 mb-3">
                  Confirm Delete
                </h2>
                <p className="text-gray-700 mb-6">
                  Are you sure you want to delete this image? This action cannot
                  be undone.
                </p>
                <div className="flex justify-end gap-4">
                  <button
                    onClick={() => setShowDeleteModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (itemToDelete.type === "carousel") {
                        confirmDeleteCarouselImage();
                      } else if (itemToDelete.type === "gallery") {
                        confirmDeleteGalleryImage();
                      }
                    }}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center"
                  >
                    <Trash2 className="mr-2" size={16} />
                    Delete
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {isEditing && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black bg-opacity-40 z-30"
                onClick={() => setIsEditing(false)}
              />
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="fixed top-0 right-0 h-full w-full max-w-xl bg-white z-50 shadow-2xl"
              >
                <div className="h-full flex flex-col">
                  <div className="p-5 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <h2 className="text-md font-medium text-gray-900">
                        {sections.find((s) => s.id === activeSection)?.title}
                      </h2>
                      <div className="mt-1">
                        {sections.find((s) => s.id === activeSection)?.infoicon}
                      </div>
                    </div>

                    <button
                      onClick={() => setIsEditing(false)}
                      className="p-2 rounded-full hover:bg-gray-100"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  <div className="flex-grow overflow-y-auto p-6 scrollbar-custom">
                    {sections.find((s) => s.id === activeSection)?.content}
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>

      <Alert
        show={alert.show}
        message={alert.message}
        type={alert.type}
        onClose={() => setAlert({ ...alert, show: false })}
      />
    </div>
  );
};

export default HomeDashboard;
