// REFACTORED VERSION: Categories | Brands toggle-based manager
// Only shows CategoryManager or BrandManager based on tab click.

"use client";
import { useState, useEffect, useRef } from "react";
import { X } from "lucide-react";
import Button from "./uic/button";
import CategoryManager from "./CategoryManager";
import BrandManager from "./BrandManager";
import SectionHeader from "./uic/SectionHeader";

export default function categoriesbrands() {
  const [activeTab, setActiveTab] = useState("categories");
  const tokenRef = useRef(null);

  useEffect(() => {
    tokenRef.current = localStorage.getItem("token");
    if (!tokenRef.current) alert("Token missing. Please log in again.");
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (e.detail?.tab) {
        setActiveTab(e.detail.tab);
      }
    };

    window.addEventListener("SWITCH_TAB", handler);
    return () => window.removeEventListener("SWITCH_TAB", handler);
  }, []);

  return (
    <div className="p-7 w-full">
      {/* Top Header */}
      <SectionHeader
        title="Product Data Controls"
        subtitle="Manage categories and brands for your products."
      />

      {/* Tabs */}
      <div className="flex border-b gap-6">
        <button
          onClick={() => setActiveTab("categories")}
          className={`pb-2 text-sm font-medium border-b-2 ${
            activeTab === "categories"
              ? "border-blue-600 text-blue-600"
              : "border-transparent text-gray-600"
          }`}
        >
          Categories
        </button>

        <button
          onClick={() => setActiveTab("brands")}
          className={`pb-2 text-sm font-medium border-b-2 ${
            activeTab === "brands"
              ? "border-blue-600 text-blue-600"
              : "border-transparent text-gray-600"
          }`}
        >
          Brands
        </button>
      </div>

      {/* Content Area */}
      <div className="">
        {activeTab === "categories" && <CategoryManager />}
        {activeTab === "brands" && <BrandManager />}
      </div>
    </div>
  );
}
