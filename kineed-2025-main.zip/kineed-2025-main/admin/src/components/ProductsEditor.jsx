"use client";
import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Search } from "lucide-react";
import demoimage from "@/assets/1.jpg";

import Button from "./uic/button";
import Dropdown from "../components/Dropdown";
import ProductCard from "./uic/Productcard";
import AddCategory from "./lib/categorym";
import AddBrand from "./lib/addbrand";
import ProductForm from "./productform";
import ConfirmModal from "./uic/confirmdel";
import SectionHeader from "./uic/SectionHeader";

import {
  DndContext,
  PointerSensor,
  TouchSensor,
  KeyboardSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";

import {
  SortableContext,
  rectSortingStrategy,
  useSortable,
  arrayMove,
} from "@dnd-kit/sortable";

import { CSS } from "@dnd-kit/utilities";

/* ===========================================================
   Sortable Product Item — now uses dragRef passed into ProductCard
   =========================================================== */
function SortableProductItem({
  product,
  onEdit,
  onDelete,
  onToggleVisibility,
  onToggleStock,
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: product.id,
    animateLayoutChanges: () => true,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: transition || "transform 180ms ease",
    zIndex: isDragging ? 50 : "auto",
  };

  return (
    <div ref={setNodeRef} {...attributes} style={style} className="relative">
      {/* ProductCard contains its own GripVertical icon & receives the drag handle reference */}
      <ProductCard
        product={product}
        imageUrl={product.mainImage || demoimage}
        handleEdit={() => onEdit(product)}
        handleDelete={() => onDelete(product.id)}
        handleToggleVisibility={() => onToggleVisibility(product.id)}
        handleToggleStock={() => onToggleStock(product.id)}
        dragRef={setActivatorNodeRef} // <== important
        dragListeners={listeners} // <== important
      />
    </div>
  );
}

/* ===========================================================
   FULL ProductsEditor Component (unchanged except passing dragRef)
   =========================================================== */
export default function ProductsEditor({ setActiveContent }) {
  const [products, setProducts] = useState([]);
  const [allProducts, setAllProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);

  const [filterCategory, setFilterCategory] = useState("");
  const [filterBrand, setFilterBrand] = useState("");

  const [loading, setLoading] = useState(true);
  const [showSidebar, setShowSidebar] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isBrandOpen, setIsBrandOpen] = useState(false);

  const [searchText, setSearchText] = useState("");

  const tokenRef = useRef(null);
  const requestQueue = useRef(Promise.resolve());

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState(null);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(TouchSensor),
    useSensor(KeyboardSensor)
  );

  /* --- FETCHING --- */
  useEffect(() => {
    tokenRef.current = localStorage.getItem("token");
    if (!tokenRef.current) {
      alert("Token missing. Please log in again.");
      return;
    }
    initData();
  }, []);

  const runSerialized = (fn) => {
    requestQueue.current = requestQueue.current.then(fn).catch(console.error);
    return requestQueue.current;
  };

  const initData = async () => {
    await runSerialized(fetchCategories);
    await runSerialized(fetchBrands);
    await runSerialized(fetchProducts);
    setLoading(false);
  };

  const fetchProducts = async () => {
    const params = new URLSearchParams();
    if (filterCategory && filterCategory !== "All Categories")
      params.append("category", filterCategory);
    if (filterBrand && filterBrand !== "All Brands")
      params.append("brand", filterBrand);

    const res = await fetch(
      `https://api.kineed.in/api/products?${params.toString()}`,
      { headers: { Authorization: `Bearer ${tokenRef.current}` } }
    );

    const data = await res.json();

    if (res.ok && data.status === "success") {
      const list = data.data.products
        .slice()
        .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

      setProducts(list);
      setAllProducts(list);
    }
  };

  const handleToggleStock = async (id) => {
    await runSerialized(async () => {
      const product = products.find((p) => p.id === id);
      if (!product) return;

      await fetch(`https://api.kineed.in/api/products/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tokenRef.current}`,
        },
        body: JSON.stringify({ inStock: !product.inStock }),
      });

      await fetchProducts();
    });
  };

  const handleToggleVisibility = async (id) => {
    await runSerialized(async () => {
      const product = products.find((p) => p.id === id);
      if (!product) return;

      await fetch(`https://api.kineed.in/api/products/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tokenRef.current}`,
        },
        body: JSON.stringify({ isActive: !product.isActive }),
      });

      await fetchProducts();
    });
  };

  const fetchCategories = async () => {
    const res = await fetch(
      "https://api.kineed.in/api/products/categories/all",
      {
        headers: { Authorization: `Bearer ${tokenRef.current}` },
      }
    );
    const data = await res.json();

    if (res.ok && data.status === "success")
      setCategories(data.data.categories);
  };

  const fetchBrands = async () => {
    const res = await fetch("https://api.kineed.in/api/products/brands/all", {
      headers: { Authorization: `Bearer ${tokenRef.current}` },
    });

    const data = await res.json();
    if (res.ok && data.status === "success") setBrands(data.data.brands);
  };

  const requestDeleteProduct = (id) => {
    setProductToDelete(id);
    setDeleteModalOpen(true);
  };

  const confirmDeleteProduct = async () => {
    if (!productToDelete) return;

    await runSerialized(async () => {
      await fetch(`https://api.kineed.in/api/products/${productToDelete}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${tokenRef.current}` },
      });

      await fetchProducts();
    });

    setDeleteModalOpen(false);
    setProductToDelete(null);
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setShowSidebar(true);
  };

  const handleAddNew = () => {
    setEditingProduct(null);
    setShowSidebar(true);
  };

  const handleFormSubmit = async () => {
    await runSerialized(fetchProducts);
    setShowSidebar(false);
  };

  const executeSearch = () => {
    if (!searchText.trim()) {
      setProducts(allProducts);
      return;
    }

    const filtered = allProducts.filter((p) =>
      p.name.toLowerCase().includes(searchText.toLowerCase())
    );

    setProducts(filtered);
  };

  useEffect(() => {
    if (!loading) runSerialized(fetchProducts);
  }, [filterCategory, filterBrand]);

  /* --- DND --- */
  const handleDragEnd = async (event) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = products.findIndex((p) => p.id === active.id);
    const newIndex = products.findIndex((p) => p.id === over.id);

    const reordered = arrayMove(products, oldIndex, newIndex);
    setProducts(reordered);

    await fetch("https://api.kineed.in/api/products/reorder", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${tokenRef.current}`,
      },
      body: JSON.stringify({
        list: reordered.map((p, idx) => ({ id: p.id, order: idx })),
      }),
    });
  };

  if (loading) {
    return (
      <div className="p-7 flex items-center justify-center">
        <p className="text-gray-500">Loading products...</p>
      </div>
    );
  }

  return (
    <div className="relative p-4 sm:p-7 w-full">
      <ConfirmModal
        open={deleteModalOpen}
        title="Delete Product?"
        message="This action is permanent and cannot be undone."
        onCancel={() => setDeleteModalOpen(false)}
        onConfirm={confirmDeleteProduct}
      />

      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-3">
        <div>
          <SectionHeader
            title="Manage Products"
            subtitle="Add, edit, and delete products in your catalog."
          />
          {/* <span className="text-sm text-gray-500">
            Total: {products.length}
          </span> */}
        </div>

        {/* <div className="flex items-center gap-2 w-full md:w-auto">
          <input
            type="text"
            placeholder="Search products..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && executeSearch()}
            className="w-full md:w-72 px-4 py-2 border border-gray-300 rounded-lg"
          />
          <button
            onClick={executeSearch}
            className="p-3 bg-blue-200 text-blue-900 rounded-lg"
          >
            <Search className="w-5 h-5" />
          </button>
        </div> */}
      </div>

      {/* FILTERS */}
      <div className="flex flex-wrap justify-between gap-4 mb-6">
        <div className="flex items-center gap-2 w-full md:w-auto">
          <input
            type="text"
            placeholder="Search products..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && executeSearch()}
            className="w-full md:w-72 px-4 py-2 border border-gray-300 rounded-lg"
          />
          <button
            onClick={executeSearch}
            className="p-3 bg-blue-200 text-blue-900 rounded-lg"
          >
            <Search className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          <Dropdown
            label="Category"
            value={filterCategory}
            onChange={setFilterCategory}
            options={["All Categories", ...categories.map((c) => c.name)]}
          />
          <Dropdown
            label="Brand"
            value={filterBrand}
            onChange={setFilterBrand}
            options={["All Brands", ...brands.map((b) => b.name)]}
          />

          <Button text="Add Product" onClick={handleAddNew} variant="blue" />
        </div>
      </div>

      {/* GRID */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={products.map((p) => p.id)}
          strategy={rectSortingStrategy}
        >
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {products.map((p) => (
              <SortableProductItem
                key={p.id}
                product={p}
                onEdit={handleEdit}
                onDelete={requestDeleteProduct}
                onToggleVisibility={handleToggleVisibility}
                onToggleStock={handleToggleStock}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      {/* SIDEBAR */}
      <AnimatePresence>
        {showSidebar && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black z-40"
              onClick={() => setShowSidebar(false)}
            />

            {/* Sidebar */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 20, stiffness: 250 }}
              className="
          fixed top-0 right-0 h-full bg-white z-50 shadow-2xl 
          w-full sm:w-4/5 lg:w-3/4 xl:w-[70%]
          overflow-y-auto
        "
            >
              {/* CONTENT WRAPPER — scrollable */}
              <div className="p-6 min-h-screen">
                <div className="flex justify-between items-center mb-6 sticky top-0 bg-white pb-4 z-50">
                  <h3 className="text-lg font-semibold">
                    {editingProduct ? "Edit Product" : "Add Product"}
                  </h3>

                  <button onClick={() => setShowSidebar(false)}>
                    <X className="w-6 h-6 text-gray-600" />
                  </button>
                </div>

                {/* FORM (already scrollable inside) */}
                <ProductForm
                  product={editingProduct}
                  categories={categories.map((c) => c.name)}
                  brands={brands.map((b) => b.name)}
                  onSuccess={handleFormSubmit}
                />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
