"use client";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, StarOff } from "lucide-react";

import {
  BookText,
  ClipboardList,
  UserCheck,
  BarChart2,
  Award,
  CalendarCheck,
  CheckCircle,
  BookOpen,
  Library,
  Monitor,
  Smartphone,
  Plus,
  X,
  Trash2,
  Edit,
} from "lucide-react";

const CoursesDashboard = () => {
  const iconComponents = {
    BookText,
    ClipboardList,
    UserCheck,
    BarChart2,
    Award,
    CalendarCheck,
    CheckCircle,
    BookOpen,
    Library,
    Monitor,
    Smartphone,
  };

  const [showConfirm, setShowConfirm] = useState(false);
  const [courseToDelete, setcourseToDelete] = useState(null);

  const [courses, setCourses] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    features: [""],
    link: "",
    icon: "BookText",
  });

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const res = await fetch("https://api.jarayuayurved.com/api/courses");
      const data = await res.json();
      // Sort by createdAt (older first)
      const sorted = [...data].sort(
        (a, b) => new Date(a.createdAt) - new Date(b.createdAt)
      );

      setCourses(sorted);
    } catch (error) {
      console.error("Failed to fetch courses", error);
    }
  };

  const startEditing = (course) => {
    setEditingId(course.id);
    setFormData({
      title: course.title,
      description: course.description,
      link: course.link,
      features: [...course.features],
      icon: course.icon,
    });
    setIsEditing(true);
  };

  const startAdding = () => {
    setEditingId(null);
    setFormData({
      title: "",
      description: "",
      features: [""],
      link: "",
      icon: "BookText",
    });
    setIsEditing(true);
  };

  const cancelEditing = () => {
    setIsEditing(false);
    setEditingId(null);
  };

  const saveChanges = async () => {
    const payload = {
      title: formData.title,
      description: formData.description,
      features: formData.features.filter((f) => f.trim() !== ""),
      link: formData.link,
      icon: formData.icon,
    };

    try {
      if (editingId) {
        const res = await fetch(
          `https://api.jarayuayurved.com/api/courses/${editingId}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          }
        );
        const updated = await res.json();
        setCourses((prev) =>
          prev.map((c) => (c.id === editingId ? updated : c))
        );
      } else {
        const res = await fetch("https://api.jarayuayurved.com/api/courses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const newCourse = await res.json();
        setCourses((prev) => [...prev, newCourse]);
      }
      cancelEditing();
    } catch (error) {
      console.error("Failed to save course", error);
    }
  };

  const toggleHighlight = async (course) => {
    const updatedHighlight = !course.highlight;

    try {
      const res = await fetch(
        `https://api.jarayuayurved.com/api/courses/${course.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ...course, highlight: updatedHighlight }),
        }
      );

      if (res.ok) {
        const updated = await res.json();
        setCourses((prev) =>
          prev.map((c) => (c.id === course.id ? updated : c))
        );
      } else {
        console.error("Failed to toggle highlight");
      }
    } catch (error) {
      console.error("Error toggling highlight:", error);
    }
  };

  const deleteCourse = async (id) => {
    // if (!window.confirm("Are you sure you want to delete this course?")) return;
    try {
      await fetch(`https://api.jarayuayurved.com/api/courses/${id}`, {
        method: "DELETE",
      });
      setCourses((prev) => prev.filter((c) => c.id !== id));
    } catch (error) {
      console.error("Failed to delete course", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFeatureChange = (index, value) => {
    const updated = [...formData.features];
    updated[index] = value;
    setFormData((prev) => ({ ...prev, features: updated }));
  };

  const addFeatureField = () => {
    setFormData((prev) => ({ ...prev, features: [...prev.features, ""] }));
  };

  const removeFeatureField = (index) => {
    if (formData.features.length > 1) {
      const updated = formData.features.filter((_, i) => i !== index);
      setFormData((prev) => ({ ...prev, features: updated }));
    }
  };

  return (
    <div
      className="h-screen overflow-y-auto scrollbar-custom bg-gradient-to-b from-blue-50 to-white py-8 px-4 sm:px-6"
      style={{ height: "calc(100vh - 80px)" }}
    >
      <div className="max-w-7xl mx-auto relative">
        <div className="mb-8 flex flex-col  sm:flex-row justify-between  gap-4 sm:gap-0">
          <div>
            <h1 className="text-xl font-bold text-blue-800">
              Courses
            </h1>
            <p className="text-gray-600 text-sm">
              Manage all courses offered by the academy
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={startAdding}
            className="w-full text-sm sm:w-auto bg-gradient-to-r from-orange-300 to-orange-500 text-white font-medium py-2 px-6 rounded-lg shadow-md h-12"
          >
            Add Course
          </motion.button>
        </div>
        {/* Courses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => {
            const IconComponent = iconComponents[course.icon] || BookText;

            return (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ y: -5 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden border border-blue-100 flex flex-col"
              >
                {/* Content Area */}
                <div className="p-6 flex-grow">
                  {/* Top Row */}
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <IconComponent size={18} className=" text-[#004AAD]" />
                    </div>
                    <div className="flex gap-2">
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => toggleHighlight(course)}
                        className={`p-2 rounded-full ${
                          course.highlight
                            ? "bg-orange-500 text-yellow-100"
                            : "hover:bg-gray-100 text-gray-500"
                        }`}
                      >
                        {course.highlight ? (
                          <Star size={18} />
                        ) : (
                          <StarOff size={18} />
                        )}
                      </motion.button>

                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => startEditing(course)}
                        className="p-2 rounded-full hover:bg-blue-100 text-blue-600"
                      >
                        <Edit size={18} />
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => {
                          setcourseToDelete(course.id);
                          setShowConfirm(true);
                        }}
                        className="p-2 rounded-full hover:bg-red-100 text-red-600"
                      >
                        <Trash2 size={18} />
                      </motion.button>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-sm font-bold text-blue-800 mb-2">
                    {course.title}
                  </h3>
                  <p className="text-gray-700 font-medium mb-4 text-sm">
                    {course.description}
                  </p>

                  {/* Features */}
                  <div className="mt-4 space-y-3">
                    {course.features.map((feature, index) => (
                      <div key={index} className="flex items-start">
                        <div className="bg-blue-50 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle className="w-4 h-4 text-[#004AAD]" />
                        </div>
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sticky Bottom Footer */}
                <div className="bg-blue-50 px-6 py-4 border-t border-blue-100">
                  <div className="flex justify-between items-center">
                    <button className="bg-gradient-to-br from-orange-300 to-orange-500 hover:from-orange-400 hover:to-orange-600 text-white font-medium py-1.5 px-4 rounded-full text-sm transition-all whitespace-nowrap">
                      View Details
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Edit Sidebar */}
        <AnimatePresence>
          {isEditing && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black z-40"
                onClick={cancelEditing}
              />

              {/* Sidebar */}
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className=" fixed top-0 right-0 w-full max-w-md h-full bg-white shadow-2xl z-50 overflow-y-auto scrollbar-custom"
              >
                <div className="p-6 h-full flex flex-col">
                  {/* Panel Header */}
                  <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-200">
                    <h2 className="text-md font-medium">
                      {editingId ? "Edit Course" : "Add New Course"}
                    </h2>
                    <button
                      onClick={cancelEditing}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <X size={24} />
                    </button>
                  </div>

                  {/* Form Content */}
                  <div className=" space-y-2 ">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Course Name
                      </label>
                      <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleInputChange}
                        className="w-full text-sm px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Enter course name"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Short Description
                      </label>
                      <input
                        type="text"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        className="w-full text-sm px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Enter course description"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Course Form Link
                      </label>
                      <input
                        type="text"
                        name="link"
                        value={formData.link}
                        onChange={handleInputChange}
                        className="w-full text-sm px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Enter google form shorten URL"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Icon
                      </label>
                      <select
                        name="icon"
                        value={formData.icon}
                        onChange={handleInputChange}
                        className="w-full text-sm px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        {Object.keys(iconComponents).map((iconKey) => (
                          <option key={iconKey} value={iconKey}>
                            {iconKey}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Features
                      </label>
                      <div className="space-y-3">
                        {formData.features.length > 0 &&
                          formData.features.map((feature, index) => (
                            <div key={index} className="flex gap-2 items-start">
                              <div className="relative w-full">
                                <input
                                  type="text"
                                  value={feature}
                                  onChange={(e) =>
                                    handleFeatureChange(index, e.target.value)
                                  }
                                  className="w-full text-sm pr-10 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder={`Feature ${index + 1}`}
                                />
                                <button
                                  type="button"
                                  onClick={() => removeFeatureField(index)}
                                  className="absolute top-2 right-2 text-red-500 hover:text-red-700"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                          ))}

                        <button
                          type="button"
                          onClick={addFeatureField}
                          className="flex text-sm items-center gap-2 text-blue-600 hover:text-blue-800 p-2"
                        >
                          <Plus size={16} /> Add Feature
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-5  pt-4 border-t border-gray-200 pb-[80px]">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={saveChanges}
                      className="w-full bg-gradient-to-r text-sm from-orange-300 to-orange-500 text-white font-medium py-3 px-6 rounded-lg shadow-md"
                    >
                      {editingId ? "Update Course" : "Add Course"}
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={cancelEditing}
                      className=" w-full bg-gray-200 text-gray-700 font-medium py-3 px-6 rounded-lg"
                    >
                      Cancel
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
      {showConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-40 z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-xl shadow-lg w-[90%] max-w-sm text-center">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">
              Are you sure?
            </h2>
            <p className="text-gray-600 mb-6">
              Do you really want to delete this course?
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={() => {
                  deleteCourse(courseToDelete);
                  setShowConfirm(false);
                  setcourseToDelete(null);
                }}
                className="bg-red-600 text-white px-4 py-2 rounded-lg"
              >
                Yes, Delete
              </button>
              <button
                onClick={() => {
                  setShowConfirm(false);
                  setcourseToDelete(null);
                }}
                className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CoursesDashboard;
