"use client";

import { useEffect, useState } from "react";
import { ShoppingCart, Star, MessageSquare, TrendingUp } from "lucide-react";
import SectionHeader from "./uic/SectionHeader";

export default function Dashboard({ setActiveContent }) {
  const [reviewCount, setReviewCount] = useState(null);
  const [loadingReviews, setLoadingReviews] = useState(true);

  const API_BASE_URL = "https://api.kineed.in/api/reviews";

  // Fetch total reviews dynamically
  const fetchReviewCount = async () => {
    try {
      setLoadingReviews(true);

      const res = await fetch(API_BASE_URL);
      const data = await res.json();

      if (data.status === "success") {
        setReviewCount(data.data.reviews.length);
      } else {
        console.error("Failed to fetch reviews count:", data);
      }
    } catch (error) {
      console.error("Error fetching reviews count:", error);
    } finally {
      setLoadingReviews(false);
    }
  };

  useEffect(() => {
    fetchReviewCount();
  }, []);

  const formatINR = (n) => {
    try {
      return n.toLocaleString("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0,
      });
    } catch {
      return `₹${n}`;
    }
  };

  const stats = [
    {
      label: "Total Orders",
      value: "1,234",
      icon: ShoppingCart,
      color: "bg-blue-400/40 text-blue-900",
      change: "+12%",
      link: "Orders",
    },
    {
      label: "Reviews",
      value: loadingReviews ? "Loading..." : reviewCount ?? "0",
      icon: Star,
      color: "bg-yellow-400/40 text-yellow-900",
      change: "+8%",
      link: "Reviews",
    },
    {
      label: "Enquiries",
      value: "432",
      icon: MessageSquare,
      color: "bg-green-400/40 text-green-900",
      change: "+15%",
      link: "Enquiries",
    },
    {
      label: "Revenue",
      value: formatINR(45678),
      icon: TrendingUp,
      color: "bg-purple-400/40 text-purple-900",
      change: "+23%",
      link: null,
    },
  ];

  const recentOrders = [
    {
      id: "#1234",
      customer: "John Doe",
      amount: 299,
      status: "Completed",
      date: "2024-01-15",
    },
    {
      id: "#1235",
      customer: "Jane Smith",
      amount: 450,
      status: "Processing",
      date: "2024-01-15",
    },
    {
      id: "#1236",
      customer: "Bob Johnson",
      amount: 199,
      status: "Pending",
      date: "2024-01-14",
    },
  ];

  return (
    <div className="space-y-6 p-7">
      <SectionHeader
        title="Dashboard Overview"
        subtitle="Welcome back! Here's what's happening today."
      />

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;

          return (
            <div
              key={index}
              onClick={() => {
                if (stat.link) {
                  setActiveContent(stat.link);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }
              }}
              className="bg-white relative rounded-lg border border-gray-200 p-2 md:p-5 py-3 shadow-sm cursor-pointer hover:shadow-md transition"
            >
              <div className="flex items-center justify-around">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-3 h-3 md:w-5 md:h-5" />
                </div>

                <div>
                  <h3 className="text-gray-600 text-xs md:text-sm font-medium mb-1">
                    {stat.label}
                  </h3>
                  <p className="text-sm md:text-xl font-semibold text-gray-900">
                    {stat.value}
                  </p>
                </div>
              </div>

              <div className="absolute inset-x-0 bottom-0 h-0.5 rounded-b-2xl bg-gradient-to-r from-blue-500 via-sky-400 to-indigo-500"></div>
            </div>
          );
        })}
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Recent Orders</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Order ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recentOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {order.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {order.customer}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatINR(order.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs font-medium rounded-full ${
                        order.status === "Completed"
                          ? "bg-green-100 text-green-800"
                          : order.status === "Processing"
                          ? "bg-blue-100 text-blue-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {order.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t border-gray-200">
          <button
            onClick={() => setActiveContent("Orders")}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium"
          >
            View all orders →
          </button>
        </div>
      </div>
    </div>
  );
}
