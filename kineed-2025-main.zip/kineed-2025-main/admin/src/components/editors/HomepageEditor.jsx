"use client";
import React, { useState, useEffect, useRef } from "react";
import { Trash2, Upload, Info } from "lucide-react"; // added Info icon for tooltip
import ActionButtons from "../uic/ActionButtons";
import Alert from "../uic/Alert";
import ImageUploader from "../uic/ImageUploader";
import MultiImageUploader from "../uic/MultiImageUploader";
import InfoTooltip from "../uic/InfoTooltip";

/* -----------------------------------------------------
   MEDIA SERVER CONFIG
----------------------------------------------------- */
const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

const MEDIA_UPLOAD =
  "https://media.bizonance.in/api/v1/image/upload/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

/* -----------------------------------------------------
   MAIN COMPONENT
----------------------------------------------------- */
export default function Photos() {
  const [alert, setAlert] = useState({
    show: false,
    message: "",
    type: "success",
  });

  const [homeId, setHomeId] = useState(null);

  // ---------------------------
  // LOGO
  // ---------------------------
  const [logo, setLogo] = useState(null);
  const [logoInitial, setLogoInitial] = useState(null);
  const [logoFile, setLogoFile] = useState(null);

  // ---------------------------
  // GALLERY
  // ---------------------------
  const [gallery, setGallery] = useState([]);

  const [pendingChanges, setPendingChanges] = useState({
    uploads: [],
    deletions: [],
    logoChanged: false,
  });

  const fileInputRef = useRef(null);

  /* -----------------------------------------------------
     LOAD EXISTING HOME DATA
  ----------------------------------------------------- */
  useEffect(() => {
    fetchHome();
  }, []);

  const fetchHome = async () => {
    try {
      const res = await fetch("https://api.kineed.in/api/home");
      if (!res.ok) return;

      const { data } = await res.json();
      const home = data?.[0];
      if (!home) return;

      setHomeId(home.id);

      // LOGO
      setLogoInitial(home.logo || null);
      setLogo(home.logo ? `${MEDIA_DOWNLOAD}/${home.logo}` : null);

      // GALLERY
      const galleryFormatted = home.sliderimages.map((filename) => ({
        id: filename,
        preview: `${MEDIA_DOWNLOAD}/${filename}`,
      }));
      setGallery(galleryFormatted);

      // Reset pending
      setPendingChanges({
        uploads: [],
        deletions: [],
        logoChanged: false,
      });
    } catch (err) {
      console.error("Error loading home:", err);
    }
  };

  /* -----------------------------------------------------
     UPLOAD TO MEDIA SERVER
  ----------------------------------------------------- */
  const uploadToMedia = async (file) => {
    try {
      const fd = new FormData();
      fd.append("file", file);

      const res = await fetch(MEDIA_UPLOAD, { method: "POST", body: fd });
      const data = await res.json();

      return data?.uploadedImages?.[0]?.filename || null;
    } catch (err) {
      console.error("Upload failed:", err);
      return null;
    }
  };

  /* -----------------------------------------------------
     LOGO CHANGE
  ----------------------------------------------------- */
  const handleLogoChange = (file) => {
    if (file) {
      setLogo(URL.createObjectURL(file));
      setLogoFile(file);
      setPendingChanges((prev) => ({ ...prev, logoChanged: true }));
    } else {
      setLogo(null);
      setLogoFile(null);
      setPendingChanges((prev) => ({ ...prev, logoChanged: true }));
    }
  };

  /* -----------------------------------------------------
     LIMIT GALLERY: MAX 3 IMAGES
  ----------------------------------------------------- */
  const addImages = (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    // Prevent adding more than 3 images
    if (gallery.length + files.length > 3) {
      setAlert({
        show: true,
        message: "You can only upload up to 3 slider images.",
        type: "error",
      });
      return;
    }

    const newUploads = files.map((file) => ({
      id: `temp-${Date.now()}-${Math.random().toString(36).substr(2, 8)}`,
      file,
      preview: URL.createObjectURL(file),
    }));

    setPendingChanges((prev) => ({
      ...prev,
      uploads: [...prev.uploads, ...newUploads],
    }));

    setGallery((prev) => [...prev, ...newUploads]);
  };

  const triggerUpload = () => fileInputRef.current.click();

  /* -----------------------------------------------------
     DELETE GALLERY IMAGE
  ----------------------------------------------------- */
  const deleteImage = (id) => {
    const isTemp = id.startsWith("temp-");

    setPendingChanges((prev) => ({
      ...prev,
      uploads: isTemp ? prev.uploads.filter((u) => u.id !== id) : prev.uploads,
      deletions: isTemp ? prev.deletions : [...prev.deletions, id],
    }));

    setGallery((prev) => prev.filter((img) => img.id !== id));
  };

  /* -----------------------------------------------------
     SAVE ALL CHANGES (PUT /home/:id)
  ----------------------------------------------------- */
  const saveGallery = async () => {
    try {
      if (!homeId) return;

      let finalSliderImages = gallery
        .filter((item) => !item.id.startsWith("temp-"))
        .map((item) => item.id);

      // Upload new slider images
      for (const item of pendingChanges.uploads) {
        const filename = await uploadToMedia(item.file);
        if (filename) finalSliderImages.push(filename);
      }

      // Remove deleted images
      finalSliderImages = finalSliderImages.filter(
        (id) => !pendingChanges.deletions.includes(id)
      );

      // Upload logo if changed
      let finalLogo = logoInitial;
      if (pendingChanges.logoChanged) {
        if (logoFile) {
          const filename = await uploadToMedia(logoFile);
          if (filename) finalLogo = filename;
        } else {
          finalLogo = null;
        }
      }

      // SAVE ALL
      await fetch(`https://api.kineed.in/api/home/${homeId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          logo: finalLogo,
          sliderimages: finalSliderImages,
        }),
      });

      setAlert({
        show: true,
        message: "Home updated successfully",
        type: "success",
      });

      fetchHome();
    } catch (err) {
      console.error(err);
      setAlert({
        show: true,
        message: "Failed to save changes",
        type: "error",
      });
    }
  };

  /* -----------------------------------------------------
     CANCEL
  ----------------------------------------------------- */
  const cancelChanges = () => {
    fetchHome();
    setAlert({
      show: true,
      message: "Changes reverted",
      type: "info",
    });
  };

  const hasChanges =
    pendingChanges.uploads.length > 0 ||
    pendingChanges.deletions.length > 0 ||
    pendingChanges.logoChanged;

  /* -----------------------------------------------------
     RENDER
  ----------------------------------------------------- */
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-12">
        {/* ---------------- LOGO ---------------- */}
        <div className="space-y-4 md:col-span-4 lg:col-span-4 mb-6 md:mb-0 md:mr-6">
          <h2 className="text-lg font-semibold">Logo</h2>

          <ImageUploader
            image={logo}
            onImageChange={handleLogoChange}
            uploadText="Upload Logo"
            changeText="Change Logo"
            noImageText="No Logo"
            required
          />
        </div>

        {/* ---------------- GALLERY ---------------- */}
        <div className="col-span-8">
          <div className="flex justify-between items-center ">
            <h2 className="text-lg  font-semibold flex items-center gap-2">
              Slider Images
              {/* Tooltip */}
              <InfoTooltip
                points={[
                  "You can upload a maximum of 3 slider images. Recommended size: 2000×800 or higher.",
                  "Preferred formats: JPEG, PNG, WEBP.",
                  "Image size should be less than 5 MB.",
                  "Recommended minimum resolution: 800×800 pixels.",
                  "Avoid blurry or stretched images.",
                ]}
              />
            </h2>

            <button
              onClick={triggerUpload}
              className="text-sm bg-blue-200 hover:bg-blue-300 text-blue-900  px-4 py-2 rounded flex justify-center"
              disabled={gallery.length >= 3}
            >
              <Upload className="mr-2" size={16} /> Add Images
            </button>
          </div>

          {/* GRID */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-0">
            {gallery.map((item) => (
              <div
                key={item.id}
                className="relative  rounded-lg overflow-hidden group"
              >
                <img
                  src={item.preview}
                  className="w-full h-[150px] object-contain"
                />

                <button
                  onClick={() => deleteImage(item.id)}
                  className="absolute bottom-2 right-2 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition"
                >
                  <Trash2 size={16} />
                </button>

                {item.id.startsWith("temp-") && (
                  <div className="absolute top-2 left-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded">
                    New
                  </div>
                )}

                {pendingChanges.deletions.includes(item.id) && (
                  <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
                    To Delete
                  </div>
                )}
              </div>
            ))}
          </div>

          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="image/*"
            multiple
            onChange={addImages}
          />
        </div>

        {/* ALERT */}
        <Alert
          show={alert.show}
          message={alert.message}
          type={alert.type}
          onClose={() => setAlert({ ...alert, show: false })}
        />
      </div>

      {/* SAVE/CANCEL */}
      <ActionButtons
        onSave={saveGallery}
        onCancel={cancelChanges}
        disabled={!hasChanges}
      />
    </div>
  );
}
