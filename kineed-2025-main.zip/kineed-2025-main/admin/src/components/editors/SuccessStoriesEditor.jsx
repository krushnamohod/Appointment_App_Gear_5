"use client";
import React, { useEffect, useState } from "react";

const API_BASE = "https://api.kineed.in/api/policy";

import Button from "./../uic/button";
import ActionButtons from "./../uic/ActionButtons";
import { Dot, Heading1, Heading2, Rows3, Trash2 } from "lucide-react";

/* =====================================================
   COMPONENT: Description Item Editor
===================================================== */
function DescriptionItem({ item, index, onChange, onDelete }) {
  const update = (field, value) => {
    onChange(index, { ...item, [field]: value });
  };

  return (
    <div className="bg-white rounded-lg border-gray-200 mb-4">
      <div className="flex flex-col gap-3">
        <div className="relative">
          <textarea
            rows={item.type === "content" ? 4 : 1}
            value={item.text}
            onChange={(e) => update("text", e.target.value)}
            className="w-full border rounded p-3 text-sm"
            placeholder={`Enter ${item.type}...`}
          />

          <button
            onClick={() => onDelete(index)}
            className="px-3 py-3 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 flex items-center justify-center transition-colors absolute -top-2 -right-2"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* =====================================================
   EMPTY STATE
===================================================== */
function EmptyState({ onAddPolicy }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <h2 className="text-2xl font-semibold text-gray-900 mb-3">
        No Policies Found
      </h2>

      <p className="text-gray-600 mb-8">
        Create your first policy and start adding structured content.
      </p>

      <Button text="Create Policy" onClick={onAddPolicy} variant="blue" />
    </div>
  );
}

/* =====================================================
   MAIN SYSTEM
   - name-based backend contract retained
   - no useEffect returns a Promise or non-function
   - guarded operations when edited/policy may be null
===================================================== */
export default function PolicyDashboard() {
  const [policies, setPolicies] = useState([]);
  const [active, setActive] = useState(null);
  const [policy, setPolicy] = useState(null); // original from API
  const [edited, setEdited] = useState(null); // Local editable copy

  const [loading, setLoading] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newSubtitle, setNewSubtitle] = useState("");

  /* ========================= Load All Policies ========================= */
  const loadPolicies = async () => {
    setLoading(true);
    try {
      const res = await fetch(API_BASE);
      if (!res.ok) throw new Error("Failed to fetch policies");
      const data = await res.json();
      setPolicies(Array.isArray(data) ? data : []);

      // set active only if it's currently nullish
      setActive(
        (prev) =>
          prev ?? (Array.isArray(data) && data.length > 0 ? data[0].name : null)
      );
    } catch (err) {
      console.error(err);
      setPolicies([]);
    } finally {
      setLoading(false);
    }
  };

  /* ========================= Load One Policy ========================= */
  const loadPolicy = async (name) => {
    if (!name) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/${encodeURIComponent(name)}`);
      if (!res.ok) {
        if (res.status === 404) {
          setPolicy(null);
          setEdited(null);
          return;
        }
        throw new Error("Failed to fetch policy");
      }

      const data = await res.json();
      setPolicy(data);

      const mapped = (data.description || []).map((d) => ({
        id: d.id ?? undefined,
        type: d.heading
          ? "heading"
          : d.subheading
          ? "subheading"
          : d.point
          ? "point"
          : "content",
        text: d.heading || d.subheading || d.point || d.content || "",
      }));

      setEdited({
        id: data.id,
        name: data.name,
        subtitle: data.subtitle || "",
        description: mapped,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  /* ========================= Effects (fixed) ========================= */
  useEffect(() => {
    // don't return the promise — call async inside
    loadPolicies();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!active) return;
    loadPolicy(active);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  /* ========================= Create Policy ========================= */
  const createPolicy = async () => {
    if (!newName.trim()) {
      alert("Policy name is required.");
      return;
    }

    try {
      const payload = {
        name: newName.trim(),
        subtitle: newSubtitle.trim(),
        description: [],
      };

      const res = await fetch(API_BASE, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error("Failed to create policy");

      const created = await res.json();

      setShowCreate(false);
      setNewName("");
      setNewSubtitle("");

      await loadPolicies();
      if (created && created.name) setActive(created.name);
    } catch (err) {
      console.error(err);
      alert("Unable to create policy.");
    }
  };

  /* ========================= Delete policy (BY NAME) ========================= */
  const deletePolicy = async (name) => {
    // ensure we delete by name according to backend contract
    const policyName = typeof name === "string" ? name : policy?.name;
    if (!policyName) {
      alert("No policy name available to delete.");
      return;
    }

    if (!confirm(`Delete policy "${policyName}"? This is permanent.`)) return;

    try {
      const res = await fetch(`${API_BASE}/${encodeURIComponent(policyName)}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Failed to delete");

      await loadPolicies();
      setActive(null);
      setPolicy(null);
      setEdited(null);
    } catch (err) {
      console.error(err);
      alert("Delete failed.");
    }
  };

  /* ========================= Add Description Item ========================= */
  const addDescription = (type) => {
    setEdited((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        description: [...(prev.description || []), { type, text: "" }],
      };
    });
  };

  /* ========================= Update Description Item ========================= */
  const updateDescriptionItem = (index, newItem) => {
    setEdited((prev) => {
      if (!prev) return prev;
      const arr = [...(prev.description || [])];
      arr[index] = newItem;
      return { ...prev, description: arr };
    });
  };

  /* ========================= Delete Description Item ========================= */
  const deleteDescriptionItem = async (index) => {
    if (!edited) return;
    const item = edited.description?.[index];
    if (!item) return;

    // if saved on server (has id) -> call API delete route
    if (item.id) {
      if (!confirm("Delete this saved description item?")) return;
      try {
        const res = await fetch(`${API_BASE}/description/${item.id}`, {
          method: "DELETE",
        });
        if (!res.ok) throw new Error("Failed to delete description item");
        // reload policy from server (server reorders)
        await loadPolicy(edited.name);
      } catch (err) {
        console.error(err);
        alert("Failed to delete description item.");
      }
      return;
    }

    // else just remove locally
    setEdited((prev) => {
      if (!prev) return prev;
      const arr = [...(prev.description || [])];
      arr.splice(index, 1);
      return { ...prev, description: arr };
    });
  };

  /* ========================= Save Policy (UPDATE BY NAME) ========================= */
  const savePolicy = async () => {
    if (!edited?.name?.trim()) {
      alert("Policy name is required.");
      return;
    }

    // always PUT to the current (old) policy name (backend contract)
    const oldName = policy?.name || active;
    if (!oldName) {
      alert("No active policy selected to update.");
      return;
    }

    const descriptionPayload = edited.description.map((item, idx) => {
      const block = { order: idx };

      if (item.type === "heading") block.heading = item.text;
      if (item.type === "subheading") block.subheading = item.text;
      if (item.type === "content") block.content = item.text;
      if (item.type === "point") block.point = item.text;

      return block;
    });

    try {
      const res = await fetch(`${API_BASE}/${encodeURIComponent(oldName)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: edited.name, // allow rename
          subtitle: edited.subtitle,
          description: descriptionPayload,
        }),
      });

      if (!res.ok) {
        // surface 404 specially
        if (res.status === 404) {
          alert("Policy not found on server (it may have been deleted).");
          await loadPolicies();
          setActive(null);
          setPolicy(null);
          setEdited(null);
          return;
        }
        throw new Error(`Failed to save policy (status ${res.status})`);
      }

      const updated = await res.json();

      // set active to new name returned by server (or edited.name)
      setActive(updated?.name ?? edited.name);

      await loadPolicies();
      await loadPolicy(updated?.name ?? edited.name);

      alert("Policy updated.");
    } catch (err) {
      console.error(err);
      alert("Failed to save policy.");
    }
  };

  /* ========================= Render ========================= */
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Empty State */}
      {policies.length === 0 && (
        <EmptyState onAddPolicy={() => setShowCreate(true)} />
      )}

      {/* Main */}
      {policies.length > 0 && (
        <>
          {/* Tabs */}
          <div className="flex justify-between mb-6 items-center">
            <div className="flex gap-2 flex-wrap">
              {policies.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setActive(p.name)}
                  className={`px-8 py-2 flex gap-2 relative rounded-lg border ${
                    active === p.name
                      ? "bg-blue-200 text-blue-900"
                      : "bg-white text-gray-700"
                  }`}
                >
                  {p.name}

                  {active === p.name && (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        deletePolicy(p.name);
                      }}
                      title="Delete Policy"
                      className="w-8 h-8 absolute -top-2 -right-2 bg-red-100 rounded-full flex items-center justify-center cursor-pointer hover:bg-red-200 transition"
                    >
                      <Trash2 className="h-4 w-4 text-red-700" />
                    </div>
                  )}
                </button>
              ))}
            </div>

            <Button
              text="Create Policy"
              onClick={() => setShowCreate(true)}
              variant="blue"
            />
          </div>

          {/* Editor */}
          {edited ? (
            <div className="bg-white rounded-xl p-4">
              <div className="relative">
                <input
                  value={edited.name}
                  onChange={(e) =>
                    setEdited({ ...edited, name: e.target.value })
                  }
                  className="w-full border p-3 text-xl font-semibold mb-3 pr-12"
                  placeholder="Policy Title"
                />

                {/* {policy && (
                  <div
                    onClick={() => deletePolicy(policy.name)}
                    title="Delete Policy"
                    className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center cursor-pointer hover:bg-red-200 transition absolute top-2 right-2"
                  >
                    <Trash2 className="h-5 w-5 text-red-700" />
                  </div>
                )} */}
              </div>

              <input
                value={edited.subtitle}
                onChange={(e) =>
                  setEdited({ ...edited, subtitle: e.target.value })
                }
                className="w-full border p-2 text-sm mb-6"
                placeholder="Policy Subtitle"
              />

              {/* Add Buttons */}
              <div className="flex justify-end gap-2 mb-4">
                <div
                  onClick={() => addDescription("heading")}
                  className="w-10 h-10 bg-blue-300 rounded-full flex items-center justify-center hover:bg-blue-400 cursor-pointer transition"
                  title="Add Heading"
                >
                  <Heading1 className="h-5 w-5 text-blue-900" />
                </div>

                <div
                  onClick={() => addDescription("subheading")}
                  className="w-10 h-10 bg-blue-300 rounded-full flex items-center justify-center hover:bg-blue-400 cursor-pointer transition"
                  title="Add Subheading"
                >
                  <Heading2 className="h-5 w-5 text-blue-900" />
                </div>

                <div
                  onClick={() => addDescription("content")}
                  className="w-10 h-10 bg-blue-300 rounded-full flex items-center justify-center hover:bg-blue-400 cursor-pointer transition"
                  title="Add Content"
                >
                  <Rows3 className="h-5 w-5 text-blue-900" />
                </div>

                <div
                  onClick={() => addDescription("point")}
                  className="w-10 h-10 bg-blue-300 rounded-full flex items-center justify-center hover:bg-blue-400 cursor-pointer transition"
                  title="Add Point"
                >
                  <Dot className="h-5 w-5 text-blue-900" />
                </div>
              </div>

              {/* Description Items */}
              {(edited.description || []).map((item, index) => (
                <DescriptionItem
                  key={index}
                  item={item}
                  index={index}
                  onChange={updateDescriptionItem}
                  onDelete={deleteDescriptionItem}
                />
              ))}

              <div className="flex justify-end pt-4 mt-6">
                <ActionButtons
                  onSave={savePolicy}
                  onCancel={() => policy && loadPolicy(policy.name)}
                />
              </div>
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-xl">
              Select a policy to edit
            </div>
          )}
        </>
      )}

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <h3 className="text-xl font-semibold mb-4">Create Policy</h3>

            <input
              className="w-full p-3 border mb-3"
              placeholder="Policy Name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
            />

            <input
              className="w-full p-3 border mb-6"
              placeholder="Subtitle (optional)"
              value={newSubtitle}
              onChange={(e) => setNewSubtitle(e.target.value)}
            />

            <div className="flex justify-end">
              <ActionButtons
                onSave={createPolicy}
                onCancel={() => setShowCreate(false)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
