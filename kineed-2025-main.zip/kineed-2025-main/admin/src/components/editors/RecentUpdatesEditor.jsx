"use client"

import { useState } from "react"
import { Plus, X } from "lucide-react"

export default function RecentUpdatesEditor() {
  const [updates, setUpdates] = useState([
    { id: 1, title: "New Product Launch", image: "/placeholder.jpg", content: "We are excited to announce..." },
    { id: 2, title: "Company Milestone", image: "/placeholder.jpg", content: "We have reached 10,000 customers!" },
  ])

  const [showSidebar, setShowSidebar] = useState(false)
  const [editingUpdate, setEditingUpdate] = useState(null)

  const handleEdit = (update) => {
    setEditingUpdate(update)
    setShowSidebar(true)
  }

  const handleAddNew = () => {
    setEditingUpdate({ id: Date.now(), title: "", image: "", content: "" })
    setShowSidebar(true)
  }

  const handleSave = () => {
    if (editingUpdate.id && updates.find((u) => u.id === editingUpdate.id)) {
      setUpdates(updates.map((u) => (u.id === editingUpdate.id ? editingUpdate : u)))
    } else {
      setUpdates([...updates, editingUpdate])
    }
    setShowSidebar(false)
    setEditingUpdate(null)
  }

  const handleDelete = (id) => {
    setUpdates(updates.filter((u) => u.id !== id))
  }

  return (
    <div className="relative">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Recent Updates</h3>
        <button
          onClick={handleAddNew}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add New Update
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {updates.map((update) => (
          <div key={update.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm">
            <img src={update.image || "/placeholder.svg"} alt={update.title} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h4 className="font-semibold text-gray-900 mb-2">{update.title}</h4>
              <p className="text-gray-600 text-sm mb-4">{update.content}</p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(update)}
                  className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(update.id)}
                  className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showSidebar && (
        <>
          <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={() => setShowSidebar(false)} />
          <div className="fixed right-0 top-0 h-full w-96 bg-white shadow-xl z-50 overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">
                  {editingUpdate?.title ? "Edit Update" : "Add New Update"}
                </h3>
                <button onClick={() => setShowSidebar(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                  <input
                    type="text"
                    value={editingUpdate?.title || ""}
                    onChange={(e) => setEditingUpdate({ ...editingUpdate, title: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                  <input
                    type="text"
                    value={editingUpdate?.image || ""}
                    onChange={(e) => setEditingUpdate({ ...editingUpdate, image: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Content</label>
                  <textarea
                    value={editingUpdate?.content || ""}
                    onChange={(e) => setEditingUpdate({ ...editingUpdate, content: e.target.value })}
                    rows={6}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <button
                  onClick={handleSave}
                  className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Save Update
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
