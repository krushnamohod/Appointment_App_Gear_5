"use client";

import React, { useEffect, useRef, useState } from "react";
import * as LucideIcons from "lucide-react";
import { Plus, Trash2, Upload } from "lucide-react";
import Button from "../uic/button.jsx";
import ActionButtons from "../uic/ActionButtons";
import Alert from "../uic/Alert";
import ImageUploader from "../uic/ImageUploader";
import ServiceCard from "../uic/aboutcard";
import FactsCard from "../uic/factscard.jsx";

function IconByName({ name, className = "h-6 w-6" }) {
  const IconComponent = LucideIcons[name];
  if (!IconComponent) return <LucideIcons.HelpCircle className={className} />; // fallback icon
  return <IconComponent className={className} />;
}

/* -----------------------------------------------------
   CONFIG - adjust these if necessary
----------------------------------------------------- */
const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";
const MEDIA_UPLOAD =
  "https://media.bizonance.in/api/v1/image/upload/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

const ABOUT_API = "https://api.kineed.in/api/about"; // GET (findFirst), POST (create), PUT /:id (update)

/* -----------------------------------------------------
   Icon options for dropdowns (strings saved to DB)
   Add/remove icon names here as needed.
----------------------------------------------------- */
const ICON_OPTIONS = [
  "Leaf",
  "LeafyGreen",
  "ThumbsUp",
  "ShieldCheck",
  "CheckCircle",
  "Award",
  "Users",
  "Globe",
  "Recycle",
];

/* -----------------------------------------------------
   Helpers
----------------------------------------------------- */
const makeTempId = () =>
  `temp-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

/* -----------------------------------------------------
   Main component
----------------------------------------------------- */
export default function AboutEditor() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  const [aboutId, setAboutId] = useState(null);

  const [heroTitle, setHeroTitle] = useState("");
  const [heroSubtitle, setHeroSubtitle] = useState("");

  // heroImages: array of { id: filename | tempId, preview }
  const [heroImages, setHeroImages] = useState([]);
  const heroFileRef = useRef(null);

  // services, values: array of { id, icon, title, description }
  const [services, setServices] = useState([]);
  const [values, setValues] = useState([]);

  // facts: array of { id, icon, value, label }
  const [facts, setFacts] = useState([]);

  // pending change tracker for media uploads & deletions
  const [pending, setPending] = useState({ uploads: [], deletions: [] });

  // Alert state
  const [alert, setAlert] = useState({
    show: false,
    message: "",
    type: "success",
  });

  /* -----------------------------------------------------
     Load existing About record (findFirst)
     Accepts multiple response shapes: raw object, { data: ... }, or array
  ----------------------------------------------------- */
  useEffect(() => {
    fetchAbout();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchAbout = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const res = await fetch(ABOUT_API, {
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      });
      if (!res.ok) throw new Error("Failed to fetch About");

      const json = await res.json();
      const payload = json?.data || json || null;
      const record = Array.isArray(payload) ? payload[0] : payload;

      if (!record) {
        // empty initial state
        setAboutId(null);
        setHeroTitle("");
        setHeroSubtitle("");
        setHeroImages([]);
        setServices([]);
        setValues([]);
        setFacts([]);
        setPending({ uploads: [], deletions: [] });
        return;
      }

      setAboutId(record.id || null);
      setHeroTitle(record.heroTitle || "");
      setHeroSubtitle(record.heroSubtitle || "");

      const hero = (record.heroImages || []).map((fn) => ({
        id: fn,
        preview: `${MEDIA_DOWNLOAD}/${fn}`,
      }));
      setHeroImages(hero);

      // services and values in DB use fields as created previously
      setServices(record.services || []);
      setValues(record.values || []);

      // facts
      setFacts(record.facts || []);

      setPending({ uploads: [], deletions: [] });
    } catch (err) {
      console.error("fetchAbout error:", err);
      setAlert({
        show: true,
        message: "Failed to load About data",
        type: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  /* -----------------------------------------------------
     Media upload helper
     returns uploaded filename or null
  ----------------------------------------------------- */
  const uploadToMedia = async (file) => {
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch(MEDIA_UPLOAD, { method: "POST", body: fd });
      if (!res.ok) {
        const txt = await res.text();
        console.error("Media upload failed:", txt);
        return null;
      }
      const json = await res.json();
      return json?.uploadedImages?.[0]?.filename || null;
    } catch (err) {
      console.error("uploadToMedia error:", err);
      return null;
    }
  };

  /* -----------------------------------------------------
     HERO IMAGES - add, delete
  ----------------------------------------------------- */
  const onHeroFilesSelected = (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    const newItems = files.map((file) => {
      const tempId = makeTempId();
      // add to pending uploads
      setPending((p) => ({
        ...p,
        uploads: [...p.uploads, { id: tempId, file }],
      }));
      return { id: tempId, preview: URL.createObjectURL(file) };
    });

    setHeroImages((prev) => [...prev, ...newItems]);
    e.target.value = "";
  };

  const triggerHeroInput = () => heroFileRef.current?.click();

  const deleteHeroImage = (id) => {
    const isTemp = id.startsWith("temp-");
    if (isTemp) {
      // simply remove from pending uploads and previews
      setPending((p) => ({
        ...p,
        uploads: p.uploads.filter((u) => u.id !== id),
      }));
      setHeroImages((prev) => prev.filter((h) => h.id !== id));
      return;
    }

    if (
      !confirm(
        "Remove this hero image? This will delete it from the carousel on save."
      )
    )
      return;

    setPending((p) => ({ ...p, deletions: [...p.deletions, id] }));
    setHeroImages((prev) => prev.filter((h) => h.id !== id));
  };

  /* -----------------------------------------------------
     CRUD for Services, Values, Facts
     Each add generates a temporary numeric id if DB id is absent.
  ----------------------------------------------------- */
  const makeItemId = (collection) => {
    const numbers = collection.map((i) => {
      // if id is UUID, keep as is; otherwise coerce to number when possible
      const asNum = Number(i.id);
      return Number.isFinite(asNum) ? asNum : 0;
    });
    return Math.max(0, ...numbers) + 1;
  };

  /* - Services - */
  const addService = () => {
    const newService = {
      id: makeItemId(services),
      icon: ICON_OPTIONS[0],
      title: "",
      description: "",
    };
    setServices((s) => [...s, newService]);
  };
  const updateService = (index, field, value) => {
    const copy = [...services];
    copy[index] = { ...copy[index], [field]: value };
    setServices(copy);
  };
  const removeService = (index) => {
    // if (!confirm("Remove this service?")) return;
    setServices((s) => s.filter((_, i) => i !== index));
  };

  /* - Values - */
  const addValue = () => {
    const newValue = {
      id: makeItemId(values),
      icon: ICON_OPTIONS[0],
      title: "",
      description: "",
    };
    setValues((v) => [...v, newValue]);
  };
  const updateValue = (index, field, value) => {
    const copy = [...values];
    copy[index] = { ...copy[index], [field]: value };
    setValues(copy);
  };
  const removeValue = (index) => {
    if (!confirm("Remove this value?")) return;
    setValues((v) => v.filter((_, i) => i !== index));
  };

  /* - Facts - */
  const addFact = () => {
    const newFact = {
      id: makeItemId(facts),
      icon: ICON_OPTIONS[0],
      value: "",
      label: "",
    };
    setFacts((f) => [...f, newFact]);
  };
  const updateFact = (index, field, value) => {
    const copy = [...facts];
    copy[index] = { ...copy[index], [field]: value };
    setFacts(copy);
  };
  const removeFact = (index) => {
    if (!confirm("Remove this fact?")) return;
    setFacts((f) => f.filter((_, i) => i !== index));
  };

  /* -----------------------------------------------------
     Save — upload pending files, construct final heroImages,
     and POST (create) or PUT (update) to API.
  ----------------------------------------------------- */
  const saveAll = async () => {
    try {
      setSaving(true);
      setAlert({ show: false, message: "", type: "success" });

      // 1) Upload pending files sequentially
      const uploads = [];
      for (const up of pending.uploads) {
        const filename = await uploadToMedia(up.file);
        if (!filename) throw new Error("Failed to upload one or more images");
        uploads.push({ tempId: up.id, filename });
      }
      const uploadMap = Object.fromEntries(
        uploads.map((u) => [u.tempId, u.filename])
      );

      // 2) Build final heroImages array
      let finalHero = heroImages
        .map((h) => (h.id.startsWith("temp-") ? uploadMap[h.id] : h.id))
        .filter(Boolean);
      finalHero = finalHero.filter((fn) => !pending.deletions.includes(fn));

      // 3) Prepare payload matching Prisma model
      const payload = {
        heroTitle,
        heroSubtitle,
        heroImages: finalHero,
        services: services.map((s) => ({
          id: s.id,
          icon: s.icon,
          title: s.title,
          description: s.description,
        })),
        values: values.map((v) => ({
          id: v.id,
          icon: v.icon,
          title: v.title,
          description: v.description,
        })),
        facts: facts.map((f) => ({
          id: f.id,
          icon: f.icon,
          value: f.value,
          label: f.label,
        })),
      };

      const token = localStorage.getItem("token");
      let res;
      if (aboutId) {
        res = await fetch(`${ABOUT_API}/${aboutId}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch(ABOUT_API, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify(payload),
        });
      }

      if (!res.ok) {
        const text = await res.text();
        console.error("Save returned error:", text);
        throw new Error("Failed to save About data");
      }

      setAlert({ show: true, message: "Saved successfully", type: "success" });
      // refresh server state to normalize IDs and ensure latest data
      await fetchAbout();
    } catch (err) {
      console.error("saveAll error:", err);
      setAlert({
        show: true,
        message: err.message || "Save failed",
        type: "error",
      });
    } finally {
      setSaving(false);
    }
  };

  const cancelAll = () => {
    if (!confirm("Discard unsaved changes?")) return;
    fetchAbout();
  };

  /* -----------------------------------------------------
     Simple change detector (naive)
  ----------------------------------------------------- */
  const hasChanges =
    pending.uploads.length > 0 ||
    pending.deletions.length > 0 ||
    // If any local item is present (initially empty arrays might match DB) we consider possible edits
    true;

  /* -----------------------------------------------------
     UI
  ----------------------------------------------------- */
  if (loading) {
    return (
      <div className="space-y-6 p-4">
        <div className="animate-pulse">
          <div className="h-8 bg-gradient-to-r from-gray-200 to-gray-300 rounded-lg w-1/3 mb-6"></div>
          <div className="grid md:grid-cols-2 gap-6">
            {[...Array(4)].map((_, i) => (
              <div
                key={i}
                className="bg-gradient-to-r from-gray-100 to-gray-200 rounded-xl p-6 h-40 shadow-sm"
              ></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30 p-4 lg:p-6 mb-30">
      <div className="max-w-7xl mx-auto space-y-6 ">
        {/* Alert */}
        {alert.show && (
          <div className="animate-fade-in">
            <Alert
              show={alert.show}
              message={alert.message}
              type={alert.type}
              onClose={() => setAlert({ ...alert, show: false })}
            />
          </div>
        )}

        {/* HERO SECTION */}
        <div className="bg-white  overflow-hidden ">
          <div className="  text-gray-700">
            <h3 className="text-xl font-bold  flex items-center gap-3">
              {/* <div className="w-2 h-6 bg-white rounded-full"></div> */}
              Hero Section
            </h3>
            <p className=" mt-1">
              Title, subtitle and carousel images for the main banner
            </p>
          </div>

          <div className="mt-5 space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Hero Title
                  </label>
                  <input
                    type="text"
                    value={heroTitle}
                    onChange={(e) => setHeroTitle(e.target.value)}
                    placeholder="Enter compelling hero title..."
                    disabled={previewMode}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white disabled:bg-gray-100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Hero Subtitle
                  </label>
                  <textarea
                    value={heroSubtitle}
                    onChange={(e) => setHeroSubtitle(e.target.value)}
                    rows={4}
                    placeholder="Brief description that supports the hero title..."
                    disabled={previewMode}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white resize-none disabled:bg-gray-100 scrollbar-custom"
                  />
                </div>
              </div>

              {/* Hero images uploader */}
              <div className="bg-gray-50 rounded-xl">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 gap-3">
                  <div>
                    <p className="font-semibold text-gray-800">
                      Hero Carousel Images
                    </p>
                    <p className="text-sm text-gray-600">
                      Recommended: 3-5 high-quality images
                    </p>
                  </div>
                  <div>
                    <input
                      ref={heroFileRef}
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      onChange={onHeroFilesSelected}
                    />
                    <button
                      onClick={triggerHeroInput}
                      disabled={previewMode}
                      className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 disabled:from-gray-400 disabled:to-gray-500 transition-all duration-200 shadow-md disabled:shadow-none"
                    >
                      <Upload className="w-4 h-4" />
                      Add Images
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4">
                  {heroImages.length === 0 && (
                    <div className="col-span-full text-center py-8 text-gray-500 bg-white rounded-lg border-2 border-dashed border-gray-300">
                      <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                      <p>No hero images yet</p>
                      <p className="text-sm">Add some images to get started</p>
                    </div>
                  )}
                  {heroImages.map((img) => (
                    <div
                      key={img.id}
                      className="relative group rounded-xl overflow-hidden transition-all duration-300 transform hover:-translate-y-1"
                    >
                      <img
                        src={img.preview}
                        alt="hero"
                        className="w-40 h-32 object-contain"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-200 flex items-center justify-center">
                        <button
                          onClick={() => deleteHeroImage(img.id)}
                          disabled={previewMode}
                          className="opacity-0 group-hover:opacity-100 transform scale-75 group-hover:scale-100 transition-all duration-200 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 disabled:hidden"
                          title="Delete image"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      {img.id.startsWith("temp-") && (
                        <div className="absolute top-2 left-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded-full font-semibold shadow-md">
                          New
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SERVICES */}
        <div className="bg-white overflow-hidden">
          <div className="">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="text-gray-700">
                <h3 className="text-xl font-bold flex items-center gap-3">
                  {/* <div className="w-2 h-6 bg-white rounded-full"></div> */}
                  Our Services
                </h3>
                <p className=" mt-1">
                  Showcase your company's services with icons and descriptions
                </p>
              </div>

              <Button text="Add Service" onClick={addService}></Button>
            </div>
          </div>

          <div className="p-6 lg:p-8">
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {services.length === 0 && (
                <div className="col-span-full text-center py-12">
                  <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <Plus className="w-10 h-10 text-gray-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">
                    No services yet
                  </h4>
                  <p className="text-gray-500 mb-4">
                    Start by adding your first service
                  </p>
                  <button
                    onClick={addService}
                    disabled={previewMode}
                    className="px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:bg-gray-400 transition-colors"
                  >
                    Add First Service
                  </button>
                </div>
              )}

              {services.map((service, idx) => (
                <ServiceCard
                  key={service.id ?? idx}
                  service={service}
                  index={idx}
                  updateService={updateService}
                  removeService={removeService}
                  previewMode={previewMode}
                  ICON_OPTIONS={ICON_OPTIONS}
                />
              ))}
            </div>
          </div>
        </div>

        {/* VALUES */}
        <div className="bg-white  overflow-hidden">
          <div className="">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="text-gray-700">
                <h3 className="text-xl font-bold flex items-center gap-3">
                  {/* <div className="w-2 h-6 bg-white rounded-full"></div> */}
                  Our Values
                </h3>
                <p className=" mt-1">
                  Define what makes your company unique and trustworthy
                </p>
              </div>
              <Button text="Add Value" onClick={addValue}></Button>
            </div>
          </div>

          <div className="p-6 lg:p-8">
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {values.length === 0 && (
                <div className="col-span-full text-center py-12">
                  <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <Plus className="w-10 h-10 text-gray-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">
                    No values yet
                  </h4>
                  <p className="text-gray-500 mb-4">
                    Define your company values
                  </p>
                  <button
                    onClick={addValue}
                    disabled={previewMode}
                    className="px-6 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 disabled:bg-gray-400 transition-colors"
                  >
                    Add First Value
                  </button>
                  {/* <Button text="Add First Value" onClick={addValue}></Button> */}
                </div>
              )}
              {values.map((v, idx) => (
                <ServiceCard
                  key={v.id ?? idx}
                  service={v}
                  index={idx}
                  updateService={updateService}
                  removeService={removeService}
                  previewMode={previewMode}
                  ICON_OPTIONS={ICON_OPTIONS}
                />
              ))}
            </div>
          </div>
        </div>

        {/* FACTS */}
        <div className="bg-white  overflow-hidden">
          <div className="">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="text-gray-700">
                <h3 className="text-xl font-bold  flex items-center gap-3">
                  {/* <div className="w-2 h-6 bg-white rounded-full"></div> */}
                  Facts & Figures
                </h3>
                <p className=" mt-1">
                  Impressive statistics that build credibility
                </p>
              </div>

              <Button text="Add Fact" onClick={addFact}></Button>
            </div>
          </div>

          <div className="p-6 lg:p-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {facts.length === 0 && (
                <div className="col-span-full text-center py-12">
                  <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <Plus className="w-10 h-10 text-gray-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">
                    No facts yet
                  </h4>
                  <p className="text-gray-500 mb-4">
                    Add some impressive statistics
                  </p>
                  <button
                    onClick={addFact}
                    disabled={previewMode}
                    className="px-6 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 disabled:bg-gray-400 transition-colors"
                  >
                    Add First Fact
                  </button>
                </div>
              )}
              {facts.map((f, idx) => (
                <FactsCard
                  key={f.id ?? idx}
                  fact={f}
                  index={idx}
                  updateFact={updateFact}
                  removeFact={removeFact}
                  previewMode={previewMode}
                  ICON_OPTIONS={ICON_OPTIONS}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Action Buttons */}
        <div className="">
          {/* SAVE/CANCEL */}
          <ActionButtons
            onSave={saveAll}
            onCancel={cancelAll}
            disabled={!hasChanges}
          />
        </div>
      </div>
    </div>
  );
}
