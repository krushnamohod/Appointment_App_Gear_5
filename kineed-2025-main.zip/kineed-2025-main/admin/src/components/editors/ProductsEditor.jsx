"use client";

import { useState } from "react";
import { Pencil, Plus, Trash2, X } from "lucide-react";
import { products as initialProducts } from "../lib/Products"; // Import your product data
import demoimage from "@/assets/1.jpg";

import Dropdown from "../Dropdown";

export default function ProductsEditor() {
  const [products, setProducts] = useState(initialProducts);
  const [showSidebar, setShowSidebar] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [filterCategory, setFilterCategory] = useState("");
  const [filterBrand, setFilterBrand] = useState("");

  const filteredProducts = products.filter((product) => {
    return (
      (filterCategory === "All Categories" ||
        filterCategory === "" ||
        product.category === filterCategory) &&
      (filterBrand === "All Brands" ||
        filterBrand === "" ||
        product.brand === filterBrand)
    );
  });

  // --- Handlers ---
  const handleEdit = (product) => {
    setEditingProduct({ ...product });
    setShowSidebar(true);
  };

  const handleAddNew = () => {
    setEditingProduct({
      id: Date.now(),
      name: "",
      originalPrice: "",
      price: "",
      rating: "",
      category: "",
      stock: "",
      sku: "",
      brand: "",
      colors: [],
      description: "",
      features: [],
      specifications: {},
      images: [],
      image: "",
    });
    setShowSidebar(true);
  };

  const handleSave = () => {
    if (editingProduct.id && products.find((p) => p.id === editingProduct.id)) {
      // Update existing product
      setProducts(
        products.map((p) => (p.id === editingProduct.id ? editingProduct : p))
      );
    } else {
      // Add new product
      setProducts([...products, editingProduct]);
    }
    setShowSidebar(false);
    setEditingProduct(null);
  };

  const handleDelete = (id) => {
    if (confirm("Are you sure you want to delete this product?")) {
      setProducts(products.filter((p) => p.id !== id));
    }
  };

  const handleArrayChange = (key, value, index) => {
    const updatedArray = [...(editingProduct[key] || [])];
    updatedArray[index] = value;
    setEditingProduct({ ...editingProduct, [key]: updatedArray });
  };

  const handleAddArrayItem = (key) => {
    const updatedArray = [...(editingProduct[key] || []), ""];
    setEditingProduct({ ...editingProduct, [key]: updatedArray });
  };

  const handleRemoveArrayItem = (key, index) => {
    const updatedArray = [...(editingProduct[key] || [])];
    updatedArray.splice(index, 1);
    setEditingProduct({ ...editingProduct, [key]: updatedArray });
  };

  const handleSpecChange = (field, value) => {
    setEditingProduct({
      ...editingProduct,
      specifications: { ...editingProduct.specifications, [field]: value },
    });
  };

  const handleAddSpecField = () => {
    setEditingProduct({
      ...editingProduct,
      specifications: { ...editingProduct.specifications, "New Field": "" },
    });
  };

  const handleRemoveSpecField = (field) => {
    const updatedSpecs = { ...editingProduct.specifications };
    delete updatedSpecs[field];
    setEditingProduct({ ...editingProduct, specifications: updatedSpecs });
  };

  // --- JSX ---
  return (
    <div className="relative p-2">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Products</h3>

        <div className="flex gap-4 mb-6 flex-wrap">
          <Dropdown
            label="Category"
            value={filterCategory}
            onChange={setFilterCategory}
            options={["All Categories", ...new Set(products.map((p) => p.category))]}
          />

          <Dropdown
            label="Brand"
            value={filterBrand}
            onChange={setFilterBrand}
            options={["All Brands", ...new Set(products.map((p) => p.brand))]}
          />

          <button
            onClick={handleAddNew}
            className="flex items-center gap-2 px-4 py-2 bg-blue-200 text-blue-900 rounded-lg hover:bg-blue-300 transition-colors"
          >
            {/* <Plus className="w-4 h-4" /> */}
            Add New Product
          </button>
        </div>
      </div>

      <div className="flex mx-auto flex-wrap justify-start gap-6">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="bg-white w-[200px] sm:w-[180px] xs:w-[150px] rounded-lg border border-gray-200 overflow-hidden shadow-sm flex-shrink-0 flex flex-col"
          >
            <div className="w-full h-40 flex items-center justify-center bg-gray-50">
              <img
                src={demoimage}
                alt={product.name}
                className="max-w-full max-h-full object-contain"
              />
            </div>
            <div className="p-4 flex flex-col flex-1">
              <h4 className="font-semibold text-sm text-gray-800 mb-1 truncate">
                {product.name}
              </h4>
              <p className="text-gray-600 text-xs font-bold mb-2">
                ${product.price}
              </p>
              <div className="flex justify-end gap-2 mt-auto">
                <button
                  onClick={() => handleEdit(product)}
                  className=" px-3 py-2 bg-blue-200 text-blue-900 rounded-lg hover:bg-blue-300 transition-colors text-sm"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(product.id)}
                  className="px-3 py-2 bg-red-200 text-red-900 rounded-lg hover:bg-red-300 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* --- Sidebar --- */}
      {showSidebar && (
        <>
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={() => setShowSidebar(false)}
          />
          <div className="fixed right-0 top-0 h-full w-full sm:w-100 bg-white shadow-xl z-50 overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">
                  {editingProduct?.name ? "Edit Product" : "Add New Product"}
                </h3>
                <button
                  onClick={() => setShowSidebar(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                {/* --- Basic Info --- */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Product Name
                  </label>
                  <input
                    type="text"
                    value={editingProduct?.name || ""}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        name: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Original Price
                    </label>
                    <input
                      type="number"
                      value={editingProduct?.originalPrice || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          originalPrice: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Price
                    </label>
                    <input
                      type="number"
                      value={editingProduct?.price || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          price: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rating
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={editingProduct?.rating || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          rating: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Stock
                    </label>
                    <input
                      type="number"
                      value={editingProduct?.stock || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          stock: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* --- Category, SKU, Brand, Colors --- */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <input
                      type="text"
                      value={editingProduct?.category || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          category: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      SKU
                    </label>
                    <input
                      type="text"
                      value={editingProduct?.sku || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          sku: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Brand
                    </label>
                    <input
                      type="text"
                      value={editingProduct?.brand || ""}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          brand: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Colors (comma separated)
                    </label>
                    <input
                      type="text"
                      value={(editingProduct?.colors || []).join(", ")}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          colors: e.target.value
                            .split(",")
                            .map((c) => c.trim()),
                        })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* --- Description --- */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    value={editingProduct?.description || ""}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        description: e.target.value,
                      })
                    }
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* --- Features --- */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Features
                  </label>
                  {(editingProduct?.features || []).map((feature, idx) => (
                    <div key={idx} className="flex gap-2 mb-2">
                      <input
                        type="text"
                        value={feature}
                        onChange={(e) =>
                          handleArrayChange("features", e.target.value, idx)
                        }
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        onClick={() => handleRemoveArrayItem("features", idx)}
                        className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => handleAddArrayItem("features")}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mt-2"
                  >
                    Add Feature
                  </button>
                </div>

                {/* --- Specifications --- */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Specifications
                  </label>
                  {Object.entries(editingProduct?.specifications || {}).map(
                    ([key, value], idx) => (
                      <div key={idx} className="flex gap-2 mb-2">
                        <input
                          type="text"
                          value={key}
                          onChange={(e) => {
                            const newKey = e.target.value;
                            const specs = { ...editingProduct.specifications };
                            specs[newKey] = specs[key];
                            if (newKey !== key) delete specs[key];
                            setEditingProduct({
                              ...editingProduct,
                              specifications: specs,
                            });
                          }}
                          className="w-1/3 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="text"
                          value={value}
                          onChange={(e) =>
                            handleSpecChange(key, e.target.value)
                          }
                          className="w-2/3 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <button
                          onClick={() => handleRemoveSpecField(key)}
                          className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )
                  )}
                  <button
                    onClick={handleAddSpecField}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mt-2"
                  >
                    Add Specification
                  </button>
                </div>

                {/* --- Images --- */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Images
                  </label>
                  {(editingProduct?.images || []).map((img, idx) => (
                    <div key={idx} className="flex gap-2 mb-2 items-center">
                      <input
                        type="text"
                        value={img}
                        onChange={(e) =>
                          handleArrayChange("images", e.target.value, idx)
                        }
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        onClick={() => handleRemoveArrayItem("images", idx)}
                        className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => handleAddArrayItem("images")}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mt-2"
                  >
                    Add Image
                  </button>
                </div>

                {/* --- Main Image --- */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Main Image
                  </label>
                  <input
                    type="text"
                    value={editingProduct?.image || ""}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        image: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <button
                  onClick={handleSave}
                  className="w-full px-4 py-3 bg-blue-200 text-blue-900 rounded-lg hover:bg-blue-300 transition-colors font-medium mt-4"
                >
                  Save Product
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
