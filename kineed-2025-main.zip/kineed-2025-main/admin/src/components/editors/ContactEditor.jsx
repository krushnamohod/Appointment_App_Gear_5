"use client"

import { useState, useEffect } from "react"
import { Facebook, Instagram, Twitter, Linkedin, Youtube, Phone, Globe, Clock } from "lucide-react"
import ActionButtons from "../uic/ActionButtons"

export default function ContactEditor() {
  const [contactInfo, setContactInfo] = useState({
    email: "",
    phone: "",
    address: "",
    businessDays: "",
    businessHours: "",
    facebook: "",
    instagram: "",
    twitter: "",
    linkedin: "",
    youtube: "",
    whatsapp: "",
    googleBusiness: "",
    secondaryPhone: ""
  })

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [activeTab, setActiveTab] = useState("basic")

  // ---------------------------------------------------
  // FETCH CONTACT INFO
  // ---------------------------------------------------
  const fetchContactInfo = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem("token")

      const response = await fetch("https://api.kineed.in/api/contact", {
        headers: { Authorization: `Bearer ${token}` }
      })

      if (!response.ok) throw new Error("Failed to fetch contact information")

      const data = await response.json()
      const info = data?.data?.contactInfo || {}

      setContactInfo({
        ...contactInfo,
        ...info,
        businessDays: info.businessDays || "",
        businessHours: info.businessHours || ""
      })

    } catch (err) {
      console.error(err)
      setError("Failed to load contact information")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchContactInfo()
  }, [])

  // ---------------------------------------------------
  // SAVE CONTACT INFO
  // ---------------------------------------------------
  const handleSave = async () => {
    setSaving(true)
    setError("")
    setSuccess("")

    try {
      const token = localStorage.getItem("token")

      const response = await fetch("https://api.kineed.in/api/contact", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(contactInfo)
      })

      const data = await response.json()

      if (!response.ok) throw new Error(data.message || "Failed to save contact information")

      setSuccess("Contact information saved successfully!")
      setTimeout(() => setSuccess(""), 3000)

    } catch (err) {
      setError(err.message || "Error saving contact information")
    } finally {
      setSaving(false)
    }
  }

  const handleInputChange = (field, value) => {
    setContactInfo((prev) => ({ ...prev, [field]: value }))
    if (error) setError("")
    if (success) setSuccess("")
  }

  const tabs = [
    { id: "basic", name: "Basic Info", icon: Phone },
    { id: "social", name: "Social Media", icon: Facebook },
    { id: "business", name: "Business", icon: Globe }
  ]

  // ---------------------------------------------------
  // LOADING UI
  // ---------------------------------------------------
  if (loading) {
    return (
      <div className="w-full animate-pulse">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="space-y-2 mb-4">
            <div className="h-4 bg-gray-200 w-1/4 rounded"></div>
            <div className="h-10 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    )
  }

  // ---------------------------------------------------
  // UI RENDER
  // ---------------------------------------------------
  return (
    <div className="max-w-6xl mx-auto">


      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-600">
          {success}
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">
          {error}
        </div>
      )}

      {/* TABS */}
      <div className="border-b mb-6">
        <nav className="flex space-x-8 -mb-px">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 flex items-center gap-2 text-sm ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.name}
              </button>
            )
          })}
        </nav>
      </div>

      {/* ---------------- BASIC TAB ---------------- */}
      {activeTab === "basic" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            <Input label="Email Address *" value={contactInfo.email} onChange={(v) => handleInputChange("email", v)} />

            <Input label="Primary Phone *" value={contactInfo.phone} onChange={(v) => handleInputChange("phone", v)} />

            <Input label="Secondary Phone" value={contactInfo.secondaryPhone} onChange={(v) => handleInputChange("secondaryPhone", v)} />

            <Input label="WhatsApp" value={contactInfo.whatsapp} onChange={(v) => handleInputChange("whatsapp", v)} />
          </div>

          {/* Address */}
          <div>
            <label className="text-sm font-medium mb-2 block">Business Address *</label>
            <textarea
              rows={3}
              className="w-full px-4 py-2 border rounded-lg"
              value={contactInfo.address}
              onChange={(e) => handleInputChange("address", e.target.value)}
            />
          </div>

          {/* Business Days + Hours */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            <Input
              label="Business Days"
              icon={Clock}
              value={contactInfo.businessDays}
              onChange={(v) => handleInputChange("businessDays", v)}
              placeholder="Mon–Sat / Everyday"
            />

            <Input
              label="Business Hours"
              icon={Clock}
              value={contactInfo.businessHours}
              onChange={(v) => handleInputChange("businessHours", v)}
              placeholder="10:00 AM – 7:00 PM"
            />
          </div>
        </div>
      )}

      {/* ---------------- SOCIAL TAB ---------------- */}
      {activeTab === "social" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <InputWithIcon label="Facebook URL" icon={Facebook} value={contactInfo.facebook} onChange={(v) => handleInputChange("facebook", v)} />
          <InputWithIcon label="Instagram URL" icon={Instagram} value={contactInfo.instagram} onChange={(v) => handleInputChange("instagram", v)} />
          <InputWithIcon label="Twitter URL" icon={Twitter} value={contactInfo.twitter} onChange={(v) => handleInputChange("twitter", v)} />
          <InputWithIcon label="LinkedIn URL" icon={Linkedin} value={contactInfo.linkedin} onChange={(v) => handleInputChange("linkedin", v)} />
          <InputWithIcon label="YouTube URL" icon={Youtube} value={contactInfo.youtube} onChange={(v) => handleInputChange("youtube", v)} />
        </div>
      )}

      {/* ---------------- BUSINESS TAB ---------------- */}
      {activeTab === "business" && (
        <Input label="Google Business Profile" value={contactInfo.googleBusiness} onChange={(v) => handleInputChange("googleBusiness", v)} />
      )}

      {/* SAVE + cancel */}
      
      <ActionButtons onSave={handleSave} onCancel={fetchContactInfo} saving={saving} />
    </div>
  )
}

/* -------------------------------- INPUT COMPONENTS ------------------------------ */

function Input({ label, icon: Icon, value, onChange, type = "text", placeholder }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2 flex items-center gap-2">
        {Icon && <Icon className="w-4 h-4 text-blue-600" />}
        {label}
      </label>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-2 border rounded-lg"
      />
    </div>
  )
}

function InputWithIcon({ label, icon: Icon, value, onChange }) {
  return <Input label={label} icon={Icon} value={value} onChange={onChange} />
}
