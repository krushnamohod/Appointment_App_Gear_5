"use client";

import { useEffect, useState } from "react";
import { Star, Eye, EyeOff, Trash2, LoaderCircle } from "lucide-react";
import ConfirmModal from "./uic/confirmdel";
import SectionHeader from "./uic/SectionHeader";
import FormattedDate from "./uic/FormattedDate";

export default function Reviews() {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  const [deleteId, setDeleteId] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const API_BASE_URL = "https://api.kineed.in/api/reviews";

  const fetchReviews = async () => {
    try {
      setLoading(true);
      const res = await fetch(API_BASE_URL);
      const data = await res.json();

      if (data.status === "success") {
        setReviews(data.data.reviews);
      }
    } catch (err) {
      console.error("Error fetching reviews:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, []);

  const openDeleteModal = (id) => {
    setDeleteId(id);
    setIsDeleteModalOpen(true);
  };

  const handleDeleteConfirm = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/${deleteId}`, {
        method: "DELETE",
      });

      if (res.ok) {
        setReviews((prev) => prev.filter((r) => r.id !== deleteId));
      }
    } catch (err) {
      console.error("Error deleting review:", err);
    } finally {
      setIsDeleteModalOpen(false);
      setDeleteId(null);
    }
  };

  const handleToggleWebsite = async (id, currentState) => {
    try {
      const res = await fetch(`${API_BASE_URL}/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ showOnWebsite: !currentState }),
      });

      const data = await res.json();

      if (res.ok && data.status === "success") {
        setReviews((prev) =>
          prev.map((r) =>
            r.id === id ? { ...r, showOnWebsite: !currentState } : r
          )
        );
      }
    } catch (err) {
      console.error("Error updating review:", err);
    }
  };

  const renderStars = (rating) => (
    <div className="flex gap-1">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-3 h-3 ${
            i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
          }`}
        />
      ))}
    </div>
  );

  if (loading)
    return (
      <div className="flex h-screen flex-col items-center justify-center py-10">
        <LoaderCircle className="animate-spin" />
        <p className="text-gray-700 font-medium text-center mt-3">
          Loading reviews, please wait...
        </p>
      </div>
    );

  return (
    <>
      <ConfirmModal
        open={isDeleteModalOpen}
        title="Delete Review?"
        message="This action is permanent and cannot be undone."
        onConfirm={handleDeleteConfirm}
        onCancel={() => setIsDeleteModalOpen(false)}
      />

      <div className="space-y-6 p-7">
        <SectionHeader
          title="Reviews"
          subtitle="Manage customer reviews and ratings"
        />

        {/* Auto-equal height grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 items-stretch">
          {reviews.map((review) => (
            <div
              key={review.id}
              className="bg-white relative rounded-lg border border-gray-200 p-3 shadow-sm hover:shadow-md transition-shadow duration-300 flex flex-col"
            >
              {/* Status Badge */}
              <span
                className={`absolute top-0 left-0 px-4 py-1 text-xs font-medium rounded-br-lg ${
                  review.showOnWebsite
                    ? "bg-blue-100 text-blue-800"
                    : "bg-gray-100 text-gray-700"
                }`}
              >
                {review.showOnWebsite ? "Visible on site" : "Hidden"}
              </span>

              <div className="flex-1 mt-6 flex flex-col">
                <h3 className="font-semibold text-gray-900 text-md">
                  {review.customerName || review.customer}
                </h3>

                <div className="mt-2">{renderStars(review.rating)}</div>

                {/* Auto-height description */}
                <p className="text-gray-700 break-words mt-3 text-xs">
                  {review.comment.length > 200
                    ? review.comment.slice(0, 200) + "..."
                    : review.comment}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between gap-3 mt-4">
                {/* Date at bottom */}
                <div className="">
                  <p className="text-xs sm:text-sm text-gray-500">
                    <FormattedDate date={review.createdAt} />
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() =>
                      handleToggleWebsite(review.id, review.showOnWebsite)
                    }
                    className={`flex items-center text-xs gap-2 px-3 py-2 rounded-lg justify-center transition-colors ${
                      review.showOnWebsite
                        ? "bg-gray-100 text-gray-800 hover:bg-gray-200"
                        : "bg-gray-400 text-white hover:bg-gray-500"
                    }`}
                  >
                    {review.showOnWebsite ? (
                      <Eye className="w-4 h-4" />
                    ) : (
                      <EyeOff className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={() => openDeleteModal(review.id)}
                    className="flex items-center gap-2 px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-400 hover:text-white transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
