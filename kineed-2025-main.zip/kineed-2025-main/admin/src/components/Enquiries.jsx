"use client";

import { useEffect, useState } from "react";
import { Mail, Phone, Calendar, ChevronDown, ChevronUp } from "lucide-react";
import Button from "./uic/button";
import SectionHeader from "./uic/SectionHeader";
import FormattedDate from "./uic/FormattedDate";

export default function Enquiries() {
  const [enquiries, setEnquiries] = useState([]);
  const [expandedId, setExpandedId] = useState(null);
  const [loading, setLoading] = useState(true);

  const API_URL = "https://api.kineed.in/api/enquiries";

  useEffect(() => {
    fetchEnquiries();
  }, []);

  // -----------------------
  // FETCH ENQUIRIES
  // -----------------------
  const fetchEnquiries = async () => {
    try {
      setLoading(true);
      const res = await fetch(API_URL);
      const data = await res.json();

      if (res.ok && data.status === "success") {
        setEnquiries(data.data.enquiries);
      }
    } catch (err) {
      console.error("Failed to fetch enquiries", err);
    } finally {
      setLoading(false);
    }
  };

  // -----------------------
  // TOGGLE EXPAND CARD
  // -----------------------
  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  // -----------------------
  // REPLY VIA WHATSAPP
  // -----------------------
  const sendWhatsAppReply = (enquiry) => {
    const phone = enquiry.phone.replace(/[^0-9]/g, "");

    const message = encodeURIComponent(
      `Hello ${enquiry.name},\n\nRegarding your enquiry: "${enquiry.subject}"\n\n${enquiry.message}\n\nHow may I assist you further?`
    );

    window.open(`https://wa.me/${phone}?text=${message}`, "_blank");
  };

  // -----------------------
  // UPDATE STATUS (dynamic)
  // -----------------------
  const updateStatus = async (id, status) => {
    try {
      const res = await fetch(`${API_URL}/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (res.ok) await fetchEnquiries();
    } catch (err) {
      console.error("Failed to update enquiry", err);
    }
  };

  if (loading) {
    return (
      <div className="p-7 text-center text-gray-500">Loading enquiries...</div>
    );
  }

  return (
    <div className="space-y-6 p-7">
      <SectionHeader
        title="Customer Support"
        subtitle="Manage customer enquiries and support requests"
      />

      {enquiries.length === 0 && !loading && (
        <div className="p-10 text-center text-gray-500 text-sm  border-gray-200 rounded-lg bg-gray-50">
          No enquiries found.
        </div>
      )}

      <div className="grid gap-4">
        {enquiries.map((enquiry) => {
          const isExpanded = expandedId === enquiry.id;

          return (
            <div
              key={enquiry.id}
              onClick={() => toggleExpand(enquiry.id)}
              className="bg-white  rounded-lg border border-gray-200 shadow-sm overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-gray-900 text-md">
                        {enquiry.name}
                      </h3>

                      <span
                        className={`px-3 py-1 text-xs font-medium rounded-full ${
                          enquiry.status === "NEW"
                            ? "bg-blue-100 text-blue-800"
                            : enquiry.status === "IN_PROGRESS"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                        }`}
                      >
                        {enquiry.status.replace("_", " ")}
                      </span>
                    </div>

                    <p className="text-gray-700 text-sm font-medium mb-3">
                      {enquiry.subject}
                    </p>

                    <div className="flex flex-wrap gap-4 text-xs text-gray-600">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        {enquiry.email}
                      </div>

                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4" />
                        {enquiry.phone}
                      </div>

                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <FormattedDate date={enquiry.createdAt} />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleExpand(enquiry.id)}
                    className="ml-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-gray-600" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-600" />
                    )}
                  </button>
                </div>

                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h4 className="font-medium text-sm text-gray-900 mb-2">
                      Message:
                    </h4>
                    <p className="text-gray-700 mb-4 text-sm">
                      {enquiry.message}
                    </p>

                    <div className="flex gap-2 flex-wrap">
                      <Button
                        text="Reply on WhatsApp"
                        variant="blue"
                        onClick={() => sendWhatsAppReply(enquiry)}
                      />

                      <Button
                        text="Mark In-Progress"
                        variant="yellow"
                        onClick={() => updateStatus(enquiry.id, "IN_PROGRESS")}
                      />

                      <Button
                        text="Mark Resolved"
                        variant="green"
                        onClick={() => updateStatus(enquiry.id, "RESOLVED")}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
