import React, { useState, useEffect } from "react";
import Help from "./Helpcenter.jsx";
import { LogOut, Menu } from "lucide-react";
import bizologo from "../assets/bizonance_logo.png";
import { useNavigate } from "react-router-dom";

/* MEDIA SERVER */
const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

const Navbar = ({ isSidebarOpen, setIsSidebarOpen }) => {
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);

  // ------------------------------
  // Dynamic Logo
  // ------------------------------
  const [dynamicLogo, setDynamicLogo] = useState(null);

  useEffect(() => {
    fetchLogo();
  }, []);

  const fetchLogo = async () => {
    try {
      const res = await fetch("https://api.kineed.in/api/home");
      if (!res.ok) return;

      const { data } = await res.json();
      const home = data?.[0];

      if (home?.logo) {
        setDynamicLogo(`${MEDIA_DOWNLOAD}/${home.logo}`);
      } else {
        setDynamicLogo(null);
      }
    } catch (err) {
      console.error("Error fetching logo:", err);
    }
  };

  // ------------------------------
  // Logout
  // ------------------------------
  const handleLogout = () => setShowConfirm(true);

  const confirmLogout = () => {
    setShowConfirm(false);
    localStorage.removeItem("token");
    localStorage.removeItem("admin");
    navigate("/");
  };

  return (
    <div className="relative navbar flex items-center justify-between p-4 h-[80px]">
      {/* LEFT SIDE */}
      <div className="flex items-center space-x-4">
        <Menu
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          size={50}
          className={` rounded-full hover:bg-gray-200 h-10 w-10 p-2 cursor-pointer ${
            isSidebarOpen ? "bg-gray-100" : "bg-transparent"
          }`}
        />

        {/* Dynamic Logo */}
        {dynamicLogo ? (
          <img
            src={dynamicLogo}
            className="h-[40px] object-contain"
            alt="Logo"
          />
        ) : (
          <span className="text-2xl font-medium text-gray-700">
            KINEED Kitchen Appliances
          </span>
        )}
      </div>

      {/* RIGHT SIDE - Bizo Logo Dropdown */}
      <div className="relative group inline-block">
        <img
          src={bizologo}
          alt="Bizonance Logo"
          className="h-10 w-10 cursor-pointer rounded-full hover:ring-2 hover:ring-gray-300"
        />

        <div className="absolute -left-36 mt-0 opacity-0 invisible group-hover:opacity-100 group-hover:visible w-44 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
          <ul className="py-2 text-gray-700">
            <li
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 cursor-pointer"
            >
              <LogOut size={18} /> Logout
            </li>
          </ul>
        </div>
      </div>

      {/* LOGOUT CONFIRMATION MODAL */}
      {showConfirm && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg text-center">
            <p className="text-lg font-semibold">
              Are you sure you want to log out?
            </p>

            <div className="flex justify-center mt-4 space-x-4">
              <button
                onClick={confirmLogout}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
              >
                Logout
              </button>

              <button
                onClick={() => setShowConfirm(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Border Colors */}
      <div className="absolute bottom-0 left-0 w-full flex h-[6px]">
        <div className="w-1/3 bg-gradient-to-r from-yellow-300 to-orange-400"></div>
        <div className="w-1/3 bg-blue-800"></div>
        <div className="w-1/3 bg-red-600"></div>
      </div>
    </div>
  );
};

export default Navbar;
