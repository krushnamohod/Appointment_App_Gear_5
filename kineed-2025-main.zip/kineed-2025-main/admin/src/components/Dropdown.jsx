import { useState, useRef, useEffect } from "react";
import { ChevronDown, Check } from "lucide-react";

export default function Dropdown({ options, value, onChange, label, footer }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (ref.current && !ref.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div ref={ref} className="relative w-[180px] ">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full px-4 whitespace-nowrap py-2 border border-gray-300 rounded-lg bg-white flex justify-between items-center focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <span>{value || `${label}`}</span>
        <ChevronDown
          className={`w-4 h-4 text-gray-500 transition-transform duration-200 ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      {open && (
        <ul className="absolute z-50 mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto scrollbar-hide">
          {/* Footer slot: render whatever parent passes */}
          {footer && <li className=" border-t">{footer}</li>}
          {options.map((opt) => (
            <li 
              key={opt}
              onClick={() => {
                onChange(opt);
                setOpen(false);
              }}
              className={`cursor-pointer px-4 py-2 hover:bg-blue-100 flex justify-between items-center ${
                value === opt ? "bg-blue-100" : ""
              }`}
            >
              {opt}
              {value === opt && <Check className="w-4 h-4 text-blue-500" />}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
