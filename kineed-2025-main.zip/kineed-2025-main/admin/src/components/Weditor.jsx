"use client";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home,
  Info,
  Package,
  Phone,
  BookOpen,
  Newspaper,
  ImageIcon,
  X,
} from "lucide-react";
import HomepageEditor from "./editors/HomepageEditor";
import AboutEditor from "./editors/AboutEditor";
import ProductsEditor from "./editors/ProductsEditor";
import ContactEditor from "./editors/ContactEditor";
import SuccessStoriesEditor from "./editors/SuccessStoriesEditor";
import RecentUpdatesEditor from "./editors/RecentUpdatesEditor";

import SectionHeader from "./uic/SectionHeader";

const Weditor = () => {
  const [activeSection, setActiveSection] = useState(null);

  useEffect(() => {
    setActiveSection(null);
  }, []);

  const sections = [
    {
      id: "homepage",
      title: "Homepage",
      icon: <Home size={22} />,
      desc: "Edit homepage banners and content",
      action: "Customize Homepage",
      content: <HomepageEditor />,
    },
    {
      id: "aboutpage",
      title: "About Section",
      icon: <Info size={22} />,
      desc: "Manage company details and mission",
      action: "Edit About Section",
      content: <AboutEditor />,
    },
    // {
    //   id: "products",
    //   title: "Products",
    //   icon: <Package size={22} />,
    //   desc: "Add or edit your product listings",
    //   action: "Manage Products",
    //   content: <ProductsEditor />,
    // },
    {
      id: "contact",
      title: "Contacts",
      icon: <Phone size={22} />,
      desc: "Edit contact details and form settings",
      action: "Update Contacts",
      content: <ContactEditor />,
    },
    {
      id: "success-stories",
      title: "Policy & Terms",
      icon: <BookOpen size={22} />,
      desc: "Manage policy documents and terms",
      action: "Manage Policies",
      content: <SuccessStoriesEditor />,
    },
    // {
    //   id: "recent-updates",
    //   title: "Recent Updates",
    //   icon: <Newspaper size={22} />,
    //   desc: "Post new updates and announcements",
    //   action: "Add Updates",
    //   content: <RecentUpdatesEditor />,
    // },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}

        <SectionHeader
          title="Website Sections"
          subtitle="Select a section to edit its content and settings."
        />

        {/* Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 mb-8 sm:mb-12 lg:mb-16">
          {sections.map((section, index) => (
            <motion.div
              key={section.id}
              whileHover={{ y: -6, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.2 }}
              onClick={() => setActiveSection(section.id)}
              className="group relative overflow-hidden bg-white/80 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 border cursor-pointer transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 group-hover:bg-blue-600 group-hover:text-white text-blue-700 p-2 sm:p-3 rounded-lg sm:rounded-xl transition-all">
                    {section.icon}
                  </div>
                  <h2 className="text-base sm:text-lg font-semibold text-gray-900">
                    {section.title}
                  </h2>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-gray-500 mb-3 sm:mb-4">
                {section.desc}
              </p>
              <div className="flex items-center text-xs sm:text-sm text-blue-600 font-medium">
                <span>{section.action}</span>
              </div>

              {/* Gradient border accent */}
              <div className="absolute inset-x-0 bottom-0 h-1 rounded-b-xl sm:rounded-b-2xl bg-gradient-to-r from-blue-500 via-sky-400 to-indigo-500"></div>
            </motion.div>
          ))}
        </div>

        {/* Animated Side Panel */}
        <AnimatePresence>
          {activeSection && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black z-40"
                onClick={() => setActiveSection(null)}
              />
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 20, stiffness: 250 }}
                className="fixed top-0 right-0 h-full w-full max-w-6xl bg-white z-50 shadow-2xl overflow-hidden"
              >
                <div className="h-full flex flex-col">
                  {/* Panel Header */}
                  <div className="flex-shrink-0 p-4 sm:p-6 border-b border-gray-200 flex items-center justify-between bg-gray-50">
                    <h2 className="text-lg sm:text-xl font-semibold text-gray-900">
                      {sections.find((s) => s.id === activeSection)?.title}
                    </h2>
                    <button
                      onClick={() => setActiveSection(null)}
                      className="p-2 rounded-full hover:bg-gray-200 transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>

                  {/* Scrollable Content Area */}
                  <div className="flex-1 overflow-hidden">
                    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8 bg-white">
                      {sections.find((s) => s.id === activeSection)?.content}
                    </div>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Weditor;
