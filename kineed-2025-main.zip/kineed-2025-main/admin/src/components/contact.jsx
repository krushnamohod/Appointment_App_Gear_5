"use client"

import { useState, useEffect } from "react"
import { Facebook, Instagram, Twitter, Linkedin, Youtube, MessageCircle, Phone, Globe, MapPin, Clock } from "lucide-react"

export default function ContactEditor() {
  const [contactInfo, setContactInfo] = useState({
    // Basic Contact Info
    email: "",
    phone: "",
    address: "",
    
    // Updated Business Hours (split fields)
    businessDays: "",
    businessHours: "",
    
    // Social Media
    facebook: "",
    instagram: "",
    twitter: "",
    linkedin: "",
    youtube: "",
    
    // Messaging Apps
    whatsapp: "",
    
    // Business Profiles
    googleBusiness: "",
    
    // Additional Contact Methods
    secondaryPhone: ""
  })
  
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [activeTab, setActiveTab] = useState("basic")

  // Fetch contact information from backend
  const fetchContactInfo = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('token')
      const response = await fetch('https://api.kineed.in/api/contact', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        throw new Error('Failed to fetch contact information')
      }

      const data = await response.json()
      if (data.status === 'success') {
        // Patch support for old "businessHours"
        const info = data.data.contactInfo || {}

        setContactInfo({
          ...info,
          businessDays: info.businessDays || "",
          businessHours: info.businessHours || "",
        })
      }
    } catch (error) {
      console.error('Error fetching contact info:', error)
      setError('Failed to load contact information')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchContactInfo()
  }, [])

  const handleSave = async () => {
    setSaving(true)
    setError("")
    setSuccess("")

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('https://api.kineed.in/api/contact', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(contactInfo),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || 'Failed to save contact information')
      }

      if (data.status === 'success') {
        setSuccess("Contact information saved successfully!")
        setTimeout(() => setSuccess(""), 3000)
      }
    } catch (error) {
      console.error('Error saving contact info:', error)
      setError(error.message || "Error saving contact information")
    } finally {
      setSaving(false)
    }
  }

  const handleInputChange = (field, value) => {
    setContactInfo(prev => ({
      ...prev,
      [field]: value
    }))
    if (error) setError("")
    if (success) setSuccess("")
  }

  const tabs = [
    { id: "basic", name: "Basic Info", icon: Phone },
    { id: "social", name: "Social Media", icon: Facebook },
    { id: "business", name: "Business", icon: Globe }
  ]

  if (loading) {
    return (
      <div className="w-full">
        <div className="animate-pulse space-y-4">
          {[...Array(8)].map((_, i) => (
            <div key={i}>
              <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
              <div className="h-10 bg-gray-200 rounded"></div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Contact Information</h3>

      {/* Success Message */}
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-sm text-green-600">{success}</p>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.name}
              </button>
            )
          })}
        </nav>
      </div>

      <div className="space-y-6">
        
        {/* Basic Contact Info Tab */}
        {activeTab === "basic" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={contactInfo.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="contact@example.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Primary Phone *
                </label>
                <input
                  type="tel"
                  value={contactInfo.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="9876543210"
                  maxLength={10}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Secondary Phone
                </label>
                <input
                  type="tel"
                  value={contactInfo.secondaryPhone}
                  onChange={(e) => handleInputChange('secondaryPhone', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="9876543210"
                  maxLength={10}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  WhatsApp
                </label>
                <input
                  type="tel"
                  value={contactInfo.whatsapp}
                  onChange={(e) => handleInputChange('whatsapp', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="9876543210"
                  maxLength={10}
                />
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Business Address *
              </label>
              <textarea
                value={contactInfo.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="123 Main St, City, Country"
                required
              />
            </div>

            {/* BUSINESS HOURS – Updated UI */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  Business Days
                </label>
                <input
                  type="text"
                  value={contactInfo.businessDays}
                  onChange={(e) => handleInputChange('businessDays', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Mon–Fri / Everyday / Weekends"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  Business Time
                </label>
                <input
                  type="text"
                  value={contactInfo.businesshours}
                  onChange={(e) => handleInputChange('businessTime', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="9:00 AM – 6:00 PM"
                />
              </div>

            </div>

          </div>
        )}

        {/* Social Media Tab */}
        {activeTab === "social" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Facebook className="w-4 h-4 text-blue-600" />
                  Facebook URL
                </label>
                <input
                  type="url"
                  value={contactInfo.facebook}
                  onChange={(e) => handleInputChange('facebook', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://facebook.com/yourbusiness"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Instagram className="w-4 h-4 text-pink-600" />
                  Instagram URL
                </label>
                <input
                  type="url"
                  value={contactInfo.instagram}
                  onChange={(e) => handleInputChange('instagram', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://instagram.com/yourbusiness"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Twitter className="w-4 h-4 text-blue-400" />
                  Twitter URL
                </label>
                <input
                  type="url"
                  value={contactInfo.twitter}
                  onChange={(e) => handleInputChange('twitter', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://twitter.com/yourbusiness"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Linkedin className="w-4 h-4 text-blue-700" />
                  LinkedIn URL
                </label>
                <input
                  type="url"
                  value={contactInfo.linkedin}
                  onChange={(e) => handleInputChange('linkedin', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://linkedin.com/company/yourbusiness"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  <Youtube className="w-4 h-4 text-red-600" />
                  YouTube URL
                </label>
                <input
                  type="url"
                  value={contactInfo.youtube}
                  onChange={(e) => handleInputChange('youtube', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://youtube.com/yourbusiness"
                />
              </div>

            </div>
          </div>
        )}

        {/* Business Tab */}
        {activeTab === "business" && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Google Business Profile
              </label>
              <input
                type="url"
                value={contactInfo.googleBusiness}
                onChange={(e) => handleInputChange('googleBusiness', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="https://g.page/your-business"
              />
            </div>
          </div>
        )}

        {/* Save Reset */}
        <div className="flex gap-4 pt-6 border-t">
          <button
            onClick={handleSave}
            disabled={saving || !contactInfo.email || !contactInfo.phone || !contactInfo.address}
            className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed transition-colors font-medium flex items-center gap-2"
          >
            {saving ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Saving...
              </>
            ) : (
              "Save All Changes"
            )}
          </button>

          <button
            onClick={fetchContactInfo}
            type="button"
            className="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
          >
            Reset Changes
          </button>
        </div>

      </div>
    </div>
  )
}
