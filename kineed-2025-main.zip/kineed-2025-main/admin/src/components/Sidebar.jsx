"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Users,
  Eye,
  CircleHelp,
  LayoutDashboard,
  ShoppingCart,
  NotebookPen,
  FilePenLine,
  Package,
  Menu,
  X,
} from "lucide-react";

import Orders from "./Orders.jsx";
import Reviews from "./Reviews.jsx";
import Dashboard from "./Dashboard.jsx";
import Siteframe from "./siteframe.jsx";
import Help from "./Helpcenter.jsx";
import Websiteeditor from "./Weditor.jsx";
import Categorybrands from "./categoriesbrands.jsx";
import Enquiries from "./Enquiries.jsx";
import ProductsEditor from "./ProductsEditor.jsx";
import Contactform from "./contactform.jsx";
import BlogsDashboard from "./blogs.jsx";


/* ------------------------------------------------------
   Only add bottom:true here for bottom mobile bar
------------------------------------------------------ */
const sidebarItems = [
  { title: "Dashboard", Icon: LayoutDashboard, Content: Dashboard , bottom: true },
  { title: "Orders", Icon: ShoppingCart, Content: Orders , bottom: true },
  { title: "Reviews", Icon: Users, Content: Reviews , bottom: true },
  { title: "Customer Support", Icon: NotebookPen, Content: Enquiries , bottom: true },
  { title: "Contact Messages", Icon: NotebookPen, Content: Contactform },
  { title: "Categories & Brands", Icon: Package, Content: Categorybrands },

  { title: "Products", Icon: Package, Content: ProductsEditor  },
  { title: "Website Editor", Icon: FilePenLine, Content: Websiteeditor },
  { title: "Blogs", Icon: NotebookPen, Content: BlogsDashboard },

  { title: "Site Preview", Icon: Eye, Content: Siteframe },
  { title: "Help Center", Icon: CircleHelp, Content: Help },
];

function Sidebar({ isOpen: propIsOpen }) {
  const [activeContent, setActiveContent] = useState("Dashboard");
  const [isMobile, setIsMobile] = useState(false);
  const [isOpen, setIsOpen] = useState(propIsOpen);

  const bottomItems = sidebarItems.filter((i) => i.bottom);

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) setIsOpen(false);   // sidebar hidden on mobile
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  useEffect(() => {
    if (!isMobile) setIsOpen(propIsOpen);
  }, [propIsOpen, isMobile]);

  const getContent = (title) => {
    const item = sidebarItems.find((item) => item.title === title);
    return item ? <item.Content setActiveContent={setActiveContent} /> : null;
  };

  const renderSidebarButton = (item, index) => {
    const isActive = activeContent === item.title;

    return (
      <motion.div
        key={index}
        className="relative group"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <button
          onClick={() => {
            setActiveContent(item.title);
            if (isMobile) setIsOpen(false);
          }}
          className={`flex items-center ${
            isOpen
              ? "justify-start space-x-3 whitespace-nowrap"
              : "justify-center"
          } py-2 px-4 rounded-r-full text-sm w-full ${
            isActive
              ? "bg-blue-400/30 text-blue-950"
              : "text-gray-700 hover:bg-gray-200"
          }`}
        >
          <item.Icon className="w-4 h-4" />
          {isOpen && (
            <motion.span
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="font-medium"
            >
              {item.title}
            </motion.span>
          )}
        </button>
      </motion.div>
    );
  };

  const renderMobileTab = (item, index) => {
    const isActive = activeContent === item.title;

    return (
      <motion.div
        key={index}
        className="flex mx-auto items-center  justify-center px-2"
        whileTap={{ scale: 0.95 }}
      >
        <button
          onClick={() => setActiveContent(item.title)}
          className={`flex flex-col items-center justify-center w-full py-2 px-1 ${
            isActive ? "text-blue-800" : "text-gray-500"
          }`}
        >
          <item.Icon className="w-5 h-5 mb-1" />
          <span className="text-xs truncate">{item.title}</span>
        </button>
      </motion.div>
    );
  };

  return (
    <div className="relative h-full">

      {/* Mobile menu button */}
      {isMobile && !isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed top-4 left-4 z-50 p-2 bg-white rounded-full "
        >
          <Menu className="w-6 h-6" />
        </button>
      )}

      {/* Desktop Layout */}
      {!isMobile && (
        <div className="flex h-[calc(100vh-5rem)]">
          <motion.div
            className="sidebar flex flex-col border-r-2 pt-8 bg-white z-10"
            animate={{
              width: isOpen ? "16rem" : "5rem",
            }}
            transition={{
              type: "spring",
              damping: 25,
              stiffness: 300,
            }}
          >
            {sidebarItems.map((item, index) =>
              renderSidebarButton(item, index)
            )}
          </motion.div>

          <div className="content flex-1 bg-white overflow-y-scroll">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeContent}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.2 }}
              >
                {getContent(activeContent)}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Mobile Layout */}
      {isMobile && (
        <div className="flex flex-col h-full">

          {/* Mobile Sidebar Drawer */}
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ x: -300 }}
                animate={{ x: 0 }}
                exit={{ x: -300 }}
                transition={{ type: "spring", stiffness: 260, damping: 25 }}
                className="fixed top-0 left-0 h-full w-80 bg-white shadow-xl z-50 border-r overflow-y-auto"
              >
                <button
                  onClick={() => setIsOpen(false)}
                  className="absolute top-4 right-4 p-2 bg-white rounded-full shadow"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="pt-20 space-y-1">
                  {sidebarItems.map((item, index) =>
                    renderSidebarButton(item, index)
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Content */}
          <div className="flex-1 overflow-auto pb-16">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeContent}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.2 }}
              >
                {getContent(activeContent)}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Mobile Bottom Bar → ONLY bottom:true items */}
          <motion.div
            className="fixed p-2 bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 shadow-lg"
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            <div className="flex overflow-x-auto no-scrollbar">
              {bottomItems.map((item, index) => renderMobileTab(item, index))}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

export default Sidebar;
