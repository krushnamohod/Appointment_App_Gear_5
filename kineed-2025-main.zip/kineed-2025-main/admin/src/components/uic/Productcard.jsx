"use client";

import {
  Pencil,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle,
  GripVertical,
} from "lucide-react";

export default function ProductCard({
  product,
  imageUrl,
  handleEdit,
  handleDelete,
  handleToggleVisibility,
  handleToggleStock,
  dragRef, // <== NEW
  dragListeners,
}) {
  return (
    <div
      key={product.id}
      className="flex flex-col bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden w-full cursor-pointer max-w-[260px] sm:max-w-[280px] mx-auto transition-transform hover:scale-[1.02]"
    >
      {/* Image Section */}
      <div className="relative w-full h-20 sm:h-32 bg-gray-50 flex items-center justify-center">
        <img
          src={imageUrl}
          alt={product.name}
          className="max-h-full max-w-full object-contain p-3"
        />

        <div
          className="absolute top-0 right-0 p-3"
          ref={dragRef}
          {...dragListeners}
        >
          {" "}
          <GripVertical className="text-gray-600" />
        </div>
      </div>

      {/* Product Info */}
      <div className="flex flex-col justify-between flex-1 p-4">
        <div>
          <h4
            className="
    font-medium text-sm text-gray-800 mb-1
    leading-snug
    min-h-[2.5rem]
  "
          >
            {product.name}
          </h4>
          <p className="text-xs text-gray-600 font-medium">₹ {product.price}</p>
        </div>

        {/* Action Buttons - Fully Responsive */}
        <div
          className="
          grid 
          grid-cols-2 
          sm:grid-cols-4 
          gap-2 
          mt-4
        "
        >
          {/* Edit */}
          <button
            onClick={() => handleEdit(product)}
            className="w-full px-3 py-3 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 flex items-center justify-center transition-colors"
            title="Edit Product"
          >
            <Pencil className="w-4 h-4" />
          </button>

          {/* Stock Toggle */}
          <button
            onClick={() => handleToggleStock(product.id)}
            className={`w-full px-3 py-3 rounded-lg flex items-center justify-center transition-colors ${
              product.inStock
                ? "bg-green-100 text-green-800 hover:bg-green-200"
                : "bg-red-300 text-red-800 hover:bg-red-200"
            }`}
            title={product.inStock ? "Mark Out of Stock" : "Mark In Stock"}
          >
            <CheckCircle className="w-4 h-4" />
          </button>

          {/* Hide/Show */}
          <button
            onClick={() => handleToggleVisibility(product.id)}
            className={`w-full px-3 py-3 rounded-lg flex items-center justify-center transition-colors ${
              product.isActive
                ? "bg-gray-100 text-gray-800 hover:bg-gray-200"
                : "bg-gray-400 text-white hover:bg-gray-500"
            }`}
            title={product.isActive ? "Hide Product" : "Show Product"}
          >
            {product.isActive ? (
              <Eye className="w-4 h-4" />
            ) : (
              <EyeOff className="w-4 h-4" />
            )}
          </button>

          {/* Delete */}
          <button
            onClick={() => handleDelete(product.id)}
            className="w-full px-3 py-3 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 flex items-center justify-center transition-colors"
            title="Delete Product"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
