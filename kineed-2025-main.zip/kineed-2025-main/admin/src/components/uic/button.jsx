"use client";

export default function Button({ 
  text, 
  onClick, 
  className = "", 
  variant = "gray" // default is blue
}) {
  const baseStyles = `
    flex items-center justify-center gap-2 px-4 py-2 
    rounded-lg transition-colors whitespace-nowrap text-xs md:text-sm
  `;

  const variants = {
    blue: "bg-blue-200 text-blue-900 hover:bg-blue-300",
    gray: "bg-gray-200 text-gray-900 hover:bg-gray-300",
  };

  return (
    <button
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${className}`}
    >
      {text}
    </button>
  );
}
