"use client";
import { useRef, useState } from "react";
import { Plus, RotateCcw, Trash2 } from "lucide-react";
import { motion } from "framer-motion";

export default function MultiImageUploader({
  images = [],
  onImagesChange,
  maxImages = 4,
}) {
  const inputRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(null);

  const selectImages = (index) => {
    setActiveIndex(index);
    inputRef.current.click();
  };

  const handleFilesSelected = (fileList) => {
    if (activeIndex === null) return;

    const newFiles = Array.from(fileList);
    let updated = [...images];

    let insertIndex = activeIndex;

    newFiles.forEach((file) => {
      if (insertIndex >= maxImages) return; // stop if limit reached
      updated[insertIndex] = file;
      insertIndex++;
    });

    onImagesChange(updated.slice(0, maxImages));
    setActiveIndex(null);
  };

  const handleRemove = (idx) => {
    const updated = images.filter((_, i) => i !== idx);

    // shift remaining images left
    while (updated.length < maxImages) {
      updated.push(null);
    }

    onImagesChange(updated);
  };

  const slots = Array.from({ length: maxImages }, (_, idx) => images[idx] || null);

  return (
    <div>
      <div className="flex flex-wrap gap-4">
        {slots.map((img, idx) => (
          <div
            key={idx}
            className="relative w-32 h-32 border border-dashed border-gray-700 rounded-lg
                       bg-gray-100 flex items-center justify-center overflow-hidden group cursor-pointer"
            onClick={() => selectImages(idx)}
          >
            {/* If image exists */}
            {img ? (
              <>
                <img
                  src={img instanceof File ? URL.createObjectURL(img) : img}
                  alt={`Image ${idx + 1}`}
                  className="w-full h-full object-cover"
                />

                {/* Hover Overlay */}
                <div
                  className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center gap-3 
                             opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                >
                  {/* Replace */}
                  <motion.div
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      selectImages(idx);
                    }}
                    className="flex flex-col items-center opacity-0 group-hover:opacity-100 transition"
                  >
                    <div className="p-2 bg-white/90 rounded-full shadow">
                      <RotateCcw className="w-5 h-5 text-gray-700" />
                    </div>
                    <span className="text-white text-xs mt-1">Replace</span>
                  </motion.div>

                  {/* Delete */}
                  <motion.div
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemove(idx);
                    }}
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition"
                  >
                    <div className="p-1.5 bg-white/90 rounded-full shadow">
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </div>
                  </motion.div>
                </div>
              </>
            ) : (
              /* Empty Slot */
              <div className="flex flex-col items-center justify-center">
                <Plus className="text-gray-400 w-6 h-6" />
                <span className="text-gray-500 text-xs mt-1">Add Image</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Hidden Input */}
      <input
        type="file"
        accept="image/*"
        multiple
        ref={inputRef}
        className="hidden"
        onChange={(e) => handleFilesSelected(e.target.files)}
      />
    </div>
  );
}
