"use client";
import { Info } from "lucide-react";
import { useState } from "react";

export default function InfoTooltip({
  points = ["This is some helpful information."], // Array of strings
}) {
  const [opened, setOpened] = useState(false);

  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setOpened(true)}
      onMouseLeave={() => setOpened(false)}
    >
      {/* Info icon */}
      <Info
        onClick={() => setOpened((prev) => !prev)}
        className="w-5 h-5 text-gray-500 cursor-pointer hover:text-blue-600 transition-colors"
      />

      {/* Tooltip */}
      <div
        className={`absolute left-3 mt-2 w-72 bg-gray-50 text-gray-800 text-sm rounded-lg shadow-lg p-3 z-10 transition-all duration-200 border border-gray-200 ${
          opened ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
      >
        <ul className="list-disc list-inside space-y-1">
          {points.map((point, index) => (
            <li key={index}>{point}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
