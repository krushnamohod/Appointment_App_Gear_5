"use client";

import { useState } from "react";
import { Trash2, X, Pencil } from "lucide-react";
import * as LucideIcons from "lucide-react";

export default function FactsCard({
  fact,
  index,
  updateFact,
  removeFact,
  previewMode,
  ICON_OPTIONS,
}) {
  const f = fact;

  const [iconPopup, setIconPopup] = useState(false);

  function IconByName({ name, className = "h-6 w-6" }) {
    const IconComponent = LucideIcons[name];
    if (!IconComponent) return <LucideIcons.HelpCircle className={className} />;
    return <IconComponent className={className} />;
  }

  return (
    <>
      {/* Main Card */}
      <div className="bg-gradient-to-br from-white to-gray-50 rounded-xl border border-gray-200 p-4 hover:shadow-lg transition-all duration-300 text-center">
        {/* Top Section */}
        <div className="flex justify-between items-start mb-4">
          {/* Icon Button with Hover Pencil */}
          <button
            type="button"
            disabled={previewMode}
            onClick={() => setIconPopup(true)}
            className="relative w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 shadow-sm transition-all group hover:ring-2 hover:ring-blue-300 "
          >
            {/* Default Icon */}
            <div className="transition-opacity duration-200 group-hover:opacity-0">
              <IconByName name={f.icon} className="h-6 w-6 text-blue-900" />
            </div>

            {/* Pencil Icon Overlay */}
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <Pencil className="h-5 w-5 text-blue-700" />
            </div>
          </button>

          {/* Delete Button */}
          <button
            onClick={() => removeFact(index)}
            disabled={previewMode}
            className=" bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-all duration-200 disabled:hidden -mt-1 -mr-1"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Form Fields */}
        <div className="space-y-4">
          {/* Label */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-2">
              LABEL
            </label>
            <input
              value={f.label || ""}
              onChange={(e) => updateFact(index, "label", e.target.value)}
              placeholder="Happy Clients"
              disabled={previewMode}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white disabled:bg-gray-100 text-center font-medium"
            />
          </div>

          {/* Value */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-2">
              VALUE
            </label>
            <input
              value={f.value || ""}
              onChange={(e) => updateFact(index, "value", e.target.value)}
              placeholder="500+"
              disabled={previewMode}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white disabled:bg-gray-100 text-xl font-bold text-center text-gray-800"
            />
          </div>
        </div>
      </div>

      {/* Icon Selection Popup */}
      {iconPopup && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center overflow-hidden">
          <div className="absolute w-72 h-72 bg-white shadow-xl border border-gray-200 p-4 rounded-xl overflow-y-auto scrollbar-hide">
            {/* Header */}
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Select Icon</h2>
              <button
                onClick={() => setIconPopup(false)}
                className="p-2 rounded hover:bg-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Icons Grid */}
            <div className="grid grid-cols-4 gap-3">
              {ICON_OPTIONS.map((icon) => {
                const IconEl = LucideIcons[icon] || LucideIcons.HelpCircle;

                return (
                  <button
                    key={icon}
                    onClick={() => {
                      updateFact(index, "icon", icon);
                      setIconPopup(false);
                    }}
                    className="flex flex-col items-center gap-1 p-2 rounded-lg border hover:bg-blue-100 text-gray-600 transition-all"
                  >
                    <IconEl className="h-6 w-6" />
                    <span className="text-[10px] truncate w-full text-center">
                      {icon}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
