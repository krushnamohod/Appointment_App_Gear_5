"use client";
import { motion } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { ImageUp, RotateCcw, Plus } from "lucide-react";

export default function ImageUploader({
  image: externalImage = null,
  onImageChange,
  fileType = "image/*",
  className = "", // <<< ADDED
  borderColor = "border-gray-800",
  bgColor = "bg-gray-100",
}) {
  const inputRef = useRef(null);
  const [preview, setPreview] = useState(externalImage);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    setPreview(externalImage);
  }, [externalImage]);

  const handleFileChange = (file) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreview(url);
    onImageChange && onImageChange(file);
  };

  useEffect(() => {
    return () => {
      if (preview && preview.startsWith("blob:")) {
        URL.revokeObjectURL(preview);
      }
    };
  }, [preview]);

  return (
    <div className="relative">
      {/* Image preview box */}
      <div
        className={`
          rounded-xl border border-dashed ${borderColor} ${bgColor}
          overflow-hidden flex items-center justify-center relative group cursor-pointer w-32 h-32
          ${className}  // <<< APPLIES CUSTOM SIZE
        `}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={() => inputRef.current.click()}
      >
        <input
          type="file"
          accept={fileType}
          className="hidden"
          ref={inputRef}
          onChange={(e) => handleFileChange(e.target.files[0])}
        />

        {preview ? (
          <>
            <img
              src={preview}
              alt="Preview"
              className="w-full h-full object-cover"
            />

            {hovered && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/40 flex items-center justify-center gap-4"
              >
                <motion.div
                  whileTap={{ scale: 0.9 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    inputRef.current.click();
                  }}
                  className="p-2 bg-white/90 rounded-full shadow"
                >
                  <RotateCcw className="w-5 h-5 text-gray-700" />
                </motion.div>
              </motion.div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center text-gray-400">
            <Plus className="w-8 h-8" />
          </div>
        )}
      </div>
    </div>
  );
}
