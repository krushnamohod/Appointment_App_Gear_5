"use client";

export default function SectionHeader({ title, subtitle }) {
  return (
    <div className="w-full mb-6">
      <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-1">
        {title}
      </h2>
      {subtitle && (
        <p className="text-xs md:text-sm text-gray-600">
          {subtitle}
        </p>
      )}
    </div>
  );
}
