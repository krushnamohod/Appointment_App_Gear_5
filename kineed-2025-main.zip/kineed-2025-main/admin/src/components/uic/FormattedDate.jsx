export default function FormattedDate({ date }) {
  if (!date) return null;

  const d = new Date(date);
  if (isNaN(d)) return "Invalid date";

  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();

  return <span>{`${dd}-${mm}-${yyyy}`}</span>;
}
