// Add to your existing seed.js file
async function seedProducts() {
  console.log('🌱 Seeding products and categories...');

  // Create categories
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { name: 'Electronics' },
      update: {},
      create: {
        name: 'Electronics',
        description: 'Electronic devices and accessories'
      }
    }),
    prisma.category.upsert({
      where: { name: 'Clothing' },
      update: {},
      create: {
        name: 'Clothing',
        description: 'Fashion and apparel'
      }
    }),
    prisma.category.upsert({
      where: { name: 'Home & Kitchen' },
      update: {},
      create: {
        name: 'Home & Kitchen',
        description: 'Home appliances and kitchenware'
      }
    })
  ]);

  // Create sample products
  const products = await prisma.product.createMany({
    data: [
      {
        name: 'Wireless Bluetooth Headphones',
        originalPrice: 129.99,
        price: 89.99,
        rating: 4.5,
        category: 'Electronics',
        stock: 50,
        sku: 'ELEC-001',
        brand: 'AudioTech',
        colors: ['Black', 'White', 'Blue'],
        description: 'High-quality wireless headphones with noise cancellation',
        features: ['Noise Cancellation', '30hr Battery', 'Quick Charge'],
        specifications: {
          'Battery Life': '30 hours',
          'Connectivity': 'Bluetooth 5.0',
          'Weight': '250g'
        },
        images: ['/images/headphones-1.jpg', '/images/headphones-2.jpg'],
        mainImage: '/images/headphones-1.jpg'
      },
      {
        name: 'Smart Fitness Watch',
        originalPrice: 199.99,
        price: 149.99,
        rating: 4.3,
        category: 'Electronics',
        stock: 30,
        sku: 'ELEC-002',
        brand: 'FitTech',
        colors: ['Black', 'Silver', 'Rose Gold'],
        description: 'Advanced fitness tracking smartwatch with heart rate monitor',
        features: ['Heart Rate Monitor', 'GPS', 'Water Resistant'],
        specifications: {
          'Display': '1.3 inch AMOLED',
          'Battery': '7 days',
          'Water Resistance': '50m'
        },
        images: ['/images/watch-1.jpg', '/images/watch-2.jpg'],
        mainImage: '/images/watch-1.jpg'
      },
      {
        name: 'Cotton T-Shirt',
        originalPrice: 29.99,
        price: 19.99,
        rating: 4.2,
        category: 'Clothing',
        stock: 100,
        sku: 'CLOTH-001',
        brand: 'FashionCo',
        colors: ['White', 'Black', 'Gray', 'Navy'],
        description: 'Premium cotton t-shirt for everyday wear',
        features: ['100% Cotton', 'Machine Washable', 'Pre-shrunk'],
        specifications: {
          'Material': '100% Cotton',
          'Fit': 'Regular',
          'Care': 'Machine Wash'
        },
        images: ['/images/tshirt-1.jpg', '/images/tshirt-2.jpg'],
        mainImage: '/images/tshirt-1.jpg'
      }
    ],
    skipDuplicates: true
  });

  console.log('✅ Products and categories seeded');
}