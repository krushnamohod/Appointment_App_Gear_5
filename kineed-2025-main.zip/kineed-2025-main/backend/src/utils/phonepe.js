import axios from "axios";
import qs from "qs";

let cachedToken = null;
let tokenExpiry = 0;

export async function getAccessToken() {
  if (cachedToken && Date.now() < tokenExpiry) {
    return cachedToken;
  }

  const url = `${process.env.PHONEPE_BASE_URL}/apis/pg-sandbox/v1/oauth/token`;

  const response = await axios.post(
    url,
    qs.stringify({
      client_id: process.env.PHONEPE_CLIENT_ID,
      client_secret: process.env.PHONEPE_CLIENT_SECRET,
      client_version: process.env.PHONEPE_CLIENT_VERSION,
      grant_type: "client_credentials",
    }),
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    }
  );

  cachedToken = response.data.access_token;
  tokenExpiry = Date.now() + 50 * 60 * 1000;

  return cachedToken;
}

export async function initiatePayment(payload) {
  const token = await getAccessToken();
  const url = `${process.env.PHONEPE_BASE_URL}/apis/pg-sandbox/checkout/v1/pay`;

  const res = await axios.post(url, payload, {
    headers: { Authorization: `O-Bearer ${token}` },
  });

  return res.data;
}

export async function checkPaymentStatus(orderId) {
  const token = await getAccessToken();

  const url = `${process.env.PHONEPE_BASE_URL}/apis/pg-sandbox/checkout/v1/order/status/${process.env.PHONEPE_MERCHANT_ID}/${orderId}`;

  const res = await axios.get(url, {
    headers: { Authorization: `O-Bearer ${token}` },
  });

  return res.data;
}
