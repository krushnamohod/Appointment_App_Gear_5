import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";
import AppError from "../utils/appError.js";

const prisma = new PrismaClient();

export const protect = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  console.log("Raw header:", authHeader);

  try {
    let token;

    // 1) Extract token
    if (authHeader && authHeader.startsWith("Bearer")) {
      token = authHeader.split(" ")[1];
    }

    if (!token) {
      return next(
        new AppError("You are not logged in! Please log in to get access.", 401)
      );
    }

    // 2) Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err.name === "TokenExpiredError") {
        return next(
          new AppError("Your token has expired. Please log in again.", 401)
        );
      } else if (err.name === "JsonWebTokenError") {
        return next(
          new AppError("Token is invalid. Please log in again.", 401)
        );
      } else {
        return next(new AppError("Could not verify token.", 401));
      }
    }

    // 3) Check if user exists
    const currentUser = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: { id: true, email: true, name: true, role: true },
    });

    if (!currentUser) {
      return next(
        new AppError(
          "The user belonging to this token no longer exists.",
          401
        )
      );
    }

    // 4) Attach user to request object
    req.user = currentUser;
    next();

  } catch (error) {
    console.error("Protect middleware error:", error);
    return next(new AppError("Authentication failed.", 401));
  }
};
