import express from "express";
import { body } from "express-validator";
import { protect } from "../middleware/auth.js";

import {
  getAllEnquiries,
  getEnquiry,
  updateEnquiry,
  deleteEnquiry,
  createEnquiry,
} from "../controllers/enquiriesController.js";

const router = express.Router();

// Public route for creating enquiries
router.post(
  "/",
  [
    body("name").notEmpty(),
    body("email").isEmail(),
    body("subject").notEmpty(),
    body("message").notEmpty(),
  ],
  createEnquiry
);

// Protected routes (enable when needed)
// router.use(protect);

router.get("/", getAllEnquiries);
router.get("/:id", getEnquiry);

router.patch(
  "/:id",
  [
    body("status")
      .optional()
      .isIn(["NEW", "IN_PROGRESS", "RESOLVED"]),
  ],
  updateEnquiry
);

router.delete("/:id", deleteEnquiry);

export default router;
