import express from "express";
import {
  createAbout,
  getAbout,
  updateAbout,
  deleteAbout,
} from "../controllers/aboutController.js";

const router = express.Router();

router.post("/", createAbout);
router.get("/", getAbout);
router.put("/:id", updateAbout);
router.delete("/:id", deleteAbout);

export default router;
