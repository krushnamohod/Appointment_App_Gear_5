import express from "express";
import { protect } from "../middleware/auth.js";

import {
  getWebsiteContent,
  updateWebsiteContent,
  getAllPagesContent,
} from "../controllers/websiteController.js";

const router = express.Router();

// Protect all routes
router.use(protect);

router.get("/", getAllPagesContent);
router.get("/:page", getWebsiteContent);
router.patch("/:page/:section", updateWebsiteContent);

export default router;
