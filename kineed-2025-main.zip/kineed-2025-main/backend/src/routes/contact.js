import express from "express";
import { body } from "express-validator";
import { protect } from "../middleware/auth.js";
import {
  getContactContent,
  updateContactContent,
  getPublicContactInfo,
} from "../controllers/contactController.js";

const router = express.Router();

// Public route for website to fetch contact info
router.get("/public", getPublicContactInfo);

// PROTECTED ROUTES (enable when needed)
// router.use(protect);

router.get("/", getContactContent);

router.patch(
  "/",
  [
    body("email").optional().isEmail().withMessage("Please provide a valid email address"),
    body("phone").optional().isLength({ min: 1 }).withMessage("Phone number is required"),
    body("address").optional().isLength({ min: 1 }).withMessage("Address is required"),
    body("businessHours").optional().isLength({ min: 1 }),

    // Social Media URLs
    body("facebook").optional().isURL().withMessage("Please provide a valid Facebook URL"),
    body("instagram").optional().isURL().withMessage("Please provide a valid Instagram URL"),
    body("twitter").optional().isURL().withMessage("Please provide a valid Twitter URL"),
    body("linkedin").optional().isURL().withMessage("Please provide a valid LinkedIn URL"),
    body("youtube").optional().isURL().withMessage("Please provide a valid YouTube URL"),

    // Messaging Apps
    body("whatsapp").optional(),

    // Business Profiles
    body("googleBusiness").optional().isURL().withMessage("Please provide a valid Google Business URL"),

    // Additional fields
    body("secondaryPhone").optional(),
  ],
  updateContactContent
);

export default router;
