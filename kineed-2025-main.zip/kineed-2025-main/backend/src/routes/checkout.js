// src/routes/checkout.js
import express from "express";
import {
  createOrder,
  initiatePayment,
  checkPaymentStatus,
  phonePeCallback,
  getOrderDetails,
  getAllOrders,
  updateOrderStatus
} from "../controllers/checkoutController.js";

const router = express.Router();

// Test PhonePe connection..
// router.get("/test-connection", testPhonePeConnection);

// Create order
router.post("/create-order", createOrder);

// Initiate PhonePe payment
router.post("/initiate-payment", initiatePayment);

// Check payment status
router.get("/payment-status/:transactionId", checkPaymentStatus);

// PhonePe callback endpoint
router.post("/callback", phonePeCallback);

// Get order details
router.get("/order/:orderId", getOrderDetails);

// Get all orders (admin)
router.get("/orders", getAllOrders);

// Update order status (admin)
router.patch("/order/:orderId/status", updateOrderStatus);

export default router;