import express from "express";
import {
  createHome,
  getAllHome,
  getHomeById,
  updateHome,
  deleteHome,
} from "../controllers/homecontroller.js";

const router = express.Router();

// POST /api/home
router.post("/", createHome);

// GET /api/home
router.get("/", getAllHome);

// GET /api/home/:id
router.get("/:id", getHomeById);

// PUT /api/home/:id
router.put("/:id", updateHome);

// DELETE /api/home/:id
router.delete("/:id", deleteHome);

export default router;
