import express from "express";
import { ContactController } from "../controllers/contactform.js";

const router = express.Router();

// Create new contact message
router.post("/", ContactController.createMessage);

// Get all messages
router.get("/", ContactController.getMessages);

// Get single message
router.get("/:id", ContactController.getMessageById);

// Update status
router.put("/:id/status", ContactController.updateStatus);

// Delete message
router.delete("/:id", ContactController.deleteMessage);

export default router;
