import express from "express";
import { body } from "express-validator";
import { protect } from "../middleware/auth.js";

import {
  getAllReviews,
  updateReview,
  deleteReview,
  createReviewsBulk,
  createReview,
} from "../controllers/reviewsController.js";

const router = express.Router();

// Protect all routes (enable when needed)
// router.use(protect);

router.get("/", getAllReviews);

router.post(
  "/",
  [
    body("customerName").notEmpty(),
    body("rating").isInt({ min: 1, max: 5 }),
    body("comment").notEmpty(),
  ],
  createReview
);

router.patch(
  "/:id",
  [
    body("status")
      .optional()
      .isIn(["PENDING", "APPROVED", "REJECTED"]),
  ],
  updateReview
);

router.delete("/:id", deleteReview);

router.post("/bulk", createReviewsBulk);

export default router;
