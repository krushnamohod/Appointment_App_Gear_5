import express from "express";
import {
  getAllPolicies,
  getPolicy,
  createPolicy,
  updatePolicy,
  deletePolicy,
  deleteDescriptionItem,
  reorderDescription
} from "../controllers/policyController.js";

const router = express.Router();

// POLICIES CRUD
router.get("/", getAllPolicies);          // GET all policies
router.post("/", createPolicy);           // CREATE new policy

router.get("/:name", getPolicy);          // GET single policy
router.put("/:name", updatePolicy);       // UPDATE policy
router.delete("/:name", deletePolicy);    // DELETE policy

// DESCRIPTION ITEM CRUD
router.delete("/description/:descId", deleteDescriptionItem);   // DELETE description row
router.put("/reorder/:policyId", reorderDescription);           // REORDER rows (drag & drop)

export default router;
