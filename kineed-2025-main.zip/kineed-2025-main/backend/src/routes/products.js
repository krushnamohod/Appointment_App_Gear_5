import express from "express";
import { body } from "express-validator";
import { protect } from "../middleware/auth.js";

import {
  getAllProducts,
  getProduct,
  updateProduct,
  deleteProduct,
  createProduct,
  reorderProducts,

  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  reorderCategories,

  getAllBrands,
  createBrand,
  deleteBrand,
  updateBrand,
  reorderBrands,
  bulkCreateProducts,

  uploadImages,
} from "../controllers/productsController.js";

const router = express.Router();

// =============================================================
// PRODUCT ROUTES
// =============================================================
router.get("/", getAllProducts);
router.get("/:id", getProduct);

router.post(
  "/",
  [
    body("name").notEmpty().withMessage("Product name is required"),
    body("originalPrice")
      .isFloat({ min: 0 })
      .withMessage("Original price must be a positive number"),
    body("price")
      .isFloat({ min: 0 })
      .withMessage("Price must be a positive number"),
    body("category").notEmpty().withMessage("Category is required"),
    body("sku").notEmpty().withMessage("SKU is required"),
    body("brand").notEmpty().withMessage("Brand is required"),
    body("description").notEmpty().withMessage("Description is required"),
  ],
  createProduct
);

// ⭐ Reorder products (DnD)
router.post("/reorder", reorderProducts);

router.patch(
  "/:id",
  [
    body("originalPrice")
      .optional()
      .isFloat({ min: 0 })
      .withMessage("Original price must be a positive number"),
    body("price")
      .optional()
      .isFloat({ min: 0 })
      .withMessage("Price must be a positive number"),
  ],
  updateProduct
);

router.delete("/:id", deleteProduct);

// =============================================================
// CATEGORY ROUTES
// =============================================================
router.get("/categories/all", getCategories);

router.post(
  "/categories",
  [
    body("name").notEmpty().withMessage("Category name is required"),
  ],
  createCategory
);

router.patch("/categories/:id", updateCategory);
router.delete("/categories/:id", deleteCategory);

// ⭐ Reorder categories
router.post("/categories/reorder", reorderCategories);

// =============================================================
// BRAND ROUTES
// =============================================================
router.get("/brands/all", getAllBrands);

router.post(
  "/brands",
  [
    body("name").notEmpty().withMessage("Brand name is required"),
  ],
  createBrand
);

router.patch("/brands/:id", updateBrand);
router.delete("/brands/:id", deleteBrand);

// ⭐ Reorder brands
router.post("/brands/reorder", reorderBrands);

// =============================================================
// IMAGE UPLOAD
// =============================================================
router.post("/upload/images", uploadImages);

// =============================================================
// BULK CREATE PRODUCTS
// =============================================================
router.post("/bulk", bulkCreateProducts);

export default router;
