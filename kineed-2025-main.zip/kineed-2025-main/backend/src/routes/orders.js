import express from "express";
import { createOrder } from "../controllers/ordersController.js";
import { phonepeWebhook } from "../controllers/phonepeWebhook.js";
import { getStatus } from "../controllers/statusController.js";

const router = express.Router();

router.post("/orders", createOrder);
router.post(
  "/webhook/phonepe",
  express.raw({ type: "application/json", limit: "5mb" }),
  phonepeWebhook
);

router.get("/orders/:orderId/status", getStatus);

export default router;
