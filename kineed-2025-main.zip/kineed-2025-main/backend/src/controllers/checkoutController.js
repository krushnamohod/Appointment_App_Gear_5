// src/controllers/checkoutController.js
import fetch from "node-fetch";
import { v4 as uuidv4 } from "uuid";
import nodemailer from "nodemailer";
import prisma from "../utils/prisma.js";

// PhonePe Configuration
const PHONEPE_CONFIG = {
  clientId: "SU2506111340583648875062",
  clientSecret: "7d5ddace-0bb0-4c00-bccf-4ac6d9162053",
  clientVersion: "1",
  merchantId: "M23TJDZPV8L6L",
  tokenUrl: "https://api.phonepe.com/apis/identity-manager/v1/oauth/token",
  payUrl: "https://api.phonepe.com/apis/pg/checkout/v2/pay",
  statusUrl: "https://api.phonepe.com/apis/pg/checkout/v2/status",
  frontendUrl: process.env.FRONTEND_URL || "https://kineed.in",
  backendUrl: process.env.BACKEND_URL || "https://api.kineed.in"
};

// Email configuration
const emailTransporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER || "your-email@gmail.com",
    pass: process.env.EMAIL_PASSWORD || "your-app-password",
  },
});

// Fetch PhonePe access token
const fetchAccessToken = async () => {
  try {
    const params = new URLSearchParams();
    params.append("client_id", PHONEPE_CONFIG.clientId);
    params.append("client_secret", PHONEPE_CONFIG.clientSecret);
    params.append("client_version", PHONEPE_CONFIG.clientVersion);
    params.append("grant_type", "client_credentials");

    const response = await fetch(PHONEPE_CONFIG.tokenUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params,
    });

    const data = await response.json();
    if (!data.access_token) {
      console.error("Token fetch failed:", data);
      throw new Error("Failed to obtain access token");
    }
    return data.access_token;
  } catch (err) {
    console.error("Access token error:", err);
    throw err;
  }
};

// Create order in database
export const createOrder = async (req, res) => {
  try {
    const { items, customerInfo, totalAmount } = req.body;

    // Validation
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Items array is required and must not be empty"
      });
    }

    if (!customerInfo || !customerInfo.name || !customerInfo.email || !customerInfo.phone) {
      return res.status(400).json({
        success: false,
        message: "Customer information is required"
      });
    }

    if (!totalAmount || totalAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Valid total amount is required"
      });
    }

    const orderId = `ORD${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    // Create order in database
    const order = await prisma.order.create({
      data: {
        orderId,
        customerName: customerInfo.name,
        customerEmail: customerInfo.email,
        customerPhone: customerInfo.phone,
        customerAddress: customerInfo.address || null,
        shippingCity: customerInfo.city || null,
        shippingState: customerInfo.state || null,
        shippingPincode: customerInfo.pincode || null,
        items: items.map(item => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          image: item.image || null
        })),
        totalAmount,
        status: 'PENDING',
        paymentStatus: 'PAYMENT_PENDING',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    });

    console.log(`Order created in database: ${order.id}`, order);

    res.status(200).json({
      success: true,
      message: "Order created successfully",
      data: {
        orderId: order.orderId,
        order
      }
    });

  } catch (error) {
    console.error("Create order error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to create order",
      error: error.message
    });
  }
};

// Initiate PhonePe payment
export const initiatePayment = async (req, res) => {
  try {
    const { orderId, amount, customerInfo } = req.body;

    // Validation
    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: "Order ID is required"
      });
    }

    // Find order in database
    const order = await prisma.order.findUnique({
      where: { orderId }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Valid amount is required"
      });
    }

    const merchantTransactionId = uuidv4();
    console.log("Initiating payment for:", merchantTransactionId);

    // Prepare PhonePe payload
    const payload = {
      merchantOrderId: merchantTransactionId,
      amount: Math.round(amount * 100), // Convert to paise
      expireAfter: 1200, // 20 minutes
      paymentFlow: {
        type: "PG_CHECKOUT",
        message: "Complete your payment for KINEED Kitchen Appliances",
        merchantUrls: {
          redirectUrl: `${PHONEPE_CONFIG.frontendUrl}/order-success?order_id=${orderId}&transaction_id=${merchantTransactionId}`,
          callbackUrl: `${PHONEPE_CONFIG.backendUrl}/api/checkout/callback`
        },
      },
      customerDetails: {
        name: customerInfo?.name || order.customerName,
        email: customerInfo?.email || order.customerEmail,
        phone: customerInfo?.phone || order.customerPhone
      }
    };

    // Get access token and initiate payment
    const accessToken = await fetchAccessToken();
    console.log("Obtained access token");

    const response = await fetch(PHONEPE_CONFIG.payUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `O-Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    console.log("PhonePe response:", data);

    if (data.redirectUrl) {
      // Update order with transaction details in database
      const updatedOrder = await prisma.order.update({
        where: { orderId },
        data: {
          transactionId: merchantTransactionId,
          merchantOrderId: merchantTransactionId,
          paymentStatus: 'PAYMENT_INITIATED',
          paymentInitiatedAt: new Date(),
          phonePeResponse: data,
          updatedAt: new Date()
        }
      });

      console.log("Payment initiated for order:", orderId);

      res.status(200).json({
        success: true,
        message: "Payment initiated successfully",
        data: {
          redirectUrl: data.redirectUrl,
          transactionId: merchantTransactionId,
          orderId: orderId,
          order: updatedOrder
        }
      });
    } else {
      console.error("Payment initiation failed:", data);
      
      // Update order status to failed
      await prisma.order.update({
        where: { orderId },
        data: {
          paymentStatus: 'PAYMENT_FAILED',
          phonePeResponse: data,
          updatedAt: new Date()
        }
      });

      res.status(400).json({
        success: false,
        message: data.message || "Payment initiation failed"
      });
    }

  } catch (error) {
    console.error("Payment initiation error:", error);
    
    // Update order status to failed in case of error
    try {
      await prisma.order.update({
        where: { orderId: req.body.orderId },
        data: {
          paymentStatus: 'PAYMENT_FAILED',
          updatedAt: new Date()
        }
      });
    } catch (dbError) {
      console.error("Failed to update order status:", dbError);
    }

    res.status(500).json({
      success: false,
      message: "Failed to initiate payment",
      error: error.message
    });
  }
};

// Check payment status
export const checkPaymentStatus = async (req, res) => {
  try {
    const { transactionId } = req.params;

    if (!transactionId) {
      return res.status(400).json({
        success: false,
        message: "Transaction ID is required"
      });
    }

    // Find order by transaction ID in database
    const order = await prisma.order.findUnique({
      where: { transactionId }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Transaction not found"
      });
    }

    // Get access token
    const accessToken = await fetchAccessToken();
    
    // Check status with PhonePe
    const statusUrl = `${PHONEPE_CONFIG.statusUrl}/${PHONEPE_CONFIG.merchantId}/${transactionId}`;
    const response = await fetch(statusUrl, {
      method: "GET",
      headers: {
        "Authorization": `O-Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();
    console.log("Payment status response:", data);

    let updatedOrder;
    
    // Update order status based on PhonePe response
    if (data.code === "PAYMENT_SUCCESS" || data.state === "COMPLETED") {
      updatedOrder = await prisma.order.update({
        where: { transactionId },
        data: {
          status: 'PROCESSING',
          paymentStatus: 'PAYMENT_SUCCESS',
          paidAt: new Date(),
          phonePeStatus: data,
          updatedAt: new Date()
        }
      });
      
      // Send confirmation email
      await sendOrderConfirmationEmail(updatedOrder);
      
    } else if (data.code === "PAYMENT_ERROR" || data.state === "FAILED") {
      updatedOrder = await prisma.order.update({
        where: { transactionId },
        data: {
          paymentStatus: 'PAYMENT_FAILED',
          phonePeStatus: data,
          updatedAt: new Date()
        }
      });
    } else {
      updatedOrder = order;
    }

    res.status(200).json({
      success: true,
      data: {
        order: updatedOrder,
        paymentStatus: data
      }
    });

  } catch (error) {
    console.error("Check payment status error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to check payment status"
    });
  }
};

// PhonePe callback handler
export const phonePeCallback = async (req, res) => {
  try {
    const callbackData = req.body;
    console.log("PhonePe callback received:", callbackData);

    const { merchantOrderId, code, state } = callbackData;

    if (!merchantOrderId) {
      return res.status(400).json({
        success: false,
        message: "Missing merchant order ID in callback"
      });
    }

    // Find order by merchantOrderId in database
    const order = await prisma.order.findUnique({
      where: { merchantOrderId }
    });

    if (!order) {
      console.error(`Order not found for merchantOrderId: ${merchantOrderId}`);
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    let updatedOrder;
    
    if (code === "PAYMENT_SUCCESS" || state === "COMPLETED") {
      updatedOrder = await prisma.order.update({
        where: { merchantOrderId },
        data: {
          status: 'PROCESSING',
          paymentStatus: 'PAYMENT_SUCCESS',
          paidAt: new Date(),
          phonePeCallback: callbackData,
          updatedAt: new Date()
        }
      });
      
      // Send confirmation email
      await sendOrderConfirmationEmail(updatedOrder);
      
      console.log(`Order ${order.orderId} confirmed via callback`);
      
    } else if (code === "PAYMENT_ERROR" || state === "FAILED") {
      updatedOrder = await prisma.order.update({
        where: { merchantOrderId },
        data: {
          paymentStatus: 'PAYMENT_FAILED',
          phonePeCallback: callbackData,
          updatedAt: new Date()
        }
      });
      
      console.log(`Order ${order.orderId} failed via callback`);
    } else {
      updatedOrder = order;
    }

    // Return success response to PhonePe
    res.status(200).json({
      success: true,
      message: "Callback received successfully",
      orderId: updatedOrder.orderId,
      paymentStatus: updatedOrder.paymentStatus
    });

  } catch (error) {
    console.error("Callback processing error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to process callback"
    });
  }
};

// Get order details
export const getOrderDetails = async (req, res) => {
  try {
    const { orderId } = req.params;

    const order = await prisma.order.findUnique({
      where: { orderId }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    res.status(200).json({
      success: true,
      data: {
        order
      }
    });

  } catch (error) {
    console.error("Get order details error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to get order details"
    });
  }
};

// Get all orders (for admin)
export const getAllOrders = async (req, res) => {
  try {
    const { page = 1, limit = 20, status, paymentStatus } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where = {};
    if (status) where.status = status;
    if (paymentStatus) where.paymentStatus = paymentStatus;

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        skip,
        take: parseInt(limit),
        orderBy: {
          createdAt: 'desc'
        }
      }),
      prisma.order.count({ where })
    ]);

    res.status(200).json({
      success: true,
      data: {
        orders,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });

  } catch (error) {
    console.error("Get all orders error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to get orders"
    });
  }
};

// Update order status (for admin)
export const updateOrderStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { status, paymentStatus } = req.body;

    const order = await prisma.order.findUnique({
      where: { orderId }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    const updatedOrder = await prisma.order.update({
      where: { orderId },
      data: {
        ...(status && { status }),
        ...(paymentStatus && { paymentStatus }),
        updatedAt: new Date()
      }
    });

    res.status(200).json({
      success: true,
      message: "Order status updated",
      data: {
        order: updatedOrder
      }
    });

  } catch (error) {
    console.error("Update order status error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update order status"
    });
  }
};

// Send order confirmation email
const sendOrderConfirmationEmail = async (order) => {
  try {
    const items = Array.isArray(order.items) ? order.items : JSON.parse(order.items);
    
    const itemsHtml = items
      .map(
        (item, index) => `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #eee;">${index + 1}</td>
        <td style="padding: 12px; border-bottom: 1px solid #eee;">${item.name}</td>
        <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity}</td>
        <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: right;">₹${item.price}</td>
        <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: right;">₹${item.price * item.quantity}</td>
      </tr>
    `
      )
      .join('');

    const mailOptions = {
      from: `KINEED Kitchen Appliances <${process.env.EMAIL_USER || "noreply@kineed.in"}>`,
      to: order.customerEmail,
      cc: process.env.ADMIN_EMAIL,
      subject: `Order Confirmation - ${order.orderId}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 700px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 0 20px rgba(0,0,0,0.1);">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); padding: 40px; color: white; text-align: center;">
            <h1 style="margin: 0; font-size: 32px;">🎉 Order Confirmed!</h1>
            <p style="margin: 10px 0 0; opacity: 0.9; font-size: 18px;">Thank you for your purchase!</p>
          </div>
          
          <div style="padding: 40px;">
            <!-- Order Summary -->
            <div style="background: #f8f9fa; padding: 25px; border-radius: 8px; margin-bottom: 30px; border-left: 5px solid #4CAF50;">
              <h2 style="color: #333; margin-top: 0; margin-bottom: 20px;">Order Summary</h2>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div>
                  <p style="margin: 8px 0;"><strong>Order ID:</strong> ${order.orderId}</p>
                  <p style="margin: 8px 0;"><strong>Transaction ID:</strong> ${order.transactionId}</p>
                </div>
                <div>
                  <p style="margin: 8px 0;"><strong>Date:</strong> ${new Date(order.createdAt).toLocaleDateString('en-IN')}</p>
                  <p style="margin: 8px 0;"><strong>Payment Status:</strong> <span style="color: #4CAF50; font-weight: bold;">${order.paymentStatus.replace('PAYMENT_', '')}</span></p>
                </div>
              </div>
            </div>
            
            <!-- Customer Information -->
            <div style="margin-bottom: 30px;">
              <h3 style="color: #333; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #4CAF50;">Customer Information</h3>
              <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                <p style="margin: 8px 0;"><strong>Name:</strong> ${order.customerName}</p>
                <p style="margin: 8px 0;"><strong>Email:</strong> ${order.customerEmail}</p>
                <p style="margin: 8px 0;"><strong>Phone:</strong> ${order.customerPhone || 'N/A'}</p>
                <p style="margin: 8px 0;"><strong>Address:</strong> ${order.customerAddress || 'N/A'}</p>
                ${order.shippingCity ? `<p style="margin: 8px 0;"><strong>City/State/Pincode:</strong> ${order.shippingCity}, ${order.shippingState} - ${order.shippingPincode}</p>` : ''}
              </div>
            </div>
            
            <!-- Order Items -->
            <div style="margin-bottom: 30px;">
              <h3 style="color: #333; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #4CAF50;">Order Items</h3>
              <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; min-width: 600px;">
                  <thead>
                    <tr style="background: #4CAF50; color: white;">
                      <th style="padding: 12px; text-align: left;">#</th>
                      <th style="padding: 12px; text-align: left;">Product</th>
                      <th style="padding: 12px; text-align: center;">Qty</th>
                      <th style="padding: 12px; text-align: right;">Price</th>
                      <th style="padding: 12px; text-align: right;">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${itemsHtml}
                  </tbody>
                </table>
              </div>
            </div>
            
            <!-- Total Amount -->
            <div style="background: #f8f9fa; padding: 25px; border-radius: 8px; text-align: right; margin-bottom: 30px;">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 20px; font-weight: bold;">Total Amount:</span>
                <span style="font-size: 28px; font-weight: bold; color: #4CAF50;">₹${order.totalAmount}</span>
              </div>
            </div>
            
            <!-- Footer -->
            <div style="margin-top: 40px; padding-top: 30px; border-top: 2px dashed #ddd; text-align: center;">
              <p style="color: #666; font-size: 16px; margin-bottom: 20px;">
                Thank you for shopping with <strong style="color: #4CAF50;">KINEED Kitchen Appliances</strong>!
              </p>
              <div style="background: #f0f7f0; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <p style="color: #555; margin: 8px 0; font-size: 14px;">
                  <strong>Need help?</strong><br>
                  📧 Email: support@kineed.in<br>
                  📞 Phone: +91 1234567890<br>
                  🕒 Hours: 9 AM - 6 PM (Mon-Sat)
                </p>
              </div>
              <p style="margin-top: 30px;">
                <a href="https://kineed.in" style="background: #4CAF50; color: white; padding: 14px 35px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; font-size: 16px;">
                  Visit Our Website
                </a>
              </p>
            </div>
          </div>
        </div>
      `,
    };

    await emailTransporter.sendMail(mailOptions);
    console.log(`Confirmation email sent to ${order.customerEmail}`);

  } catch (error) {
    console.error("Error sending confirmation email:", error);
  }
};