import prisma from "../utils/prisma.js";

/* -----------------------------------------------------
   CREATE About (Full Structure)
----------------------------------------------------- */
export const createAbout = async (req, res) => {
  try {
    const {
      heroTitle,
      heroSubtitle,
      heroImages,
      services,
      values,
      facts,
    } = req.body;

    const about = await prisma.about.create({
      data: {
        heroTitle,
        heroSubtitle,
        heroImages,

        services: {
          create: services?.map((s) => ({
            icon: s.icon,
            title: s.title,
            description: s.description,
          })),
        },

        values: {
          create: values?.map((v) => ({
            icon: v.icon,
            title: v.title,
            description: v.description,
          })),
        },

        facts: {
          create: facts?.map((f) => ({
            icon: f.icon,
            value: f.value,
            label: f.label,
          })),
        },
      },
      include: {
        services: true,
        values: true,
        facts: true,
      },
    });

    res.status(201).json({
      message: "About created successfully",
      data: about,
    });
  } catch (error) {
    console.error("Create About Error:", error);
    res.status(500).json({ error: "Failed to create About" });
  }
};

/* -----------------------------------------------------
   GET About (Assuming Only 1 Entry)
----------------------------------------------------- */
export const getAbout = async (req, res) => {
  try {
    const about = await prisma.about.findFirst({
      include: {
        services: true,
        values: true,
        facts: true,
      },
    });

    res.status(200).json(about);
  } catch (error) {
    console.error("Get About Error:", error);
    res.status(500).json({ error: "Failed to fetch About data" });
  }
};

/* -----------------------------------------------------
   UPDATE About
----------------------------------------------------- */
export const updateAbout = async (req, res) => {
  try {
    const { id } = req.params;

    const {
      heroTitle,
      heroSubtitle,
      heroImages,
      services,
      values,
      facts,
    } = req.body;

    // Delete existing nested data for clean rewrite
    await prisma.service.deleteMany({ where: { aboutId: id } });
    await prisma.aboutValue.deleteMany({ where: { aboutId: id } });
    await prisma.fact.deleteMany({ where: { aboutId: id } });

    const updated = await prisma.about.update({
      where: { id },
      data: {
        heroTitle,
        heroSubtitle,
        heroImages,

        services: {
          create: services?.map((s) => ({
            icon: s.icon,
            title: s.title,
            description: s.description,
          })),
        },

        values: {
          create: values?.map((v) => ({
            icon: v.icon,
            title: v.title,
            description: v.description,
          })),
        },

        facts: {
          create: facts?.map((f) => ({
            icon: f.icon,
            value: f.value,
            label: f.label,
          })),
        },
      },
      include: {
        services: true,
        values: true,
        facts: true,
      },
    });

    res.status(200).json({
      message: "About updated successfully",
      data: updated,
    });
  } catch (error) {
    console.error("Update About Error:", error);
    res.status(500).json({ error: "Failed to update About" });
  }
};

/* -----------------------------------------------------
   DELETE About (Optional)
----------------------------------------------------- */
export const deleteAbout = async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.service.deleteMany({ where: { aboutId: id } });
    await prisma.aboutValue.deleteMany({ where: { aboutId: id } });
    await prisma.fact.deleteMany({ where: { aboutId: id } });

    await prisma.about.delete({
      where: { id },
    });

    res.status(200).json({ message: "About deleted successfully" });
  } catch (error) {
    console.error("Delete About Error:", error);
    res.status(500).json({ error: "Failed to delete About" });
  }
};
