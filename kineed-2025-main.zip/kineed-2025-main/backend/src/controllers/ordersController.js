// src/controllers/ordersController.js
import prisma from "../utils/prisma.js";
import AppError from "../utils/appError.js";
import catchAsync from "../utils/catchAsync.js";
import { initiatePayment } from "../utils/phonepe.js";

export const createOrder = async (req, res) => {
  try {
    const { customerName, customerEmail, customerPhone, items, totalAmount } =
      req.body;

    const order = await prisma.order.create({
      data: {
        orderId: "ORD-" + Date.now(),
        customerName,
        customerEmail,
        customerPhone,
        items,
        totalAmount,
      },
    });

    const payload = {
      orderId: order.orderId,
      merchantId: process.env.PHONEPE_MERCHANT_ID,
      amount: order.totalAmount * 100,
      redirectUrl: process.env.PHONEPE_REDIRECT_URL,
      callbackUrl: process.env.PHONEPE_CALLBACK_URL,
      mobileNumber: order.customerPhone,
      paymentInstrument: { type: "PAY_PAGE" },
    };

    const phonePeRes = await initiatePayment(payload);

    await prisma.order.update({
      where: { id: order.id },
      data: {
        transactionId: phonePeRes.data.transactionId,
        paymentStatus: "PAYMENT_INITIATED",
        paymentMeta: phonePeRes,
      },
    });

    // Safely extract redirect URL from PhonePe response
    const redirectUrl =
      phonePeRes?.data?.instrumentResponse?.redirectInfo?.url ||
      phonePeRes?.data?.redirectUrl ||
      phonePeRes?.data?.url ||
      null;

    if (!redirectUrl) {
      console.error("PhonePe Response Missing redirect URL:", phonePeRes);
      return res.status(500).json({
        ok: false,
        error: "PhonePe did not return any redirect URL",
        phonePeRes,
      });
    }

    return res.json({
      ok: true,
      checkoutUrl: redirectUrl,
      orderId: order.orderId,
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({ ok: false, error: err.message });
  }
};
