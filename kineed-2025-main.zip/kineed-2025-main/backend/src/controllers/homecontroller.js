import prisma from "../utils/prisma.js";

/**
 * Create Home Data
 */
export const createHome = async (req, res) => {
  try {
    let { logo, sliderimages } = req.body;

    // Ensure sliderimages is always an array
    if (!Array.isArray(sliderimages)) {
      sliderimages = sliderimages ? [sliderimages] : [];
    }

    const home = await prisma.home.create({
      data: { logo, sliderimages },
    });

    return res.status(201).json({
      success: true,
      message: "Home data created successfully",
      data: home,
    });
  } catch (error) {
    console.error("Create Home Error:", error);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

/**
 * Get All Home Entries
 */
export const getAllHome = async (req, res) => {
  try {
    const homes = await prisma.home.findMany({
      orderBy: { createdAt: "desc" },
    });

    return res.status(200).json({
      success: true,
      data: homes,
    });
  } catch (error) {
    console.error("Get All Home Error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};



/**
 * Get Single Home Entry by ID
 */
export const getHomeById = async (req, res) => {
  try {
    const { id } = req.params;

    const home = await prisma.home.findUnique({ where: { id } });

    if (!home) {
      return res.status(404).json({ success: false, message: "Home entry not found" });
    }

    return res.status(200).json({ success: true, data: home });
  } catch (error) {
    console.error("Get Home Error:", error);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

/**
 * Update Home Entry
 */
export const updateHome = async (req, res) => {
  try {
    const { id } = req.params;
    let { logo, sliderimages } = req.body;

    // Always convert to array
    if (!Array.isArray(sliderimages)) {
      sliderimages = sliderimages ? [sliderimages] : [];
    }

    const updated = await prisma.home.update({
      where: { id },
      data: { logo, sliderimages },
    });

    return res.status(200).json({
      success: true,
      message: "Home entry updated successfully",
      data: updated,
    });
  } catch (error) {
    console.error("Update Home Error:", error);

    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Home entry not found" });
    }

    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

/**
 * Delete Home Entry
 */
export const deleteHome = async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.home.delete({
      where: { id },
    });

    return res.status(200).json({
      success: true,
      message: "Home entry deleted successfully",
    });
  } catch (error) {
    console.error("Delete Home Error:", error);

    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Home entry not found" });
    }

    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};
