import prisma from "../utils/prisma.js";

/* =====================================================
   GET ALL POLICIES
===================================================== */
export const getAllPolicies = async (req, res) => {
  try {
    const policies = await prisma.policy.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        description: {
          orderBy: { order: "asc" }
        }
      }
    });

    const formatted = policies.map(formatPolicyResponse);

    res.json(formatted);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch policies" });
  }
};


/* =====================================================
   GET SINGLE POLICY BY NAME
===================================================== */
export const getPolicy = async (req, res) => {
  try {
    const { name } = req.params;

    const policy = await prisma.policy.findUnique({
      where: { name },
      include: {
        description: { orderBy: { order: "asc" } }
      }
    });

    if (!policy) return res.status(404).json({ message: "Policy not found" });

    res.json(formatPolicyResponse(policy));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch policy" });
  }
};


/* =====================================================
   CREATE NEW POLICY
===================================================== */
export const createPolicy = async (req, res) => {
  try {
    const { name, subtitle, description } = req.body;

    const created = await prisma.policy.create({
      data: {
        name,
        subtitle,
        description: {
          create:
            description?.map((item, index) => ({
              heading: item.heading || null,
              subheading: item.subheading || null,
              content: item.content || null,
              point: item.point || null,
              order: index
            })) || []
        }
      },
      include: {
        description: { orderBy: { order: "asc" } }
      }
    });

    res.json(formatPolicyResponse(created));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to create policy" });
  }
};


/* =====================================================
   UPDATE POLICY
===================================================== */
export const updatePolicy = async (req, res) => {
  try {
    const { name } = req.params;
    const { subtitle, description } = req.body;

    const existing = await prisma.policy.findUnique({ where: { name } });
    if (!existing) return res.status(404).json({ message: "Policy not found" });

    const updated = await prisma.policy.update({
      where: { name },
      data: {
        name: req.body.name, 
        subtitle,
        description: {
          deleteMany: {}, // delete all previous description items
          create: description.map((item, index) => ({
            heading: item.heading || null,
            subheading: item.subheading || null,
            content: item.content || null,
            point: item.point || null,
            order: index
          }))
        }
      },
      include: {
        description: { orderBy: { order: "asc" } }
      }
    });

    res.json(formatPolicyResponse(updated));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update policy" });
  }
};


/* =====================================================
   DELETE ENTIRE POLICY
===================================================== */
export const deletePolicy = async (req, res) => {
  try {
    const { name } = req.params;

    await prisma.policy.delete({ where: { name } });

    res.json({ message: "Policy deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to delete policy" });
  }
};


/* =====================================================
   DELETE ONE DESCRIPTION ROW + REORDER
===================================================== */
export const deleteDescriptionItem = async (req, res) => {
  try {
    const { descId } = req.params;

    const item = await prisma.policyDescription.findUnique({
      where: { id: Number(descId) }
    });

    if (!item) {
      return res.status(404).json({ message: "Description item not found" });
    }

    const policyId = item.policyId;

    await prisma.policyDescription.delete({
      where: { id: Number(descId) }
    });

    // Reorder remaining
    const remaining = await prisma.policyDescription.findMany({
      where: { policyId },
      orderBy: { order: "asc" }
    });

    await Promise.all(
      remaining.map((row, index) =>
        prisma.policyDescription.update({
          where: { id: row.id },
          data: { order: index }
        })
      )
    );

    const updated = await prisma.policy.findUnique({
      where: { id: policyId },
      include: { description: { orderBy: { order: "asc" } } }
    });

    res.json(formatPolicyResponse(updated));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to delete description item" });
  }
};


/* =====================================================
   REORDER DESCRIPTION (DRAG & DROP)
===================================================== */
export const reorderDescription = async (req, res) => {
  try {
    const { policyId } = req.params;
    const { ordered } = req.body; // array of { id, order }

    await Promise.all(
      ordered.map((item) =>
        prisma.policyDescription.update({
          where: { id: item.id },
          data: { order: item.order }
        })
      )
    );

    const updated = await prisma.policy.findUnique({
      where: { id: Number(policyId) },
      include: { description: { orderBy: { order: "asc" } } }
    });

    res.json(formatPolicyResponse(updated));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to reorder descriptions" });
  }
};


/* =====================================================
   FORMAT POLICY RESPONSE
===================================================== */
function formatPolicyResponse(policy) {
  return {
    id: policy.id,
    name: policy.name,
    subtitle: policy.subtitle || "",
    createdAt: policy.createdAt,
    updatedAt: policy.updatedAt,
    description:
      policy.description.length > 0
        ? policy.description.map((item) => ({
            heading: item.heading ?? "",
            subheading: item.subheading ?? "",
            content: item.content ?? "",
            point: item.point ?? ""
          }))
        : []
  };
}
