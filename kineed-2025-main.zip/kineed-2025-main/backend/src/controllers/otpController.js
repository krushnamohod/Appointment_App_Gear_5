// src/controllers/otpController.js
import nodemailer from "nodemailer";
import { v4 as uuidv4 } from "uuid";

// Email configuration
const emailTransporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER || "detectivefire69@gmail.com",
    pass: process.env.EMAIL_PASSWORD || "myuh lwgj xibt diow",
  },
});

// In-memory OTP store
let otpStore = {};

// Generate 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Send OTP
export const sendOTP = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      return res.status(400).json({
        success: false,
        message: "Valid email address is required"
      });
    }

    // Generate OTP
    const otp = generateOTP();
    const otpId = uuidv4();
    const expiry = Date.now() + 10 * 60 * 1000; // 10 minutes

    // Store OTP
    otpStore[otpId] = {
      email,
      otp,
      expiry,
      attempts: 0,
      verified: false,
      createdAt: new Date().toISOString()
    };

    // Send email
    const mailOptions = {
      from: `KINEED Kitchen Appliances <${process.env.EMAIL_USER || "noreply@kineed.in"}>`,
      to: email,
      subject: "Your OTP for KINEED Checkout",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; color: white; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="margin: 0; font-size: 28px;">Email Verification</h1>
          </div>
          
          <div style="padding: 30px; background: #fff; border-radius: 0 0 10px 10px; border: 1px solid #e0e0e0;">
            <p>Dear Customer,</p>
            <p>Your OTP for completing your purchase on KINEED Kitchen Appliances is:</p>
            
            <div style="background: #f8f9fa; padding: 25px; text-align: center; margin: 25px 0; border-radius: 8px; border: 2px dashed #ddd;">
              <div style="font-size: 42px; font-weight: bold; letter-spacing: 10px; color: #4F46E5; margin: 10px 0;">
                ${otp}
              </div>
            </div>
            
            <p style="color: #666; font-size: 14px;">
              This OTP is valid for 10 minutes. Please do not share it with anyone.
            </p>
            
            <p style="color: #666; font-size: 14px;">
              If you didn't request this OTP, please ignore this email.
            </p>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
              <p style="color: #666; font-size: 12px;">
                Best regards,<br>
                <strong>KINEED Kitchen Appliances</strong><br>
                <a href="https://kineed.in" style="color: #4F46E5;">https://kineed.in</a>
              </p>
            </div>
          </div>
        </div>
      `,
    };

    await emailTransporter.sendMail(mailOptions);

    console.log(`OTP sent to ${email}: ${otp}`);

    res.status(200).json({
      success: true,
      message: "OTP sent successfully",
      data: {
        otpId,
        expiresIn: "10 minutes"
      }
    });

  } catch (error) {
    console.error("OTP send error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to send OTP. Please try again."
    });
  }
};

// Verify OTP
export const verifyOTP = async (req, res) => {
  try {
    const { otpId, otp, email } = req.body;

    if (!otpId || !otp || !email) {
      return res.status(400).json({
        success: false,
        message: "OTP ID, OTP and email are required"
      });
    }

    const otpData = otpStore[otpId];

    if (!otpData) {
      return res.status(400).json({
        success: false,
        message: "Invalid OTP ID"
      });
    }

    if (otpData.email !== email) {
      return res.status(400).json({
        success: false,
        message: "Email does not match"
      });
    }

    if (Date.now() > otpData.expiry) {
      delete otpStore[otpId];
      return res.status(400).json({
        success: false,
        message: "OTP has expired"
      });
    }

    if (otpData.otp !== otp) {
      otpData.attempts += 1;
      
      if (otpData.attempts >= 3) {
        delete otpStore[otpId];
        return res.status(400).json({
          success: false,
          message: "Too many failed attempts. Please request a new OTP."
        });
      }
      
      return res.status(400).json({
        success: false,
        message: "Invalid OTP",
        attemptsRemaining: 3 - otpData.attempts
      });
    }

    // OTP verified successfully
    otpStore[otpId].verified = true;
    otpStore[otpId].verifiedAt = new Date().toISOString();

    res.status(200).json({
      success: true,
      message: "OTP verified successfully",
      data: {
        verified: true,
        email
      }
    });

  } catch (error) {
    console.error("OTP verification error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to verify OTP"
    });
  }
};

// Resend OTP
export const resendOTP = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required"
      });
    }

    // Generate new OTP
    const otp = generateOTP();
    const otpId = uuidv4();
    const expiry = Date.now() + 10 * 60 * 1000;

    // Remove old OTPs for this email
    Object.keys(otpStore).forEach(key => {
      if (otpStore[key].email === email) {
        delete otpStore[key];
      }
    });

    // Store new OTP
    otpStore[otpId] = {
      email,
      otp,
      expiry,
      attempts: 0,
      verified: false,
      createdAt: new Date().toISOString(),
      isResend: true
    };

    // Send email
    const mailOptions = {
      from: `KINEED Kitchen Appliances <${process.env.EMAIL_USER || "noreply@kineed.in"}>`,
      to: email,
      subject: "Your New OTP for KINEED Checkout",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); padding: 30px; color: white; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="margin: 0; font-size: 28px;">New OTP Request</h1>
          </div>
          
          <div style="padding: 30px; background: #fff; border-radius: 0 0 10px 10px; border: 1px solid #e0e0e0;">
            <p>Dear Customer,</p>
            <p>Your new OTP for completing your purchase on KINEED Kitchen Appliances is:</p>
            
            <div style="background: #f8f9fa; padding: 25px; text-align: center; margin: 25px 0; border-radius: 8px; border: 2px dashed #ddd;">
              <div style="font-size: 42px; font-weight: bold; letter-spacing: 10px; color: #4CAF50; margin: 10px 0;">
                ${otp}
              </div>
            </div>
            
            <p style="color: #666; font-size: 14px;">
              This OTP is valid for 10 minutes. Please do not share it with anyone.
            </p>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
              <p style="color: #666; font-size: 12px;">
                Best regards,<br>
                <strong>KINEED Kitchen Appliances</strong><br>
                <a href="https://kineed.in" style="color: #4CAF50;">https://kineed.in</a>
              </p>
            </div>
          </div>
        </div>
      `,
    };

    await emailTransporter.sendMail(mailOptions);

    console.log(`Resent OTP to ${email}: ${otp}`);

    res.status(200).json({
      success: true,
      message: "New OTP sent successfully",
      data: {
        otpId,
        expiresIn: "10 minutes"
      }
    });

  } catch (error) {
    console.error("Resend OTP error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to resend OTP"
    });
  }
};  