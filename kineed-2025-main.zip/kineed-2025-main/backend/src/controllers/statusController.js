import { PrismaClient } from "@prisma/client";
import { checkPaymentStatus } from "../utils/phonepe.js";

const prisma = new PrismaClient();

export const getStatus = async (req, res) => {
  try {
    const { orderId } = req.params;

    const statusRes = await checkPaymentStatus(orderId);

    const phonePeStatus = statusRes.data.state;

    let paymentStatus = "PAYMENT_PENDING";
    let orderStatus = "PENDING";

    if (phonePeStatus === "COMPLETED") {
      paymentStatus = "PAYMENT_SUCCESS";
      orderStatus = "COMPLETED";
    } else if (phonePeStatus === "FAILED") {
      paymentStatus = "PAYMENT_FAILED";
      orderStatus = "CANCELLED";
    }

    await prisma.order.updateMany({
      where: { orderId },
      data: {
        paymentStatus,
        status: orderStatus,
        paymentMeta: statusRes,
      },
    });

    res.json({ ok: true, statusRes });
  } catch (err) {
    console.log(err);
    res.status(500).json({ ok: false, error: err.message });
  }
};
