import prisma from "../utils/prisma.js";
import AppError from "../utils/appError.js";
import catchAsync from "../utils/catchAsync.js";

// Get contact page content
export const getContactContent = catchAsync(async (req, res, next) => {
  let contactInfo = await prisma.contactInfo.findFirst({
    orderBy: { updatedAt: "desc" },
  });

  // If no contact info exists, create default
  if (!contactInfo) {
    contactInfo = await prisma.contactInfo.create({
      data: {
        email: "contact@example.com",
        phone: "+1 234 567 8900",
        address: "123 Main St, City, Country",
        businessHours: "Mon-Fri 9AM-5PM",
      },
    });
  }

  res.status(200).json({
    status: "success",
    data: {
      contactInfo,
    },
  });
});

// Update contact content
export const updateContactContent = catchAsync(async (req, res, next) => {
  const {
    email,
    phone,
    address,
    businessHours,
    businessDays,
    facebook,
    instagram,
    twitter,
    linkedin,
    youtube,
    whatsapp,
    googleBusiness,
    secondaryPhone,
  } = req.body;

  let contactInfo = await prisma.contactInfo.findFirst();

  if (contactInfo) {
    // Update existing contact info
    contactInfo = await prisma.contactInfo.update({
      where: { id: contactInfo.id },
      data: {
        email,
        phone,
        address,
        businessHours,
        businessDays,
        facebook,
        instagram,
        twitter,
        linkedin,
        youtube,
        whatsapp,
        googleBusiness,
        secondaryPhone,
      },
    });
  } else {
    // Create new contact info
    contactInfo = await prisma.contactInfo.create({
      data: {
        email,
        phone,
        address,
        businessHours,
        businessDays,
        facebook,
        instagram,
        twitter,
        linkedin,
        youtube,
        whatsapp,
        googleBusiness,
        secondaryPhone,
      },
    });
  }

  res.status(200).json({
    status: "success",
    message: "Contact information updated successfully",
    data: {
      contactInfo,
    },
  });
});

// Get public contact info
export const getPublicContactInfo = catchAsync(async (req, res, next) => {
  let contactInfo = await prisma.contactInfo.findFirst({
    orderBy: { updatedAt: "desc" },
  });

  // If no contact info exists, return default values
  if (!contactInfo) {
    contactInfo = {
      email: "contact@example.com",
      phone: "+1 234 567 8900",
      address: "123 Main St, City, Country",
      businessHours: "Mon-Fri 9AM-5PM",
    };
  }

  res.status(200).json({
    status: "success",
    data: {
      contactInfo,
    },
  });
});
