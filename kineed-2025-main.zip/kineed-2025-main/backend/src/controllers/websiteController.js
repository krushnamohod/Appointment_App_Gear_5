import prisma from "../utils/prisma.js";
import AppError from "../utils/appError.js";
import catchAsync from "../utils/catchAsync.js";

// ===============================================================
// GET CONTENT FOR A SINGLE PAGE
// ===============================================================
export const getWebsiteContent = catchAsync(async (req, res, next) => {
  const { page } = req.params;

  const content = await prisma.websiteContent.findMany({
    where: { page },
    orderBy: { section: "asc" },
  });

  res.status(200).json({
    status: "success",
    data: { content },
  });
});

// ===============================================================
// UPDATE / CREATE CONTENT FOR A PAGE + SECTION
// ===============================================================
export const updateWebsiteContent = catchAsync(async (req, res, next) => {
  const { page, section } = req.params;
  const { content, isActive } = req.body;

  let websiteContent = await prisma.websiteContent.findFirst({
    where: { page, section },
  });

  if (websiteContent) {
    websiteContent = await prisma.websiteContent.update({
      where: { id: websiteContent.id },
      data: {
        content,
        ...(isActive !== undefined && { isActive }),
      },
    });
  } else {
    websiteContent = await prisma.websiteContent.create({
      data: {
        page,
        section,
        content,
        isActive: isActive !== undefined ? isActive : true,
      },
    });
  }

  res.status(200).json({
    status: "success",
    data: { content: websiteContent },
  });
});

// ===============================================================
// GET ALL PAGES + GROUP BY PAGE
// ===============================================================
export const getAllPagesContent = catchAsync(async (req, res, next) => {
  const content = await prisma.websiteContent.findMany({
    orderBy: [{ page: "asc" }, { section: "asc" }],
  });

  const groupedContent = content.reduce((acc, item) => {
    if (!acc[item.page]) acc[item.page] = [];
    acc[item.page].push(item);
    return acc;
  }, {});

  res.status(200).json({
    status: "success",
    data: { content: groupedContent },
  });
});
