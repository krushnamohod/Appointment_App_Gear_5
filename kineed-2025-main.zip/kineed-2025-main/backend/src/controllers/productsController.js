import prisma from "../utils/prisma.js";
import AppError from "../utils/appError.js";
import catchAsync from "../utils/catchAsync.js";

// ======================================================================
// GET ALL PRODUCTS (NO PAGINATION, NO LIMIT)
// ======================================================================
export const getAllProducts = catchAsync(async (req, res, next) => {
  const { category, brand, search, sortBy = "order", sortOrder = "asc" } = req.query;

  const where = {};

  if (category && category !== "All Categories" && category !== "") {
    where.category = category;
  }

  if (brand && brand !== "All Brands" && brand !== "") {
    where.brand = brand;
  }

  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { description: { contains: search, mode: "insensitive" } },
      { sku: { contains: search, mode: "insensitive" } }
    ];
  }

  const products = await prisma.product.findMany({
    where,
    orderBy: { [sortBy]: sortOrder },
    select: {
      id: true,
      name: true,
      originalPrice: true,
      price: true,
      rating: true,
      category: true,
      inStock: true,
      sku: true,
      brand: true,
      description: true,
      features: true,
      specifications: true,
      images: true,
      mainImage: true,
      isActive: true,
      order: true,
      createdAt: true,
      updatedAt: true,
    }
  });

  res.status(200).json({
    status: "success",
    results: products.length,
    data: { products }
  });
});

// ======================================================================
// GET SINGLE PRODUCT
// ======================================================================
export const getProduct = catchAsync(async (req, res, next) => {
  const product = await prisma.product.findUnique({
    where: { id: req.params.id },
  });

  if (!product) return next(new AppError("Product not found", 404));

  res.status(200).json({ status: "success", data: { product } });
});

// ======================================================================
// CREATE PRODUCT
// ======================================================================
export const createProduct = catchAsync(async (req, res, next) => {
  const {
    name,
    originalPrice,
    price,
    rating,
    category,
    inStock,
    sku,
    brand,
    description,
    features,
    specifications,
    images,
    mainImage
  } = req.body;

  const existingProduct = await prisma.product.findUnique({ where: { sku } });
  if (existingProduct)
    return next(new AppError("Product with this SKU already exists", 400));

  const highestOrder = await prisma.product.aggregate({
    _max: { order: true },
  });

  const nextOrder = (highestOrder._max.order || 0) + 1;

  const product = await prisma.product.create({
    data: {
      name,
      originalPrice: parseFloat(originalPrice),
      price: parseFloat(price),
      rating: rating ? parseFloat(rating) : null,
      category,
      inStock: inStock !== undefined ? !!inStock : true,
      sku,
      brand,
      description,
      features: features || [],
      specifications: specifications || [],
      images: images || [],
      mainImage,
      order: nextOrder,
    },
  });

  res.status(201).json({ status: "success", data: { product } });
});

// ======================================================================
// UPDATE PRODUCT
// ======================================================================
export const updateProduct = catchAsync(async (req, res, next) => {
  const {
    name,
    originalPrice,
    price,
    rating,
    category,
    inStock,
    isActive,
    sku,
    brand,
    description,
    features,
    specifications,
    images,
    mainImage,
    order,
  } = req.body;

  const existingProduct = await prisma.product.findUnique({
    where: { id: req.params.id },
  });
  if (!existingProduct) return next(new AppError("Product not found", 404));

  if (sku && sku !== existingProduct.sku) {
    const skuExists = await prisma.product.findUnique({ where: { sku } });
    if (skuExists)
      return next(new AppError("Product with this SKU already exists", 400));
  }

  const updated = await prisma.product.update({
    where: { id: req.params.id },
    data: {
      ...(name && { name }),
      ...(originalPrice && { originalPrice: parseFloat(originalPrice) }),
      ...(price && { price: parseFloat(price) }),
      ...(rating !== undefined && { rating: rating ? parseFloat(rating) : null }),
      ...(category && { category }),
      ...(inStock !== undefined && { inStock: !!inStock }),
      ...(sku && { sku }),
      ...(brand && { brand }),
      ...(description && { description }),
      ...(features && { features }),
      ...(specifications && { specifications }),
      ...(images && { images }),
      ...(mainImage && { mainImage }),
      ...(isActive !== undefined && { isActive }),
      ...(order !== undefined && { order }),
    },
  });

  res.status(200).json({ status: "success", data: { product: updated } });
});

// ======================================================================
// DELETE PRODUCT + AUTO-FIX ORDER
// ======================================================================
export const deleteProduct = catchAsync(async (req, res, next) => {
  const product = await prisma.product.findUnique({
    where: { id: req.params.id },
  });

  if (!product) return next(new AppError("Product not found", 404));

  await prisma.product.delete({ where: { id: req.params.id } });

  const all = await prisma.product.findMany({ orderBy: { order: "asc" } });

  let index = 0;
  for (const item of all) {
    await prisma.product.update({
      where: { id: item.id },
      data: { order: index++ },
    });
  }

  res.status(204).json({ status: "success", data: null });
});

// ======================================================================
// REORDER PRODUCTS
// ======================================================================
export const reorderProducts = catchAsync(async (req, res, next) => {
  const { list } = req.body;

  if (!Array.isArray(list))
    return next(new AppError("Invalid format: list must be an array", 400));

  for (const item of list) {
    await prisma.product.update({
      where: { id: item.id },
      data: { order: item.order },
    });
  }

  res.status(200).json({ status: "success", message: "Order updated" });
});

// ======================================================================
// CATEGORIES
// ======================================================================
export const getCategories = catchAsync(async (req, res, next) => {
  const categories = await prisma.category.findMany({
    orderBy: { order: "asc" },
  });

  res.status(200).json({
    status: "success",
    results: categories.length,
    data: { categories },
  });
});

export const createCategory = catchAsync(async (req, res, next) => {
  const { name, description, image } = req.body;

  const exists = await prisma.category.findUnique({ where: { name } });
  if (exists) return next(new AppError("Category already exists", 400));

  const highestOrder = await prisma.category.aggregate({
    _max: { order: true },
  });

  const nextOrder = (highestOrder._max.order || 0) + 1;

  const category = await prisma.category.create({
    data: { name, description, image, order: nextOrder },
  });

  res.status(201).json({ status: "success", data: { category } });
});

export const updateCategory = catchAsync(async (req, res, next) => {
  const { name, description, image, order } = req.body;

  const category = await prisma.category.findUnique({
    where: { id: req.params.id },
  });
  if (!category) return next(new AppError("Category not found", 404));

  if (name && name !== category.name) {
    const nameExists = await prisma.category.findUnique({ where: { name } });
    if (nameExists)
      return next(new AppError("Category name already exists", 400));
  }

  const updated = await prisma.category.update({
    where: { id: req.params.id },
    data: {
      ...(name && { name }),
      ...(description && { description }),
      ...(image && { image }),
      ...(order !== undefined && { order }),
    },
  });

  res.status(200).json({ status: "success", data: { category: updated } });
});

export const deleteCategory = catchAsync(async (req, res, next) => {
  const category = await prisma.category.findUnique({
    where: { id: req.params.id },
  });

  if (!category) return next(new AppError("Category not found", 404));

  await prisma.category.delete({ where: { id: req.params.id } });

  const all = await prisma.category.findMany({ orderBy: { order: "asc" } });

  let index = 0;
  for (const item of all) {
    await prisma.category.update({
      where: { id: item.id },
      data: { order: index++ },
    });
  }

  res.status(204).json({ status: "success", data: null });
});

export const reorderCategories = catchAsync(async (req, res, next) => {
  const { list } = req.body;

  for (const item of list) {
    await prisma.category.update({
      where: { id: item.id },
      data: { order: item.order },
    });
  }

  res.status(200).json({ status: "success", message: "Categories reordered" });
});

// ======================================================================
// BRANDS
// ======================================================================
export const getAllBrands = catchAsync(async (req, res, next) => {
  const brands = await prisma.brands.findMany({
    orderBy: { order: "asc" },
  });

  res.status(200).json({
    status: "success",
    results: brands.length,
    data: { brands },
  });
});

export const createBrand = catchAsync(async (req, res, next) => {
  const { name, image } = req.body;

  const exists = await prisma.brands.findUnique({ where: { name } });
  if (exists) return next(new AppError("Brand already exists", 400));

  const highestOrder = await prisma.brands.aggregate({
    _max: { order: true },
  });

  const nextOrder = (highestOrder._max.order || 0) + 1;

  const brand = await prisma.brands.create({
    data: { name, image, order: nextOrder },
  });

  res.status(201).json({ status: "success", data: { brand } });
});

export const updateBrand = catchAsync(async (req, res, next) => {
  const { name, image, order } = req.body;

  const brand = await prisma.brands.findUnique({
    where: { id: req.params.id },
  });
  if (!brand) return next(new AppError("Brand not found", 404));

  if (name && name !== brand.name) {
    const exists = await prisma.brands.findUnique({ where: { name } });
    if (exists)
      return next(new AppError("Brand name already exists", 400));
  }

  const updated = await prisma.brands.update({
    where: { id: req.params.id },
    data: {
      ...(name && { name }),
      ...(image && { image }),
      ...(order !==undefined && { order }),
    },
  });

  res.status(200).json({ status: "success", data: { brand: updated } });
});

export const deleteBrand = catchAsync(async (req, res, next) => {
  const brand = await prisma.brands.findUnique({
    where: { id: req.params.id },
  });
  if (!brand) return next(new AppError("Brand not found", 404));

  await prisma.brands.delete({ where: { id: req.params.id } });

  const all = await prisma.brands.findMany({ orderBy: { order: "asc" } });

  let index = 0;
  for (const item of all) {
    await prisma.brands.update({
      where: { id: item.id },
      data: { order: index++ },
    });
  }

  res.status(204).json({ status: "success", data: null });
});

export const reorderBrands = catchAsync(async (req, res, next) => {
  const { list } = req.body;

  for (const item of list) {
    await prisma.brands.update({
      where: { id: item.id },
      data: { order: item.order },
    });
  }

  res.status(200).json({ status: "success", message: "Brands reordered" });
});

// ======================================================================
// IMAGE UPLOAD
// ======================================================================
export const uploadImages = catchAsync(async (req, res, next) => {
  const { images } = req.body;
  res.status(200).json({ status: "success", data: { images: images || [] } });
});

// ======================================================================
// BULK CREATE PRODUCTS
// ======================================================================
export const bulkCreateProducts = catchAsync(async (req, res, next) => {
  const { products } = req.body;

  if (!Array.isArray(products)) {
    return next(new AppError("Products must be an array", 400));
  }

  // Validate SKU duplicates inside request
  const seen = new Set();
  for (const p of products) {
    if (seen.has(p.sku)) {
      return next(new AppError(`Duplicate SKU in request: ${p.sku}`, 400));
    }
    seen.add(p.sku);
  }

  // Validate SKU duplicates in DB
  const existing = await prisma.product.findMany({
    where: { sku: { in: products.map((p) => p.sku) } },
  });

  if (existing.length > 0) {
    return next(new AppError(`SKU already exists: ${existing[0].sku}`, 400));
  }

  const highestOrder = await prisma.product.aggregate({
    _max: { order: true },
  });

  let nextOrder = (highestOrder._max.order || 0) + 1;

  const createData = [];

  for (const p of products) {
    createData.push({
      name: p.name,
      originalPrice: parseFloat(p.originalPrice),
      price: parseFloat(p.price),
      rating: p.rating ? parseFloat(p.rating) : null,
      category: p.category,
      inStock: p.inStock !== undefined ? p.inStock : true,
      sku: p.sku,
      brand: p.brand,
      description: p.description,
      features: p.features || [],
      specifications: p.specifications || [],
      images: p.images || [],
      mainImage: p.mainImage || "",
      order: nextOrder++,
    });
  }

  const created = await prisma.product.createMany({
    data: createData,
  });

  res.status(201).json({
    status: "success",
    results: created.count,
    data: { created: created.count },
  });
});
