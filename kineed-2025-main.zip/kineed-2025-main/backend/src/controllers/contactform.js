import prisma from "../utils/prisma.js";

export const ContactController = {
  createMessage: async (req, res) => {
    try {
      const { name, email, mobile, message } = req.body;

      if (!name || !email || !mobile || !message)
        return res.status(400).json({ error: "All fields are required." });

      const result = await prisma.contactMessage.create({
        data: { name, email, mobile, message },
      });

      return res.status(201).json(result);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  },

  getMessages: async (req, res) => {
    try {
      const messages = await prisma.contactMessage.findMany({
        orderBy: { createdAt: "desc" },
      });
      return res.status(200).json(messages);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  },

  getMessageById: async (req, res) => {
    try {
      const { id } = req.params;

      const message = await prisma.contactMessage.findUnique({
        where: { id: Number(id) },
      });

      if (!message)
        return res.status(404).json({ error: "Message not found." });

      return res.status(200).json(message);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  },

  updateStatus: async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const validStatuses = ["UNREAD", "IN_PROGRESS", "RESOLVED", "CLOSED"];
      if (!validStatuses.includes(status))
        return res.status(400).json({ error: "Invalid status." });

      const updated = await prisma.contactMessage.update({
        where: { id: Number(id) },
        data: { status },
      });

      return res.status(200).json(updated);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  },

  deleteMessage: async (req, res) => {
    try {
      const { id } = req.params;

      await prisma.contactMessage.delete({
        where: { id: Number(id) },
      });

      return res.status(200).json({ message: "Message deleted successfully." });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  },
};
