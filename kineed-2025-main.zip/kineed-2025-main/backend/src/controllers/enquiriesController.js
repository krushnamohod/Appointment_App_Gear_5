import prisma from "../utils/prisma.js";
import AppError from "../utils/appError.js";
import catchAsync from "../utils/catchAsync.js";

// Get all enquiries (status filter only — NO pagination, NO limit)
export const getAllEnquiries = catchAsync(async (req, res, next) => {
  const { status } = req.query;

  const where = {};
  if (status && status !== "all") {
    where.status = status;
  }

  const enquiries = await prisma.enquiry.findMany({
    where,
    orderBy: { createdAt: "desc" },
  });

  res.status(200).json({
    status: "success",
    results: enquiries.length,
    data: {
      enquiries,
    },
  });
});

// Get a single enquiry
export const getEnquiry = catchAsync(async (req, res, next) => {
  const enquiry = await prisma.enquiry.findUnique({
    where: { id: req.params.id },
  });

  if (!enquiry) {
    return next(new AppError("Enquiry not found", 404));
  }

  res.status(200).json({
    status: "success",
    data: {
      enquiry,
    },
  });
});

// Update enquiry
export const updateEnquiry = catchAsync(async (req, res, next) => {
  const { status, response } = req.body;

  const enquiry = await prisma.enquiry.findUnique({
    where: { id: req.params.id },
  });

  if (!enquiry) {
    return next(new AppError("Enquiry not found", 404));
  }

  const updatedEnquiry = await prisma.enquiry.update({
    where: { id: req.params.id },
    data: {
      ...(status && { status }),
      ...(response && { response }),
    },
  });

  res.status(200).json({
    status: "success",
    data: {
      enquiry: updatedEnquiry,
    },
  });
});

// Delete enquiry
export const deleteEnquiry = catchAsync(async (req, res, next) => {
  const enquiry = await prisma.enquiry.findUnique({
    where: { id: req.params.id },
  });

  if (!enquiry) {
    return next(new AppError("Enquiry not found", 404));
  }

  await prisma.enquiry.delete({
    where: { id: req.params.id },
  });

  res.status(204).json({
    status: "success",
    data: null,
  });
});

// Create enquiry
export const createEnquiry = catchAsync(async (req, res, next) => {
  const { name, email, phone, subject, message } = req.body;

  const enquiry = await prisma.enquiry.create({
    data: {
      name,
      email,
      phone,
      subject,
      message,
    },
  });

  res.status(201).json({
    status: "success",
    data: {
      enquiry,
    },
  });
});
