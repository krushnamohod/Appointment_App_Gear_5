import prisma from "../utils/prisma.js";

export const phonepeWebhook = async (req, res) => {
  try {
    // req.body is raw buffer because of express.raw()
    const body = JSON.parse(req.body.toString());

    // PhonePe may send different keys — handle all
    const merchantOrderId =
      body.merchantOrderId ||
      body.orderId ||
      body.orderNo;

    const state = body.state;
    const transactionId = body.transactionId || body.txnId;

    if (!merchantOrderId) {
      console.error("Webhook Error: Missing merchantOrderId", body);
      return res.status(400).send("Invalid payload");
    }

    // Map PhonePe state to your enums
    let paymentStatus = "PAYMENT_FAILED";
    let orderStatus = "CANCELLED";

    if (state === "COMPLETED") {
      paymentStatus = "PAYMENT_SUCCESS";
      orderStatus = "COMPLETED";
    } else if (state === "PENDING" || state === "CREATED") {
      paymentStatus = "PAYMENT_PENDING";
      orderStatus = "PROCESSING";
    } else if (state === "FAILED") {
      paymentStatus = "PAYMENT_FAILED";
      orderStatus = "CANCELLED";
    }

    // Update DB
    await prisma.order.updateMany({
      where: { orderId: merchantOrderId },
      data: {
        paymentStatus,
        status: orderStatus,
        transactionId,
        providerReferenceId:
          body.providerReferenceId || body.bankReferenceNumber || null,
        paymentMeta: body, // STORE JSON NOT RAW BUFFER
      },
    });

    // Must respond with 200 fast
    res.status(200).send("OK");
  } catch (err) {
    console.log("Webhook error:", err);
    res.status(500).send("Webhook error");
  }
};
