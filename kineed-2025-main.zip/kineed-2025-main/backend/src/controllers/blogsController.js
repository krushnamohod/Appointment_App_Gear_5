import prisma from "../utils/prisma.js";

// Reorder function to normalize order values
async function reorderBlogs() {
  const blogs = await prisma.blogs.findMany({
    orderBy: { order: "asc" },
  });

  const updates = blogs.map((blog, index) =>
    prisma.blogs.update({
      where: { id: blog.id },
      data: { order: index + 1 },
    })
  );

  await Promise.all(updates);
}

// CREATE BLOG
export const createBlog = async (req, res) => {
  try {
    const { title, author, image, description } = req.body;

    const lastBlog = await prisma.blogs.findFirst({
      orderBy: { order: "desc" },
    });

    const nextOrder = lastBlog ? lastBlog.order + 1 : 1;

    const newBlog = await prisma.blogs.create({
      data: {
        title,
        author,
        image,
        description,
        order: nextOrder,
      },
    });

    return res.status(201).json(newBlog);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// GET ALL BLOGS
export const getBlogs = async (req, res) => {
  try {
    const blogs = await prisma.blogs.findMany({
      orderBy: { order: "asc" },
    });

    return res.status(200).json(blogs);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// GET SINGLE BLOG
export const getBlogById = async (req, res) => {
  try {
    const { id } = req.params;

    const blog = await prisma.blogs.findUnique({ where: { id } });

    if (!blog) return res.status(404).json({ message: "Blog not found" });

    return res.status(200).json(blog);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// UPDATE BLOG
export const updateBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, author, image, description } = req.body;

    const updatedBlog = await prisma.blogs.update({
      where: { id },
      data: { title, author, image, description },
    });

    return res.status(200).json(updatedBlog);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// DELETE BLOG WITH AUTO-REORDER
export const deleteBlog = async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.blogs.delete({ where: { id } });

    await reorderBlogs();

    return res.status(200).json({
      message: "Blog deleted and order adjusted",
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// UPDATE ORDER (DND)
export const updateBlogOrder = async (req, res) => {
  try {
    const { order } = req.body;

    if (!Array.isArray(order)) {
      return res.status(400).json({ message: "Invalid order format" });
    }

    const updates = order.map((item) =>
      prisma.blogs.update({
        where: { id: item.id },
        data: { order: item.order },
      })
    );

    await Promise.all(updates);

    return res.status(200).json({
      message: "Order updated successfully",
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};
