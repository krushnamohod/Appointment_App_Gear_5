import prisma from "../utils/prisma.js";
import AppError from "../utils/appError.js";
import catchAsync from "../utils/catchAsync.js";

// ======================================================================
// GET ALL REVIEWS
// ======================================================================
export const getAllReviews = catchAsync(async (req, res, next) => {
  const { status, showOnWebsite } = req.query;

  const where = {};

  if (status && status !== "all") {
    where.status = status;
  }

  if (showOnWebsite !== undefined) {
    where.showOnWebsite = showOnWebsite === "true";
  }

  const [reviews, total] = await Promise.all([
    prisma.review.findMany({
      where,
      orderBy: { createdAt: "desc" },
    }),
    prisma.review.count({ where }),
  ]);

  res.status(200).json({
    status: "success",
    results: reviews.length,
    data: { reviews, total },
  });
});

// ======================================================================
// UPDATE REVIEW
// ======================================================================
export const updateReview = catchAsync(async (req, res, next) => {
  const { showOnWebsite, status } = req.body;

  const review = await prisma.review.findUnique({
    where: { id: req.params.id },
  });

  if (!review) {
    return next(new AppError("Review not found", 404));
  }

  const updatedReview = await prisma.review.update({
    where: { id: req.params.id },
    data: {
      ...(showOnWebsite !== undefined && { showOnWebsite }),
      ...(status && { status }),
    },
  });

  res.status(200).json({
    status: "success",
    data: { review: updatedReview },
  });
});

// ======================================================================
// DELETE REVIEW
// ======================================================================
export const deleteReview = catchAsync(async (req, res, next) => {
  const review = await prisma.review.findUnique({
    where: { id: req.params.id },
  });

  if (!review) {
    return next(new AppError("Review not found", 404));
  }

  await prisma.review.delete({
    where: { id: req.params.id },
  });

  res.status(204).json({ status: "success", data: null });
});

// ======================================================================
// CREATE SINGLE REVIEW
// ======================================================================
export const createReview = catchAsync(async (req, res, next) => {
  const { customerName, customerEmail, rating, comment, product } = req.body;

  const review = await prisma.review.create({
    data: {
      customerName,
      customerEmail,
      rating: parseInt(rating),
      comment,
      product,
    },
  });

  res.status(201).json({
    status: "success",
    data: { review },
  });
});

// ======================================================================
// BULK IMPORT REVIEWS
// ======================================================================
export const createReviewsBulk = catchAsync(async (req, res, next) => {
  const { reviews } = req.body;

  if (!Array.isArray(reviews) || reviews.length === 0) {
    return next(new AppError("Provide a valid non-empty 'reviews' array", 400));
  }

  const invalidItem = reviews.find(
    (r) =>
      !r.id ||
      !r.customerName ||
      !r.customerEmail ||
      r.rating === undefined ||
      !r.comment ||
      !r.createdAt ||
      !r.updatedAt
  );

  if (invalidItem) {
    return next(
      new AppError(
        "Every review must contain id, customerName, customerEmail, rating, comment, createdAt, updatedAt",
        400
      )
    );
  }

  const formattedReviews = reviews.map((r) => ({
    id: r.id,
    customerName: r.customerName,
    customerEmail: r.customerEmail,
    rating: parseInt(r.rating),
    comment: r.comment,
    product: r.product || null,
    showOnWebsite: r.showOnWebsite ?? false,
    status: r.status || "PENDING",
    createdAt: new Date(r.createdAt),
    updatedAt: new Date(r.updatedAt),
  }));

  const response = await prisma.review.createMany({
    data: formattedReviews,
    skipDuplicates: true,
  });

  res.status(201).json({
    status: "success",
    count: response.count,
    message: `${response.count} reviews imported successfully`,
  });
});
