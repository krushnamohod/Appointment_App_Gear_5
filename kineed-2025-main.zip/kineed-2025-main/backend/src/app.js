// src/app.js
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";

// Import routes
import authRoutes from "./routes/auth.js";
import ordersRoutes from "./routes/orders.js";
import reviewsRoutes from "./routes/reviews.js";
import enquiriesRoutes from "./routes/enquiries.js";
import websiteRoutes from "./routes/website.js";
import productsRoutes from "./routes/products.js";
import contactsRoutes from "./routes/contact.js";
import contactformRoutes from "./routes/contactform.js";
import aboutRoutes from "./routes/about.js";
import policyRoutes from "./routes/policy.js";
import blogsRoutes from "./routes/blogs.js";
import homeRoutes from "./routes/home.js";

// Add the new routes
import otpRoutes from "./routes/otp.js";
import checkoutRoutes from "./routes/checkout.js";

const app = express();

// Global Middleware
app.use(helmet());
app.use(cors({
  origin: [
    "http://localhost:3000",
    "https://api.kineed.in",
    "https://kineed.in",
    "https://www.kineed.in",
     "http://localhost:5112"
  ],
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
  credentials: true,
  exposedHeaders: ['Location']
}));
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/reviews', reviewsRoutes);
app.use('/api/enquiries', enquiriesRoutes);
app.use('/api/website', websiteRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/contact', contactsRoutes);
app.use('/api/contactfrom', contactformRoutes);
app.use('/api/about', aboutRoutes);
app.use("/api/policy", policyRoutes);
app.use("/api/blogs", blogsRoutes);
app.use("/api/home", homeRoutes);

// Add the new routes
app.use("/api/otp", otpRoutes);
app.use("/api/checkout", checkoutRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Server is running',
    timestamp: new Date().toISOString(),
  });
});

// Handle undefined routes
app.all('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.originalUrl} not found`
  });
});

export default app;