import dotenv from "dotenv";
dotenv.config();

import app from "./src/app.js";
import prisma from "./src/utils/prisma.js";

const PORT = process.env.PORT || 4007;

const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV}`);
});

// Handle server errors (e.g. port already in use)
server.on("error", (err) => {
  if (err && err.code === "EADDRINUSE") {
    console.error(`Error: Port ${PORT} is already in use.`);
    console.error(
      "Please stop the process using that port or set a different PORT in your .env"
    );
    process.exit(1);
  }
  console.error("Server error:", err);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (err) => {
  console.log("UNHANDLED REJECTION! 💥 Shutting down...");
  console.log(err.name, err.message);
  server.close(() => {
    process.exit(1);
  });
});

// Handle SIGTERM
process.on("SIGTERM", () => {
  console.log("👋 SIGTERM RECEIVED. Shutting down gracefully");
  server.close(() => {
    console.log("💥 Process terminated!");
  });
});

// Graceful shutdown - CTRL + C
process.on("SIGINT", async () => {
  console.log("👋 SIGINT RECEIVED. Shutting down gracefully");
  await prisma.$disconnect();
  server.close(() => {
    console.log("💥 Process terminated!");
    process.exit(0);
  });
});
