"use client";
import React, { useState, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { slugify } from "@/utils/slugify";
import { getDiscountPercentage } from "@/utils/getDiscountPercentage";
import StarRating from "@/utils/StarRating";
import QuantitySelector from "@/utils/QuantitySelector";

const Productcard = ({ product }) => {
  const router = useRouter();
  const [qty, setQty] = useState(0);

  // Load initial quantity from localStorage
  useEffect(() => {
    const storedCart = localStorage.getItem("cartItems");
    if (storedCart) {
      const parsed = JSON.parse(storedCart);
      const item = parsed.find((i) => i.id === product.id);
      setQty(item ? item.quantity : 0);
    }

    const handleCartUpdated = () => {
      const storedCart = localStorage.getItem("cartItems");
      if (storedCart) {
        const parsed = JSON.parse(storedCart);
        const item = parsed.find((i) => i.id === product.id);
        setQty(item ? item.quantity : 0);
      } else setQty(0);
    };

    window.addEventListener("cartUpdated", handleCartUpdated);
    return () => window.removeEventListener("cartUpdated", handleCartUpdated);
  }, [product.id]);

  const updateCart = (newQty) => {
    if (typeof window === "undefined") return;

    let storedCart = localStorage.getItem("cartItems");
    let cart = storedCart ? JSON.parse(storedCart) : [];

    const existingIndex = cart.findIndex((i) => i.id === product.id);

    if (existingIndex !== -1) {
      if (newQty > 0) cart[existingIndex].quantity = newQty;
      else cart.splice(existingIndex, 1); // remove if qty 0
    } else if (newQty > 0) {
      cart.push({ ...product, quantity: newQty });
    }

    localStorage.setItem("cartItems", JSON.stringify(cart));
    window.dispatchEvent(new Event("cartUpdated"));
  };

  const handleIncrease = (e) => {
    e.stopPropagation();
    const newQty = qty + 1;
    setQty(newQty);
    updateCart(newQty);
  };

  const handleDecrease = (e) => {
    e.stopPropagation();
    const newQty = Math.max(0, qty - 1); // prevent negative
    setQty(newQty);
    updateCart(newQty);
  };

  const handleAdd = (e) => {
    e.stopPropagation();
    if (qty === 0) {
      setQty(1);
      updateCart(1);
    }
  };

  return (
    <div
      onClick={() => router.push(`/pd/${slugify(product.name)}`)}
      className="bg-white rounded-xl border border-neutral-300 shadow hover:shadow-lg transition overflow-hidden flex flex-col cursor-pointer h-full"
    >
      {/* IMAGE SECTION */}
      <div className="relative w-full aspect-[4/3] bg-white flex items-center justify-center">
        <Image
          src={product.mainImage || "/placeholder.jpg"}
          alt={product.name}
          fill
          className="object-contain p-2"
        />

        {!product.inStock && (
          <div className="absolute z-50 px-2 py-1 bg-red-400 text-white text-[10px] font-semibold rounded-br shadow">
            Out of Stock
          </div>
        )}

        {product.originalPrice > product.price && (
          <div className="absolute top-0 right-2">
            <svg
              width="30"
              height="29"
              viewBox="0 0 29 28"
              className="drop-shadow-md"
            >
              <path
                d="M28.9499 0C28.3999 0 27.9361 1.44696 27.9361 2.60412V27.9718L24.5708 25.9718L21.2055 27.9718L17.8402 25.9718L14.4749 27.9718L11.1096 25.9718L7.74436 27.9718L4.37907 25.9718L1.01378 27.9718V2.6037C1.01378 1.44655 0.549931 0 0 0H28.9499Z"
                fill="#c54822"
              />
            </svg>
            <span className="absolute top-0.5 left-1/2 -translate-x-1/2 text-[8px] font-bold text-white">
              {getDiscountPercentage(product.originalPrice, product.price)}% OFF
            </span>
          </div>
        )}
      </div>

      {/* CONTENT SECTION */}
      <div className="p-3 flex flex-col flex-1 justify-between">
        {/* TITLE + BRAND + RATING */}
        <div>
          <h3 className="font-semibold text-sm line-clamp-2 min-h-[38px] leading-snug">
            {product.name}
          </h3>

          <p className="text-xs text-gray-500">{product.brand}</p>

          <div className="mt-1">
            <StarRating rating={product.rating} />
          </div>
        </div>

        {/* PRICE + QUANTITY */}
        <div className="flex justify-between items-center mt-3">
          <div>
            <p className="text-sm font-bold">₹{product.price}</p>
            {product.originalPrice > product.price && (
              <p className="text-xs text-gray-400 line-through">
                ₹{product.originalPrice}
              </p>
            )}
          </div>

          <QuantitySelector
            quantity={qty}
            onIncrease={handleIncrease}
            onDecrease={handleDecrease}
            onAdd={handleAdd}
          />
        </div>
      </div>
    </div>
  );
};

export default Productcard;
