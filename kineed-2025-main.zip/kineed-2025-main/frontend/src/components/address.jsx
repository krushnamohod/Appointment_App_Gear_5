"use client";

import { useState, useEffect } from "react";

export default function DynamicAddress() {
  const [info, setInfo] = useState(null);

  const fetchContactData = async () => {
    try {
      const res = await fetch("https://api.kineed.in/api/contact");
      const data = await res.json();

      if (data?.status === "success") {
        setInfo(data.data.contactInfo);
      }
    } catch (err) {
      console.error("Failed to load contact info", err);
    }
  };

  useEffect(() => {
    fetchContactData();
  }, []);

  if (!info) return null;

  return (
    <address className="mt-4 not-italic">
      <p>{info.companyName || "Ghrutika Agro"}</p>
      <p>Email: {info.email}</p>
      <p>Phone: +91 {info.phone}</p>
      {info.address && <p>{info.address}</p>}
    </address>
  );
}
