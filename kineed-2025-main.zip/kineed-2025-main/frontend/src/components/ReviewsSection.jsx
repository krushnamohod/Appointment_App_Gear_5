"use client";

import { useRef, useState, useEffect } from "react";
import Image from "next/image";
import {
  ChevronLeft,
  ChevronRight,
  Star,
  StarHalf,
  X,
  CheckCircle,
} from "lucide-react";

export default function ReviewsSection() {
  const scrollRef = useRef(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState("");

  const [formData, setFormData] = useState({
    name: "",
    number: "",
    email: "",
    review: "",
    rating: 0,
  });

  // 🌐 Fetch reviews from API
  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/reviews");
        const data = await res.json();

        if (data.status === "success" && data.data?.reviews) {
          // ✅ Show only approved + visible reviews
          const visibleReviews = data.data.reviews.filter(
            (r) => r.showOnWebsite
          );
          setReviews(visibleReviews);
        } else {
          setError("Failed to load reviews.");
        }
      } catch (err) {
        console.error("Error fetching reviews:", err);
        setError("Error fetching reviews.");
      } finally {
        setLoading(false);
      }
    };

    fetchReviews();
  }, []);

  // Scroll controls
  const updateScrollButtons = () => {
    const el = scrollRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 0);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth);
  };

  const scroll = (direction) => {
    const el = scrollRef.current;
    if (!el) return;
    const scrollAmount = el.clientWidth * 0.9;
    el.scrollBy({
      left: direction === "right" ? scrollAmount : -scrollAmount,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    updateScrollButtons();
    el.addEventListener("scroll", updateScrollButtons);
    return () => el.removeEventListener("scroll", updateScrollButtons);
  }, [reviews]);

  // Render star rating
  const renderStars = (rating = 0) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star
          key={`full-${i}`}
          className="h-4 w-4 fill-amber-300 text-amber-300"
        />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <StarHalf
          key="half"
          className="h-4 w-4 fill-amber-300 text-amber-300"
        />
      );
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="h-4 w-4 text-gray-300" />);
    }

    return stars;
  };

  // Form logic
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleStarClick = (ratingValue) => {
    setFormData((prev) => ({ ...prev, rating: ratingValue }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.rating === 0) {
      setPopupMessage("Please select a rating before submitting.");
      setShowPopup(true);
      setTimeout(() => setShowPopup(false), 2500);
      return;
    }

    try {
      const res = await fetch("https://api.kineed.in/api/reviews", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerName: formData.name,
          customerEmail: formData.email,
          phoneNumber: formData.number,
          comment: formData.review,
          rating: formData.rating,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        setPopupMessage("Thank you for your review!");
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 3000);

        setShowForm(false);
        setFormData({ name: "", number: "", email: "", review: "", rating: 0 });
      } else {
        setPopupMessage(
          data.message || "Failed to submit review. Please try again."
        );
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 3000);
      }
    } catch (error) {
      console.error(error);
      setPopupMessage("An error occurred. Please try again.");
      setShowPopup(true);
      setTimeout(() => setShowPopup(false), 3000);
    }
  };

  return (
    <section className="py-6 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold tracking-tight">
            Customer Reviews
          </h2>
          <p className="text-gray-600 mt-2 max-w-3xl mx-auto">
            Don't just take our word for it. See what our customers have to say
            about their shopping experience.
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="mt-4 px-5 py-2 bg-blue-200 text-blue-900 rounded-lg hover:bg-blue-300 transition"
          >
            Give Your Review
          </button>
        </div>

        {/* Reviews Carousel */}
        {loading ? (
          <p className="text-center text-gray-500">Loading reviews...</p>
        ) : error ? (
          <p className="text-center text-red-500">{error}</p>
        ) : reviews.length === 0 ? (
          <p className="text-center text-gray-500">No reviews yet.</p>
        ) : (
          <div className="relative">
            {canScrollLeft && (
              <button
                onClick={() => scroll("left")}
                className="absolute left-0 top-1/2 -translate-y-1/2 z-10 rounded-full p-1 shadow bg-white"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}
            {canScrollRight && (
              <button
                onClick={() => scroll("right")}
                className="absolute right-0 top-1/2 -translate-y-1/2 z-10 rounded-full p-1 shadow bg-white"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            )}

            <div
              ref={scrollRef}
              className="flex gap-6 scroll-smooth py-2 snap-x snap-mandatory overflow-x-hidden"
            >
              {reviews.map((review) => (
                <div
                  key={review.id}
                  className="min-w-[340px] md:min-w-[350px] lg:min-w-[390px] max-w-sm snap-start rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden border border-gray-200 bg-white"
                >
                  <div className="h-2 bg-green-600 w-full" />
                  <div className="p-4">
                    <div className="flex items-center gap-4 mb-2">
                      <div className="relative h-12 w-12 overflow-hidden rounded-full">
                        <Image
                          src={"/images/Icon.jpg"}
                          alt={review.customerName || "Customer"}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium">{review.customerName}</h3>
                        <div className="flex items-center gap-0.5 mt-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">
                      {new Date(
                        review.createdAt || Date.now()
                      ).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                    <p className="text-sm">{review.comment}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Review Popup Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-4 sm:px-6">
          <div
            className="bg-white rounded-xl shadow-xl w-full max-w-md p-5 sm:p-6 relative 
                 animate-fadeIn overflow-y-auto max-h-[90vh]"
          >
            {/* Close Button */}
            <button
              onClick={() => setShowForm(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-800 transition"
            >
              <X size={22} />
            </button>

            {/* Title */}
            <h3 className="text-lg sm:text-xl font-semibold mb-4 text-center">
              Give Your Review
            </h3>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-3">
              {/* Name */}
              <div>
                <label className="text-sm font-medium">Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full border rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none 
                       focus:ring-2 focus:ring-green-500 transition"
                />
              </div>

              {/* Phone Number */}
              <div>
                <label className="text-sm font-medium">Phone Number</label>
                <input
                  type="tel"
                  name="number"
                  value={formData.number}
                  onChange={handleChange}
                  maxLength={10}
                  required
                  className="w-full border rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none 
                       focus:ring-2 focus:ring-green-500 transition"
                />
              </div>

              {/* Email */}
              <div>
                <label className="text-sm font-medium">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full border rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none 
                       focus:ring-2 focus:ring-green-500 transition"
                />
              </div>

              {/* Rating */}
              <div>
                <label className="text-sm font-medium">Rating</label>
                <div className="flex items-center gap-1 mt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      onClick={() => handleStarClick(star)}
                      className={`h-6 w-6 cursor-pointer transition ${
                        star <= formData.rating
                          ? "fill-amber-400 text-amber-400"
                          : "text-gray-300 hover:text-amber-400"
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Review */}
              <div className="relative">
                <label className="text-sm font-medium">Review</label>
                <textarea
                  name="review"
                  value={formData.review}
                  onChange={handleChange}
                  rows="3"
                  required
                  maxLength={200}
                  className="w-full border rounded-lg px-3 py-2 mt-1 text-sm resize-none 
                       focus:outline-none focus:ring-2 focus:ring-green-500 transition"
                />
                <span className="absolute bottom-2 right-3 text-xs text-gray-500">
                  {formData.review.length}/200
                </span>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-blue-200 text-blue-900 py-2 rounded-lg font-medium 
                     hover:bg-blue-300 active:scale-[0.98] transition-all duration-200"
              >
                Submit Review
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ✅ Popup */}
      {showPopup && (
        <div className="fixed bottom-6 right-6 bg-green-600 text-white px-5 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-fadeInOut z-50">
          <CheckCircle size={20} />
          <span className="text-sm">{popupMessage}</span>
        </div>
      )}
    </section>
  );
}
