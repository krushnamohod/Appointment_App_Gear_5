"use client";

import { useState, useEffect } from "react";
import { Plus, Minus } from "lucide-react";
import { FaWhatsapp, FaFacebook, FaInstagram, FaGoogle, FaPhoneAlt } from "react-icons/fa";

export default function SocialFloatingButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [info, setInfo] = useState(null);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  // FETCH CONTACT DATA
  const fetchData = async () => {
    try {
      const res = await fetch("https://api.kineed.in/api/contact");
      const data = await res.json();

      if (data?.status === "success") {
        setInfo(data.data.contactInfo);
      }
    } catch (err) {
      console.log("Error loading contact info", err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (!info) return null;

  // Build WhatsApp link
  const whatsappNumber = info.whatsapp || info.phone || "";
  const whatsappLink =
    whatsappNumber &&
    `https://wa.me/91${whatsappNumber}?text=Enquiry From Website : I want to know more about Kineed and its Products`;

  return (
    <div className="fixed bottom-40 right-5 z-50 flex flex-col items-center space-y-3">

      {/* Social Buttons */}
      {isOpen && (
        <div className="flex flex-col items-center space-y-3 mb-3 animate-fade-in">

          {/* WhatsApp */}
          {whatsappNumber && (
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-green-500 text-white shadow-md hover:bg-green-600 transition-all"
            >
              <FaWhatsapp className="w-5 h-5" />
            </a>
          )}

          {/* Phone Button */}
          {info.phone && (
            <a
              href={`tel:${info.phone}`}
              className="p-3 rounded-full bg-gray-700 text-white shadow-md hover:bg-gray-800 transition-all"
            >
              <FaPhoneAlt className="w-5 h-5" />
            </a>
          )}

          {/* Facebook */}
          {info.facebook && (
            <a
              href={info.facebook}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-blue-600 text-white shadow-md hover:bg-blue-700 transition-all"
            >
              <FaFacebook className="w-5 h-5" />
            </a>
          )}

          {/* Instagram */}
          {info.instagram && (
            <a
              href={info.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-pink-500 text-white shadow-md hover:bg-pink-600 transition-all"
            >
              <FaInstagram className="w-5 h-5" />
            </a>
          )}

          {/* Google Business */}
          {info.googleBusiness && (
            <a
              href={info.googleBusiness}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-red-500 text-white shadow-md hover:bg-red-600 transition-all"
            >
              <FaGoogle className="w-5 h-5" />
            </a>
          )}
        </div>
      )}

      {/* Main Floating Button */}
      <button
        onClick={toggleMenu}
        className="fixed p-3 bottom-30 right-5 rounded-full bg-green-400 text-white shadow-lg hover:bg-green-500 transition-all"
      >
        {isOpen ? <Minus className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
      </button>

      {/* Fade Animation */}
      <style jsx global>{`
        .animate-fade-in {
          animation: fadeIn 0.3s ease-in-out;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
