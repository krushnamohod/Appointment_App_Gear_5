"use client";
import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";

export default function Categories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch(
          "https://api.kineed.in/api/products/categories/all"
        );
        if (!res.ok) throw new Error("Failed to fetch categories");

        const result = await res.json();
        const categoriesArray = result.data.categories;

        // Deduplicate (optional)
        const uniqueCategories = Array.from(
          new Map(categoriesArray.map((c) => [c.name, c.image])).entries()
        ).map(([category, image]) => ({ category, image }));

        setCategories(uniqueCategories);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  /* ------------------------------------------------
     LOADING STATE
  -------------------------------------------------- */
  if (loading) {
    return (
      <section className="py-16 flex justify-center items-center">
        <p className="text-gray-500 text-lg">Loading categories...</p>
      </section>
    );
  }

  /* ------------------------------------------------
     EMPTY STATE
  -------------------------------------------------- */
  if (!loading && categories.length === 0) {
    return (
      <section className="py-20 flex flex-col justify-center items-center text-center">
        <h3 className="text-xl font-semibold text-gray-700">
          No Categories Found
        </h3>
        <p className="text-gray-500 mt-2">
          Please add categories from your admin panel.
        </p>
      </section>
    );
  }

  /* ------------------------------------------------
     MAIN UI
  -------------------------------------------------- */
  return (
    <section className="py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap gap-5 justify-center">
        {categories.map((cat, idx) => (
          <Link
            href={`/cp/${encodeURIComponent(cat.category)}`}
            key={idx}
            className="group block bg-white transition-shadow overflow-hidden min-w-[100px]"
          >
            <div className="relative w-14 h-14 sm:w-20 sm:h-20 bg-blue-100/70 rounded-md flex items-center justify-center">
              {cat.image ? (
                <Image
                  src={cat.image}
                  alt={cat.category}
                  fill
                  className="object-contain group-hover:scale-105 transition-transform duration-300"
                  priority
                />
              ) : (
                <span className="text-gray-500 text-sm">No Image</span>
              )}
            </div>

            <div className="text-center mt-2">
              <h3 className="text-sm sm:text-base font-semibold text-gray-700 group-hover:text-blue-600 transition-colors">
                {cat.category || "PRODUCT"}
              </h3>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
