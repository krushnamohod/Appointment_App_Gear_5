"use client";

import { useRef, useState, useEffect } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Productcard from "./Productcard";

export default function OurProducts() {
  const scrollRefs = useRef({});
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  /* -------------------------------------------------------
     FETCH PRODUCTS
  -------------------------------------------------------- */
  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await fetch("https://api.kineed.in/api/products");
        const data = await res.json();

        if (data.status === "success") {
          const activeProducts = data.data.products.filter(
            (p) => p.isActive === true
          );

          setProducts(activeProducts);

          const uniqueCategories = [
            ...new Set(activeProducts.map((p) => p.category)),
          ];
          setCategories(uniqueCategories);
        }
      } catch (err) {
        console.error("Failed to fetch products:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, []);

  /* -------------------------------------------------------
     ADD TO CART
  -------------------------------------------------------- */
  const handleAddToCart = (product) => {
    if (typeof window === "undefined") return;

    let cart = localStorage.getItem("cartItems");
    cart = cart ? JSON.parse(cart) : [];

    const existingIndex = cart.findIndex((p) => p.id === product.id);

    if (existingIndex !== -1) {
      cart[existingIndex].quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }

    localStorage.setItem("cartItems", JSON.stringify(cart));
    window.dispatchEvent(new Event("cartUpdated"));
  };

  /* -------------------------------------------------------
     SCROLL
  -------------------------------------------------------- */
  const scroll = (category, direction) => {
    const container = scrollRefs.current[category];
    if (container) {
      container.scrollBy({
        left: direction === "left" ? -300 : 300,
        behavior: "smooth",
      });
    }
  };

  /* -------------------------------------------------------
     LOADING SKELETON
  -------------------------------------------------------- */
  if (loading) {
    return (
      <section className="py-10">
        <div className="max-w-7xl mx-auto px-5">
          {[1, 2].map((section) => (
            <div key={section} className="mb-10">
              <div className="h-6 w-48 bg-gray-200 animate-pulse rounded mb-4" />

              <div className="flex gap-6 overflow-x-auto">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div
                    key={i}
                    className="min-w-[210px] p-5 bg-gray-100 rounded-lg animate-pulse h-[250px]"
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  /* -------------------------------------------------------
     IF NO PRODUCTS
  -------------------------------------------------------- */
  if (!loading && products.length === 0) {
    return (
      <section className="py-20 flex flex-col justify-center items-center text-center">
        <h3 className="text-xl font-semibold text-gray-700">
          No Products Found
        </h3>
        <p className="text-gray-500 mt-2">
          Please add products from the admin panel.
        </p>
      </section>
    );
  }

  /* -------------------------------------------------------
     MAIN COMPONENT
  -------------------------------------------------------- */
  return (
    <section>
      <div className="container mx-auto max-w-7xl">
        {categories.map((category) => {
          const filteredProducts = products.filter(
            (p) => p.category === category
          );

          if (!filteredProducts.length) return null;

          return (
            <div key={category} className="mb-10">
              {/* Category Header */}
              <div className="flex items-center px-5 justify-between">
                <h2 className="text-2xl font-medium text-gray-600">
                  {category}
                </h2>

                {filteredProducts.length > 6 && (
                  <Link
                    href={`/cp/${encodeURIComponent(category)}`}
                    className="text-blue-600 font-medium hover:underline"
                  >
                    See All
                  </Link>
                )}
              </div>

              {/* Scrollable Row */}
              <div className="relative">
                {/* LEFT BUTTON */}
                {filteredProducts.length > 6 && (
                  <button
                    onClick={() => scroll(category, "left")}
                    className="absolute -left-4 top-1/2 -translate-y-1/2 border-blue-400 border-2 bg-white shadow-md rounded-full p-2 z-10 hover:bg-gray-100"
                  >
                    <ChevronLeft className="h-5 w-5 text-gray-700" />
                  </button>
                )}

                <div
                  ref={(el) => (scrollRefs.current[category] = el)}
                  className="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth p-5"
                >
                  {filteredProducts.map((product) => (
                    <div key={product.id} className=" w-full min-w-[180px] max-w-[180px]">
                      <Productcard
                        product={product}
                        addToCart={() => handleAddToCart(product)}
                      />
                    </div>
                  ))}
                </div>

                {/* RIGHT BUTTON */}
                {filteredProducts.length > 6 && (
                  <button
                    onClick={() => scroll(category, "right")}
                    className="absolute -right-4 top-1/2 -translate-y-1/2 bg-white border-blue-400 border-2 shadow-md rounded-full p-2 z-10 hover:bg-gray-100"
                  >
                    <ChevronRight className="h-5 w-5 text-gray-700" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
