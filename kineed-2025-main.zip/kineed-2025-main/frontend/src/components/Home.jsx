"use client";

import { useState, useEffect } from "react";
import Image from "next/image";

const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

export default function HeroSection() {
  const [currentImage, setCurrentImage] = useState(0);
  const [heroImages, setHeroImages] = useState([]);
  const [logo, setLogo] = useState(null);

  /* -----------------------------------------
     FETCH SLIDER IMAGES + LOGO FROM HOME API
  ------------------------------------------ */
  useEffect(() => {
    const fetchHero = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/home");
        const json = await res.json();
        const home = json?.data?.[0];

        if (!home) return;

        // Slider images
        if (home.sliderimages?.length > 0) {
          const fullUrls = home.sliderimages.map(
            (img) => `${MEDIA_DOWNLOAD}/${img}`
          );
          setHeroImages(fullUrls);
        }

        // Logo dynamic
        if (home.logo) {
          setLogo(`${MEDIA_DOWNLOAD}/${home.logo}`);
        }
      } catch (error) {
        console.error("Failed to load slider/home data:", error);
      }
    };

    fetchHero();
  }, []);

  /* -----------------------------------------
     AUTO SLIDER
  ------------------------------------------ */
  useEffect(() => {
    if (heroImages.length === 0) return;

    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % heroImages.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [heroImages]);

  /* -----------------------------------------
     FALLBACK (NO IMAGES)
  ------------------------------------------ */
  if (heroImages.length === 0) {
    return (
      <section className="relative mt-16 h-40 md:h-120 w-full bg-gray-100 flex flex-col items-center justify-center text-center transition-all duration-700">
        {/* LOGO (dynamic / text fallback) */}
        {logo ? (
          <img
            src={logo}
            alt="Brand Logo"
            className="h-20 w-auto mb-3 object-contain opacity-90"
          />
        ) : (
          <h1 className="text-3xl font-bold text-gray-700 mb-2">
            KINEED Kitchen Appliances
          </h1>
        )}

        {/* Text Content */}
        <p className="text-gray-500 text-lg max-w-xl px-4">
          Your Trusted Partner for Modern Kitchen Solutions
        </p>
      </section>
    );
  }

  /* -----------------------------------------
     MAIN HERO SLIDER
  ------------------------------------------ */
  return (
    <section className="relative mt-16 h-40 md:h-120 w-full overflow-hidden">
      <Image
        src={heroImages[currentImage]}
        alt="Hero Banner"
        fill
        priority
        className="object-cover transition-opacity duration-700"
      />
    </section>
  );
}
