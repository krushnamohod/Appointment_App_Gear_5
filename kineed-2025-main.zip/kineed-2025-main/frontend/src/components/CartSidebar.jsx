"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X, ShoppingCart, CreditCard, Loader2, Mail, Shield, User, MapPin, Phone, Home } from "lucide-react";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import axios from "axios";

const CartSidebar = ({ cartOpen, setCartOpen }) => {
  const [cartItems, setCartItems] = useState([]);
  const [productsData, setProductsData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState(0); // 0: cart, 1: email, 2: OTP, 3: user info, 4: payment
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
  });
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [otpId, setOtpId] = useState("");

  const pathname = usePathname();

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/products");
        const data = await res.json();
        setProductsData(data?.data?.products || []);
      } catch (err) {
        console.error("Failed to fetch products:", err);
      }
    };
    fetchProducts();
  }, []);

  // Resend timer
  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  // Load cart from localStorage
  useEffect(() => {
    const loadCart = () => {
      const storedCart = localStorage.getItem("cartItems");

      if (storedCart && productsData.length > 0) {
        const parsed = JSON.parse(storedCart);

        const merged = parsed
          .map((item) => {
            const product = productsData.find((p) => p.id === item.id);
            if (!product) return null;
            return { ...product, quantity: item.quantity };
          })
          .filter(Boolean);

        setCartItems(merged);
      }
    };

    loadCart();
    window.addEventListener("cartUpdated", loadCart);
    return () => window.removeEventListener("cartUpdated", loadCart);
  }, [productsData]);

  // Handle quantity change
  const handleQuantityChange = (id, delta) => {
    const updated = cartItems
      .map((i) =>
        i.id === id ? { ...i, quantity: i.quantity + delta } : i
      )
      .filter((i) => i.quantity > 0);

    setCartItems(updated);

    const save = updated.map((i) => ({
      id: i.id,
      quantity: i.quantity,
    }));

    localStorage.setItem("cartItems", JSON.stringify(save));
    window.dispatchEvent(new Event("cartUpdated"));
  };

  // Totals
  const totalAmount = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const totalItems = cartItems.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  // Step 1: Send OTP to email
  const handleSendOTP = async () => {
    if (!customerInfo.email || !/\S+@\S+\.\S+/.test(customerInfo.email)) {
      alert("Please enter a valid email address");
      return;
    }

    setOtpLoading(true);
    try {
      const response = await axios.post("https://api.kineed.in/api/otp/send", {
        email: customerInfo.email,
      });

      if (response.data.success) {
        setOtpId(response.data.data.otpId);
        setOtpSent(true);
        setResendTimer(60);
        alert("OTP sent to your email!");
        setCheckoutStep(2);
      } else {
        alert(response.data.message || "Failed to send OTP");
      }
    } catch (error) {
      console.error("Error sending OTP:", error);
      alert(error.response?.data?.message || "Failed to send OTP. Please try again.");
    } finally {
      setOtpLoading(false);
    }
  };

  // Handle OTP input
  const handleOtpChange = (index, value) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        if (nextInput) nextInput.focus();
      }
    }
  };

  // Verify OTP
  const handleVerifyOTP = async () => {
    const otpValue = otp.join("");
    if (otpValue.length !== 6) {
      alert("Please enter 6-digit OTP");
      return;
    }

    setOtpLoading(true);
    try {
      const response = await axios.post("https://api.kineed.in/api/otp/verify", {
        otpId,
        otp: otpValue,
        email: customerInfo.email,
      });

      if (response.data.success) {
        setOtpVerified(true);
        alert("Email verified successfully!");
        setCheckoutStep(3);
      } else {
        alert(response.data.message || "Invalid OTP");
      }
    } catch (error) {
      console.error("Error verifying OTP:", error);
      alert(error.response?.data?.message || "Invalid OTP. Please try again.");
    } finally {
      setOtpLoading(false);
    }
  };

  // Resend OTP
  const handleResendOTP = async () => {
    if (resendTimer > 0) return;

    setOtpLoading(true);
    try {
      const response = await axios.post("https://api.kineed.in/api/otp/resend", {
        email: customerInfo.email,
      });

      if (response.data.success) {
        setOtpId(response.data.data.otpId);
        setResendTimer(60);
        alert("OTP resent to your email!");
      } else {
        alert(response.data.message || "Failed to resend OTP");
      }
    } catch (error) {
      console.error("Error resending OTP:", error);
      alert(error.response?.data?.message || "Failed to resend OTP. Please try again.");
    } finally {
      setOtpLoading(false);
    }
  };

  // Create order and initiate payment
  const handlePhonePePayment = async () => {
    setLoading(true);
    try {
      // First create order
      const orderResponse = await axios.post("https://api.kineed.in/api/checkout/create-order", {
        items: cartItems.map(item => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          image: item.mainImage || "/placeholder.jpg",
        })),
        customerInfo,
        totalAmount,
      });

      const orderId = orderResponse.data.data.orderId;
      setOrderId(orderId);

      // Create PhonePe payment
      const paymentResponse = await axios.post("https://api.kineed.in/api/checkout/initiate-payment", {
        orderId,
        amount: totalAmount,
        customerInfo: {
          name: customerInfo.name,
          email: customerInfo.email,
          phone: customerInfo.phone,
        },
      });

      if (paymentResponse.data.data.redirectUrl) {
        // Clear cart
        localStorage.removeItem("cartItems");
        window.dispatchEvent(new Event("cartUpdated"));
        
        // Close cart sidebar
        setCartOpen(false);
        
        // Redirect to PhonePe payment page
        window.location.href = paymentResponse.data.data.redirectUrl;
      } else {
        throw new Error('No redirect URL received');
      }
    } catch (error) {
      console.error("Payment error:", error);
      alert(error.response?.data?.message || "Payment failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Handle customer info change
  const handleCustomerInfoChange = (e) => {
    setCustomerInfo({
      ...customerInfo,
      [e.target.name]: e.target.value,
    });
  };

  // Proceed to checkout
  const handleProceedToCheckout = () => {
    if (cartItems.length === 0) {
      alert("Your cart is empty!");
      return;
    }
    setCheckoutStep(1);
  };

  // Build WhatsApp message
  const buildWhatsAppLink = () => {
    const phone = "919999999999"; // Replace with actual WhatsApp number
    const messageLines = [
      "Hello, I am interested in buying the following items from *KINEED Kitchen Appliances*:",
      "",
      ...cartItems.map(
        (item, idx) =>
          `${idx + 1}. *${item.name}*\nQuantity: ${item.quantity}\nPrice: ₹${item.price}\nSubtotal: ₹${item.price * item.quantity}\n`
      ),
      `*Total Amount: ₹${totalAmount}*`,
      "",
      "Please guide me with the next steps to proceed with the purchase.",
    ];

    const finalMessage = encodeURIComponent(messageLines.join("\n"));
    return `https://wa.me/${phone}?text=${finalMessage}`;
  };

  const whatsappLink = buildWhatsAppLink();

  // Steps titles
  const stepTitles = [
    "My Cart",
    "Email Verification",
    "Verify OTP",
    "Shipping Details",
    "Secure Payment"
  ];

  return (
    <>
      <AnimatePresence>
        {cartOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black z-[1040]"
              onClick={() => {
                setCartOpen(false);
                setCheckoutStep(0);
                setOtpSent(false);
                setOtpVerified(false);
              }}
            />

            {/* Sidebar */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.3 }}
              className="fixed top-0 right-0 z-[1050] h-full w-full md:w-96 bg-white shadow-2xl flex flex-col rounded-l-2xl overflow-hidden"
            >
              {/* Header with Steps */}
              <div className="px-6 py-5 border-b border-gray-200">
                <div className="flex justify-between items-center mb-2">
                  <h2 className="text-xl font-semibold">
                    {stepTitles[checkoutStep]}
                  </h2>
                  <button
                    onClick={() => {
                      setCartOpen(false);
                      setCheckoutStep(0);
                      setOtpSent(false);
                      setOtpVerified(false);
                    }}
                    className="p-2 rounded-full hover:bg-blue-100 transition-colors"
                  >
                    <X size={24} />
                  </button>
                </div>
                
                {/* Progress Steps */}
                {checkoutStep > 0 && (
                  <div className="flex items-center justify-between mt-4">
                    {[1, 2, 3, 4].map((step) => (
                      <div key={step} className="flex flex-col items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          checkoutStep >= step 
                            ? "bg-blue-600 text-white" 
                            : "bg-gray-200 text-gray-500"
                        }`}>
                          {step}
                        </div>
                        <span className="text-xs mt-1 text-gray-600">
                          {step === 1 ? "Email" : step === 2 ? "OTP" : step === 3 ? "Info" : "Pay"}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Content Area */}
              <div className="flex-1 overflow-y-auto px-6 py-4">
                {checkoutStep === 0 ? (
                  // Cart Items
                  <div className="space-y-4">
                    {cartItems.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-gray-500">
                        <div className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                          <ShoppingCart size={64} className="text-gray-400" />
                        </div>
                        <p className="mt-4 font-medium">Your cart is empty</p>
                        <p className="text-sm text-gray-400">Add some products to get started</p>
                      </div>
                    ) : (
                      cartItems.map((item) => (
                        <div
                          key={item.id}
                          className="flex justify-between items-center bg-gray-50 p-3 rounded-xl shadow-sm hover:shadow-md transition-shadow"
                        >
                          <div className="flex items-center gap-3 flex-1">
                            <div className="relative w-16 h-16 bg-white rounded-lg overflow-hidden">
                              <Image
                                src={item.mainImage || "/placeholder.jpg"}
                                alt={item.name}
                                fill
                                className="object-contain p-1"
                              />
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-sm text-gray-800 line-clamp-2">
                                {item.name}
                              </p>
                              <p className="text-lg font-semibold text-blue-600 mt-1">
                                ₹{item.price}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleQuantityChange(item.id, -1)}
                              className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-200 hover:bg-gray-300"
                            >
                              <span className="text-lg">−</span>
                            </button>
                            <span className="w-8 text-center font-medium">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => handleQuantityChange(item.id, 1)}
                              className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-200 hover:bg-gray-300"
                            >
                              <span className="text-lg">+</span>
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                ) : checkoutStep === 1 ? (
                  // Email Verification Step
                  <div className="py-8">
                    <div className="text-center mb-8">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Mail className="text-blue-600" size={32} />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Email Verification</h3>
                      <p className="text-gray-600">We'll send a 6-digit OTP to verify your email</p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={customerInfo.email}
                          onChange={handleCustomerInfoChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="Enter your email address"
                        />
                      </div>

                      <button
                        onClick={handleSendOTP}
                        disabled={!customerInfo.email || otpLoading}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-colors"
                      >
                        {otpLoading ? (
                          <>
                            <Loader2 className="animate-spin" size={20} />
                            Sending OTP...
                          </>
                        ) : (
                          <>
                            <Mail size={20} />
                            Send OTP
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => setCheckoutStep(0)}
                        className="w-full text-center text-gray-600 hover:text-gray-800 font-medium py-2"
                      >
                        ← Back to Cart
                      </button>
                    </div>
                  </div>
                ) : checkoutStep === 2 ? (
                  // OTP Verification Step
                  <div className="py-8">
                    <div className="text-center mb-8">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Shield className="text-green-600" size={32} />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Verify OTP</h3>
                      <p className="text-gray-600 mb-1">
                        Enter the 6-digit OTP sent to
                      </p>
                      <p className="text-blue-600 font-medium">{customerInfo.email}</p>
                    </div>

                    <div className="space-y-6">
                      {/* OTP Inputs */}
                      <div className="flex justify-center gap-2">
                        {otp.map((digit, index) => (
                          <input
                            key={index}
                            id={`otp-${index}`}
                            type="text"
                            maxLength="1"
                            value={digit}
                            onChange={(e) => handleOtpChange(index, e.target.value)}
                            className="w-12 h-12 text-center text-xl font-semibold border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            onKeyDown={(e) => {
                              if (e.key === 'Backspace' && !digit && index > 0) {
                                const prevInput = document.getElementById(`otp-${index - 1}`);
                                if (prevInput) prevInput.focus();
                              }
                            }}
                          />
                        ))}
                      </div>

                      <div className="text-center">
                        {resendTimer > 0 ? (
                          <p className="text-gray-500">
                            Resend OTP in {resendTimer}s
                          </p>
                        ) : (
                          <button
                            onClick={handleResendOTP}
                            disabled={otpLoading}
                            className="text-blue-600 hover:text-blue-800 font-medium disabled:opacity-50"
                          >
                            Resend OTP
                          </button>
                        )}
                      </div>

                      <button
                        onClick={handleVerifyOTP}
                        disabled={otp.join("").length !== 6 || otpLoading}
                        className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-colors"
                      >
                        {otpLoading ? (
                          <>
                            <Loader2 className="animate-spin" size={20} />
                            Verifying...
                          </>
                        ) : (
                          <>
                            <Shield size={20} />
                            Verify & Continue
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => setCheckoutStep(1)}
                        className="w-full text-center text-gray-600 hover:text-gray-800 font-medium py-2"
                      >
                        ← Change Email
                      </button>
                    </div>
                  </div>
                ) : checkoutStep === 3 ? (
                  // User Information Step
                  <div className="py-4">
                    <div className="text-center mb-6">
                      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <User className="text-purple-600" size={32} />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Shipping Details</h3>
                      <p className="text-gray-600">Enter your shipping information</p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Full Name *
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            name="name"
                            value={customerInfo.name}
                            onChange={handleCustomerInfoChange}
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your full name"
                          />
                          <User className="absolute left-3 top-3.5 text-gray-400" size={18} />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Phone Number *
                        </label>
                        <div className="relative">
                          <input
                            type="tel"
                            name="phone"
                            value={customerInfo.phone}
                            onChange={handleCustomerInfoChange}
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Enter your phone number"
                          />
                          <Phone className="absolute left-3 top-3.5 text-gray-400" size={18} />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Complete Address *
                        </label>
                        <div className="relative">
                          <textarea
                            name="address"
                            value={customerInfo.address}
                            onChange={handleCustomerInfoChange}
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="House no., Building, Street, Area"
                            rows="3"
                          />
                          <Home className="absolute left-3 top-3.5 text-gray-400" size={18} />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            City *
                          </label>
                          <input
                            type="text"
                            name="city"
                            value={customerInfo.city}
                            onChange={handleCustomerInfoChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="City"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Pincode *
                          </label>
                          <input
                            type="text"
                            name="pincode"
                            value={customerInfo.pincode}
                            onChange={handleCustomerInfoChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Pincode"
                            maxLength="6"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          State *
                        </label>
                        <input
                          type="text"
                          name="state"
                          value={customerInfo.state}
                          onChange={handleCustomerInfoChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="State"
                        />
                      </div>

                      {/* Order Summary Preview */}
                      <div className="mt-6 pt-4 border-t border-gray-200">
                        <h4 className="font-medium text-lg mb-3">Order Summary</h4>
                        <div className="space-y-2 mb-3 max-h-32 overflow-y-auto pr-2">
                          {cartItems.map((item) => (
                            <div key={item.id} className="flex justify-between text-sm">
                              <span className="truncate max-w-[140px]">
                                {item.name} × {item.quantity}
                              </span>
                              <span className="font-medium">₹{item.price * item.quantity}</span>
                            </div>
                          ))}
                        </div>
                        <div className="flex justify-between font-bold text-lg pt-2 border-t border-gray-200">
                          <span>Total</span>
                          <span className="text-blue-600">₹{totalAmount}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => setCheckoutStep(4)}
                        disabled={
                          !customerInfo.name ||
                          !customerInfo.phone ||
                          !customerInfo.address ||
                          !customerInfo.city ||
                          !customerInfo.state ||
                          !customerInfo.pincode
                        }
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        Continue to Payment
                      </button>

                      <button
                        onClick={() => setCheckoutStep(2)}
                        className="w-full text-center text-gray-600 hover:text-gray-800 font-medium py-2"
                      >
                        ← Back
                      </button>
                    </div>
                  </div>
                ) : checkoutStep === 4 ? (
                  // Payment Step
                  <div className="py-8">
                    <div className="text-center mb-8">
                      <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CreditCard className="text-yellow-600" size={32} />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Secure Payment</h3>
                      <p className="text-gray-600">Complete your purchase securely</p>
                    </div>

                    <div className="space-y-6">
                      {/* Order Summary */}
                      <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                        <div className="flex justify-between font-bold text-lg mb-2">
                          <span>Total Amount</span>
                          <span className="text-blue-600">₹{totalAmount}</span>
                        </div>
                        <p className="text-sm text-gray-600">Including all taxes</p>
                      </div>

                      {/* Shipping Info Preview */}
                      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <MapPin size={16} />
                          Shipping to:
                        </h4>
                        <div className="text-sm space-y-1">
                          <p className="font-medium">{customerInfo.name}</p>
                          <p>{customerInfo.address}</p>
                          <p>
                            {customerInfo.city}, {customerInfo.state} - {customerInfo.pincode}
                          </p>
                          <p>📱 {customerInfo.phone}</p>
                          <p>📧 {customerInfo.email}</p>
                        </div>
                      </div>

                      <button
                        onClick={handlePhonePePayment}
                        disabled={loading}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all"
                      >
                        {loading ? (
                          <>
                            <Loader2 className="animate-spin" size={20} />
                            Processing...
                          </>
                        ) : (
                          <>
                            <CreditCard size={20} />
                            Pay ₹{totalAmount}
                          </>
                        )}
                      </button>

                      <div className="text-center">
                        <p className="text-sm text-gray-500">
                          Secure payment powered by PhonePe
                        </p>
                        <div className="flex justify-center mt-2">
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                            <Shield size={12} />
                            <span>PCI-DSS Compliant</span>
                            <span>•</span>
                            <span>256-bit SSL Encryption</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => setCheckoutStep(3)}
                        className="w-full text-center text-gray-600 hover:text-gray-800 font-medium py-2"
                      >
                        ← Back to Shipping
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>

              {/* Footer */}
              {cartItems.length > 0 && checkoutStep === 0 && (
                <div className="px-6 py-5 border-t border-gray-200 bg-white flex flex-col gap-3">
                  {/* Order Summary */}
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">Total ({totalItems} items)</span>
                    <span className="text-xl font-bold text-blue-600">₹{totalAmount}</span>
                  </div>

                  {/* WhatsApp Checkout */}
                  {/* <a
                    href={whatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-between bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-3 rounded-lg shadow-md transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <ShoppingCart size={24} />
                      <div className="flex flex-col">
                        <span>₹{totalAmount}</span>
                        <span className="text-xs">{totalItems} items</span>
                      </div>
                    </div>
                    <span>Order via WhatsApp</span>
                  </a> */}

                  {/* Secure Checkout */}
                  <button
                    onClick={handleProceedToCheckout}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold px-4 py-3 rounded-lg shadow-md transition-colors"
                  >
                    <CreditCard size={20} />
                    Proceed to Checkout
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Mobile Bottom Bar */}
      <AnimatePresence>
        {!cartOpen &&
          cartItems.length > 0 &&
          pathname !== "/checkout" && (
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed bottom-4 left-4 right-4 z-[1050] bg-gradient-to-r from-gray-900 to-gray-800 text-white rounded-xl shadow-xl flex justify-between items-center px-4 py-3 md:hidden"
            >
              <div className="flex items-center gap-3">
                <div className="bg-gray-800 rounded-full p-2">
                  <ShoppingCart size={20} />
                </div>
                <div>
                  <p className="text-sm text-gray-300">{totalItems} items</p>
                  <p className="font-bold text-lg">₹{totalAmount}</p>
                </div>
              </div>

              <button
                onClick={() => setCartOpen(true)}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-all"
              >
                View Cart
              </button>
            </motion.div>
          )}
      </AnimatePresence>
    </>
  );
};

export default CartSidebar;