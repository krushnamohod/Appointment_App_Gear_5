"use client";

import { useState, useEffect, useRef } from "react";
import { ShoppingCart, Search } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import CartSidebar from "./CartSidebar";
import { slugify } from "@/utils/slugify";

/* ---------------------------------------------
    MEDIA SERVER CONFIG FOR DYNAMIC LOGO
---------------------------------------------- */
const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

const placeholderExamples = [
  // "Search Juices",
  // "Search Soaps...",
  // "Search Gels...",
  // "Search Creams...",
  // "Search categories...",
  "Search products...",
];

const Header = () => {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [placeholder, setPlaceholder] = useState(placeholderExamples[0]);
  const indexRef = useRef(0);
  const searchRef = useRef(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);

  const [dynamicLogo, setDynamicLogo] = useState(null);

  /* ---------------------------------------------
     ROTATING PLACEHOLDER
  ---------------------------------------------- */
  useEffect(() => {
    const interval = setInterval(() => {
      indexRef.current = (indexRef.current + 1) % placeholderExamples.length;
      setPlaceholder(placeholderExamples[indexRef.current]);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  /* ---------------------------------------------
      FETCH DYNAMIC LOGO FROM HOME API
  ---------------------------------------------- */
  useEffect(() => {
    const fetchLogo = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/home");
        const data = await res.json();

        const home = data?.data?.[0];

        if (home?.logo) {
          setDynamicLogo(`${MEDIA_DOWNLOAD}/${home.logo}`);
        } else {
          setDynamicLogo(null);
        }
      } catch (err) {
        console.error("Failed to load dynamic logo:", err);
        setDynamicLogo(null);
      }
    };

    fetchLogo();
  }, []);

  /* ---------------------------------------------
     FETCH PRODUCTS & CATEGORIES
  ---------------------------------------------- */
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/products");
        const data = await res.json();
        if (data.status === "success") {
          setProducts(data.data.products);
          const uniqueCategories = [
            ...new Set(data.data.products.map((p) => p.category)),
          ];
          setCategories(uniqueCategories);
        }
      } catch (err) {
        console.error("Failed to fetch products:", err);
      }
    };

    fetchProducts();
  }, []);

  /* ---------------------------------------------
     LOAD CART FROM LOCALSTORAGE
  ---------------------------------------------- */
  /* ---------------------------------------------
   LOAD + MERGE CART WITH PRODUCTS (IMPORTANT FIX)
---------------------------------------------- */
  useEffect(() => {
    const loadCart = () => {
      const stored = localStorage.getItem("cartItems");
      const parsed = stored ? JSON.parse(stored) : [];

      // No products yet → wait
      if (parsed.length === 0 || products.length === 0) {
        setCartItems([]);
        return;
      }

      // Merge product details with cart quantities
      const mergedCart = parsed
        .map((item) => {
          const product = products.find((p) => p.id === item.id);

          if (!product) return null;

          return {
            ...product, // includes name, price, image
            quantity: item.quantity,
          };
        })
        .filter(Boolean);

      setCartItems(mergedCart);
    };

    loadCart();
    window.addEventListener("cartUpdated", loadCart);
    return () => window.removeEventListener("cartUpdated", loadCart);
  }, [products]);

  /* ---------------------------------------------
      CLOSE DROPDOWN ON OUTSIDE CLICK
  ---------------------------------------------- */
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    window.addEventListener("click", handleClickOutside);
    return () => window.removeEventListener("click", handleClickOutside);
  }, []);

  /* ---------------------------------------------
     FILTER SEARCH RESULTS
  ---------------------------------------------- */
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setDropdownOpen(false);
      return;
    }

    const matchedProducts = products.filter((p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const matchedCategories = categories.filter((c) =>
      c.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const results = [
      ...matchedCategories.map((c) => ({ type: "category", name: c })),
      ...matchedProducts.map((p) => ({
        type: "product",
        name: p.name,
        id: p.id,
      })),
    ];

    setSearchResults(results);
    setDropdownOpen(results.length > 0);
  }, [searchQuery, products, categories]);

  /* ---------------------------------------------
     CART TOTALS
  ---------------------------------------------- */
  const totalItems = cartItems.reduce(
    (acc, item) => acc + (item.quantity || 0),
    0
  );

  const totalPrice = cartItems
    .reduce((acc, item) => acc + (item.price || 0) * (item.quantity || 0), 0)
    .toFixed(2);

  /* ---------------------------------------------
     RENDER
  ---------------------------------------------- */
  return (
    <div className="z-[1000] w-full bg-white fixed top-0 shadow-md transition-all duration-300">
      <div className="container flex items-center justify-between mx-auto px-4 md:px-8 py-3 gap-3 md:gap-0">
        {/* ----------------------------------------------------
             DYNAMIC LOGO
        ------------------------------------------------------ */}
        <Link href={"/"}>
          {dynamicLogo ? (
            <Image
              src={dynamicLogo}
              alt="Kineed"
              width={120}
              height={60}
              className="h-10 w-auto md:h-14 object-contain transition-transform duration-300 hover:scale-105"
            />
          ) : (
            <span className="text-lg md:text-xl font-semibold tracking-wide">
              KINEED Kitchen Appliances
            </span>
          )}
        </Link>

        {/* ----------------------------------------------------
             SEARCH BAR
        ------------------------------------------------------ */}
        <div className="relative w-1/2" ref={searchRef}>
          <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />

          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={placeholder}
            className="w-full border border-gray-500 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

          <AnimatePresence>
            {dropdownOpen && searchResults.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-full left-0 w-full bg-white border border-gray-300 rounded-lg mt-1 shadow-lg z-50 max-h-72 overflow-y-auto"
              >
                {searchResults.map((res, i) => (
                  <Link
                    key={i}
                    href={
                      res.type === "product"
                        ? `/pd/${slugify(res.name)}`
                        : `/cp/${res.name}`
                    }
                    className="block px-4 py-2 hover:bg-blue-100 transition-colors text-gray-700"
                    onClick={() => setDropdownOpen(false)}
                  >
                    {res.type === "category"
                      ? `Category: ${res.name}`
                      : res.name}
                  </Link>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ----------------------------------------------------
             CART BUTTON
        ------------------------------------------------------ */}
        <button
          onClick={() => setCartOpen(true)}
          className={`relative hidden md:flex items-center gap-2 px-4 py-2 rounded-md transition-all duration-300 hover:shadow-md active:scale-95 ${
            cartItems.length > 0
              ? "text-blue-900 bg-blue-200 hover:bg-blue-300"
              : "text-gray-500 bg-gray-200 cursor-not-allowed"
          }`}
        >
          <ShoppingCart size={25} />
          {cartItems.length === 0 ? (
            <span className="font-medium">My Cart</span>
          ) : (
            <div className="flex flex-col">
              <span className="font-medium">{totalItems} items</span>
              <span className="font-medium">₹{totalPrice}</span>
            </div>
          )}
        </button>
      </div>

      {/* ----------------------------------------------------
           CART SIDEBAR
      ------------------------------------------------------ */}
      <CartSidebar cartOpen={cartOpen} setCartOpen={setCartOpen} />
    </div>
  );
};

export default Header;
