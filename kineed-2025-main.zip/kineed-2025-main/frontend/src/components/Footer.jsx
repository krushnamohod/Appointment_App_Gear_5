"use client";

import { useEffect, useState } from "react";
import { slugify } from "@/utils/slugify";
import Link from "next/link";

export default function Footer() {
  const [policies, setPolicies] = useState([]);

  useEffect(() => {
    fetchPolicies();
  }, []);

  const fetchPolicies = async () => {
    try {
      const res = await fetch("https://api.kineed.in/api/policy");

      // Backend returns raw array
      const data = await res.json();

      if (Array.isArray(data)) {
        setPolicies(data);
      }
    } catch (error) {
      console.error("Failed to load policies", error);
    }
  };

  return (
    <footer className="bg-white border-t border-gray-200 transition-colors duration-300">
      <div className="mx-auto px-6 py-4">
        {/* Bottom Section */}
        <div className="mt-2 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-700 text-sm">
            &copy; {new Date().getFullYear()} KINEED KITCHEN APPLIANCES PVT LTD. All rights reserved.
          </p>

          <div className="mt-4 md:mt-0 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm">
            {/* Dynamic Policies */}
            {policies.map((p) => (
              <Link
                key={p.id}
                href={`/policy/${slugify(p.name)}`}
                className="text-gray-700 transition-colors duration-300 hover:text-black"
              >
                {p.name}
              </Link>
            ))}

            {/* Hardcoded Links */}
            <Link href="/blog" className="text-gray-700 hover:text-black">
              Blog
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-black">
              About
            </Link>
            <Link href="/support" className="text-gray-700 hover:text-black">
              Customer Support
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-black">
              Contact
            </Link>
          </div>
        </div>

        {/* Branding */}
        <div className="flex mt-3 gap-3 flex-col text-sm text-gray-700 justify-center items-center">
          <p>Developed by</p>
          <a
            href="https://bizonance.in/"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              className="h-6"
              src="/bizonance_three.png"
              alt="Bizonance Logo"
            />
          </a>
        </div>
      </div>
    </footer>
  );
}
