"use client";
import React from "react";
import { Minus, Plus } from "lucide-react";

const QuantitySelector = ({ quantity, onIncrease, onDecrease, onAdd }) => {
  return quantity === 0 ? (
    <p
      className="w-15 h-8 flex items-center justify-center border border-blue-600 text-sm rounded-md font-semibold text-blue-700 cursor-pointer transition-colors bg-blue-100 hover:text-blue-800"
      onClick={onAdd}
    >
      ADD
    </p>
  ) : (
    <div
      className="w-15 h-8 flex items-center justify-between border border-blue-600 rounded-md text-blue-700 select-none overflow-hidden"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        onClick={onDecrease}
        className="flex items-center justify-center w-1/3 h-full   bg-blue-100  transition-colors"
      >
        <Minus size={14} />
      </button>
      <span className="flex text-center font-semibold w-1/3 text-sm bg-blue-100 h-full items-center justify-center">{quantity}</span>
      <button
        onClick={onIncrease}
        className="flex items-center justify-center w-1/3 h-full bg-blue-100 transition-colors"
      >
        <Plus size={14} />
      </button>
    </div>
  );
};

export default QuantitySelector;
