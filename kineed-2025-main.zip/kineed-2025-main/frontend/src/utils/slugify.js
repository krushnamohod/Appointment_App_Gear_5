export const slugify = (text) => {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[\s_]+/g, "-")      // replace spaces and underscores with hyphen
    .replace(/[^\w\-]+/g, "")     // remove special characters
    .replace(/\-\-+/g, "-");      // replace multiple hyphens with single
};
