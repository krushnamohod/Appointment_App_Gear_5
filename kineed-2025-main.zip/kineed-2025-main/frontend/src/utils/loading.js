function LoadingState() {
  return (
    <div className="w-full min-h-screen flex items-center justify-center">
      <div className="animate-spin h-10 w-10 border-4 border-blue-400 border-t-transparent rounded-full"></div>
    </div>
  );
}
export default LoadingState;