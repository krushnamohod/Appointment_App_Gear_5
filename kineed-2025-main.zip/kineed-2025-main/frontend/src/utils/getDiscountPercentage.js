// src/utils/getDiscountPercentage.js

export const getDiscountPercentage = (originalPrice, currentPrice) => {
  if (!originalPrice || originalPrice <= 0) return 0; // prevent divide by zero
  const discount = ((originalPrice - currentPrice) / originalPrice) * 100;
  return Math.round(discount);
};
