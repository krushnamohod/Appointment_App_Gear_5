// Product Not Found Component
export default function ProductNotFound({ onBackToProducts }) {
  return (
    <div className="w-full min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2 text-gray-800">
          Product Not Found
        </h2>
        <p className="text-gray-500 mb-4">
           {  "The product you're looking for doesn't exist." }
        </p>
        <button
          onClick={onBackToProducts}
          className="bg-blue-200 hover:bg-blue-300 text-blue-900 font-semibold px-4 py-2 rounded-lg"
        >
          Back to Products
        </button>
      </div>
    </div>
  );
}