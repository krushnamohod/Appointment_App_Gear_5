"use client";
import React from "react";
import { Star, StarHalf } from "lucide-react"; // make sure you have lucide-react installed

const StarRating = ({
  rating = 0,          // current rating
  maxStars = 5,        // total number of stars
  size = 16,           // width & height in px
  color = "text-yellow-500", // filled stars color
  emptyColor = "text-gray-300", // empty stars color
  showNumber = true,   // show numeric rating
}) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 !== 0;

  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <Star
          key={i}
          className={`${color} fill-yellow-500`}
          style={{ width: size, height: size }}
        />
      ))}
      {hasHalfStar && (
        <StarHalf
          className={`${color} fill-yellow-500`}
          style={{ width: size, height: size }}
        />
      )}
      {[...Array(maxStars - fullStars - (hasHalfStar ? 1 : 0))].map((_, i) => (
        <Star
          key={i + fullStars + (hasHalfStar ? 1 : 0)}
          className={`${emptyColor}`}
          style={{ width: size, height: size }}
        />
      ))}
      {showNumber && (
        <span className="ml-2 text-sm text-gray-600">({rating})</span>
      )}
    </div>
  );
};

export default StarRating;
