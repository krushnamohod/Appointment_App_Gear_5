import Link from "next/link"
import Address from "@/components/address"

export default function CookiePolicy() {
  return (
    <>
    <div className="container mx-auto px-4 py-12 max-w-4xl mt-20">
      <h1 className="text-3xl font-bold text-blue-800 mb-8">Cookie Policy</h1>

      <div className="prose prose-blue max-w-none">
        {/* <p className="text-gray-600 mb-6">Last Updated: May 2, 2025</p> */}

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Introduction</h2>
          <p>
            Grutikaagro.com ("we" or "us" or "our") may use cookies, web beacons, tracking pixels, and other tracking
            technologies when you visit our website, including any other media form, media channel, mobile website, or
            mobile application related or connected to Grutikaagro.com (collectively, the "Site") to help customize the
            Site and improve your experience.
          </p>
          <p className="mt-4">
            We reserve the right to make changes to this Cookie Policy at any time and for any reason. Any changes or
            modifications will be effective immediately upon posting the updated Cookie Policy on the Site, and you
            waive the right to receive specific notice of each such change or modification.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">What Are Cookies</h2>
          <p>
            Cookies are small text files that are stored on your computer or mobile device when you visit a website.
            They are widely used in order to make websites work, or work more efficiently, as well as to provide
            information to the owners of the site. Cookies allow us to recognize your device and store information about
            your preferences or past actions.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Types of Cookies We Use</h2>

          <h3 className="text-xl font-medium text-blue-600 mb-3">Essential Cookies</h3>
          <p>
            Essential cookies are necessary for the proper functioning of the website. These cookies enable basic
            functions like page navigation, secure areas of the website, and access to secure areas. The website cannot
            function properly without these cookies.
          </p>

          <h3 className="text-xl font-medium text-blue-600 mb-3 mt-4">Functionality Cookies</h3>
          <p>
            Functionality cookies allow us to remember choices you make and provide enhanced, more personal features.
            They may be set by us or by third-party providers whose services we have added to our pages.
          </p>

          <h3 className="text-xl font-medium text-blue-600 mb-3 mt-4">Analytics Cookies</h3>
          <p>
            Analytics cookies help us understand how visitors interact with our website. These cookies help us analyze
            data about web page traffic and improve our website in order to tailor it to customer needs. We only use
            this information for statistical analysis purposes.
          </p>

          <h3 className="text-xl font-medium text-blue-600 mb-3 mt-4">Advertising Cookies</h3>
          <p>
            Advertising cookies are used to make advertising messages more relevant to you. They perform functions like
            preventing the same ad from continuously reappearing, ensuring that ads are properly displayed, and in some
            cases selecting advertisements that are based on your interests.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Your Cookie Choices</h2>
          <p>
            Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your
            browser to remove or reject browser cookies. Please note that if you choose to remove or reject cookies,
            this could affect the availability and functionality of our Site.
          </p>
          <p className="mt-4">You can manage your cookie preferences through your browser settings:</p>
          <ul className="list-disc pl-6 mt-2 mb-4">
            <li>
              <strong>Chrome:</strong>{" "}
              <a
                href="https://support.google.com/chrome/answer/95647"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800"
              >
                https://support.google.com/chrome/answer/95647
              </a>
            </li>
            <li>
              <strong>Firefox:</strong>{" "}
              <a
                href="https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800"
              >
                https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop
              </a>
            </li>
            <li>
              <strong>Safari:</strong>{" "}
              <a
                href="https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800"
              >
                https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac
              </a>
            </li>
            <li>
              <strong>Edge:</strong>{" "}
              <a
                href="https://support.microsoft.com/en-us/microsoft-edge/delete-cookies-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800"
              >
                https://support.microsoft.com/en-us/microsoft-edge/delete-cookies-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09
              </a>
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Third-Party Cookies</h2>
          <p>
            In some special cases, we also use cookies provided by trusted third parties. The following section details
            which third-party cookies you might encounter through this site.
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4">
            <li>
              This site uses Google Analytics which is one of the most widespread and trusted analytics solutions on the
              web for helping us to understand how you use the site and ways that we can improve your experience. These
              cookies may track things such as how long you spend on the site and the pages that you visit so we can
              continue to produce engaging content.
            </li>
            <li>
              We also use social media buttons and/or plugins on this site that allow you to connect with your social
              network in various ways. For these to work, social media sites including Facebook, Instagram, and Twitter,
              will set cookies through our site which may be used to enhance your profile on their site or contribute to
              the data they hold for various purposes outlined in their respective privacy policies.
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">How Long Will Cookies Stay on My Device?</h2>
          <p>
            The length of time a cookie will remain on your device depends on whether it is a "persistent" or "session"
            cookie. Session cookies will remain on your device until you stop browsing. Persistent cookies remain on
            your device until they expire or are deleted.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Contact Us</h2>
          <p>If you have questions or comments about this Cookie Policy, please contact us at:</p>
          <Address />
        </section>
      </div>

      <div className="mt-12 pt-6 border-t border-gray-200">
        <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
          ← Back to Home
        </Link>
      </div>
    </div>
    </>
  )
}
