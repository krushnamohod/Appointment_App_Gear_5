"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import * as LucideIcons from "lucide-react";

/* -----------------------------------------
   CONFIG: MEDIA SERVER URL
----------------------------------------- */
const MEDIA_DOWNLOAD =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance";

/* -----------------------------------------
   Dynamic Icon Renderer
----------------------------------------- */
function DynamicIcon({ name, className = "h-6 w-6 text-blue-700" }) {
  const IconComponent = LucideIcons[name];
  if (!IconComponent) return <LucideIcons.HelpCircle className={className} />;
  return <IconComponent className={className} />;
}

export default function AboutPage() {
  const [about, setAbout] = useState(null);
  const [brands, setBrands] = useState([]);
  const [currentImage, setCurrentImage] = useState(0);

  /* -----------------------------------------
       Fetch About Data
  ----------------------------------------- */
  useEffect(() => {
    const fetchAbout = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/about");
        const json = await res.json();

        const record = json?.data?.about || json?.data || json;
        setAbout(Array.isArray(record) ? record[0] : record);
      } catch (err) {
        console.error("Failed to load About:", err);
      }
    };

    fetchAbout();
  }, []);

  /* -----------------------------------------
       Fetch Brands Data
  ----------------------------------------- */
  useEffect(() => {
    const fetchBrands = async () => {
      try {
        const res = await fetch("https://api.kineed.in/api/products/brands/all");
        const json = await res.json();

        setBrands(json?.data?.brands || []);
      } catch (err) {
        console.error("Failed to load brands:", err);
      }
    };

    fetchBrands();
  }, []);

  /* -----------------------------------------
     Carousel Auto Slide
  ----------------------------------------- */
  useEffect(() => {
    if (!about?.heroImages?.length) return;

    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % about.heroImages.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [about]);

  if (!about) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-400">Loading About Page...</p>
      </div>
    );
  }

  const heroImages =
    about.heroImages?.map((img) => `${MEDIA_DOWNLOAD}/${img}`) || [];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <main className="flex-1">

        {/* -----------------------------------------
               HERO SECTION
        ----------------------------------------- */}
        <div className="container mx-auto max-w-7xl px-2 md:px-10 mt-30 p-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* LEFT */}
            <div className="space-y-6 text-center md:text-left">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight text-gray-900">
                {about.heroTitle}
              </h1>
              <p className="text-lg text-gray-600 md:pr-6 text-justify">
                {about.heroSubtitle}
              </p>
            </div>

            {/* RIGHT - SLIDER */}
            <div className="relative w-full h-80 md:h-[24rem] lg:h-[25rem]">
              <div className="relative h-full w-full overflow-hidden rounded-2xl shadow-lg">
                {heroImages.map((src, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-opacity duration-700 ${
                      index === currentImage ? "opacity-100" : "opacity-0"
                    }`}
                  >
                    <Image
                      src={src}
                      alt={`Hero image ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>

              {/* Arrows */}
              <button
                onClick={() =>
                  setCurrentImage(
                    (prev) => (prev - 1 + heroImages.length) % heroImages.length
                  )
                }
                className="absolute top-1/2 -translate-y-1/2 left-3 bg-white/70 backdrop-blur-md p-2 rounded-full shadow"
              >
                <LucideIcons.ChevronLeft className="h-5 w-5 text-gray-800" />
              </button>

              <button
                onClick={() =>
                  setCurrentImage((prev) => (prev + 1) % heroImages.length)
                }
                className="absolute top-1/2 -translate-y-1/2 right-3 bg-white/70 backdrop-blur-md p-2 rounded-full shadow"
              >
                <LucideIcons.ChevronRight className="h-5 w-5 text-gray-800" />
              </button>
            </div>
          </div>
        </div>

        {/* -----------------------------------------
                OUR BRANDS (NEW)
        ----------------------------------------- */}
        {brands.length > 0 && (
          <section className="py-10 px-4 md:px-6 bg-white">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-3 text-center">
                Our Brands
              </h2>
              <p className="text-center text-gray-600 mb-8 max-w-3xl mx-auto">
                We proudly partner with trusted natural product brands that share our passion for purity and quality.
              </p>

              <div className="flex flex-wrap justify-center gap-8">
                {brands.map((brand, index) => (
                  <motion.div
                    key={brand.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    className="p-4 shadow-lg rounded-xl bg-white hover:-translate-y-2 transition-all"
                  >
                    <div className="relative w-32 h-32">
                      <Image
                        src={brand.image}
                        alt={brand.name}
                        fill
                        className="object-contain rounded-lg"
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* -----------------------------------------
                SERVICES
        ----------------------------------------- */}
        {about.services?.length > 0 && (
          <section className="py-10 px-4 md:px-6">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-3 text-center">
                Our Services
              </h2>
              <p className="text-center text-gray-600 mb-8 max-w-3xl mx-auto">
                Discover the natural benefits of Ghrutika's Aloe vera products, crafted with care and tradition.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {about.services.map((service, index) => (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                  >
                    <div className="bg-white h-64 rounded-xl shadow-md hover:shadow-xl transition-all transform hover:-translate-y-2">
                      <div className="p-6 flex flex-col items-center text-center">
                        <div className="p-4 rounded-full bg-blue-200 mb-4">
                          <DynamicIcon name={service.icon} />
                        </div>
                        <h3 className="text-xl font-semibold mb-2">
                          {service.title}
                        </h3>
                        <p className="text-gray-700">{service.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* -----------------------------------------
                VALUES
        ----------------------------------------- */}
        {about.values?.length > 0 && (
          <section className="py-10 px-4 md:px-6">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-3 text-center">
                Our Values
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {about.values.map((value, index) => (
                  <motion.div
                    key={value.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                  >
                    <div className="bg-white h-64 rounded-xl shadow-md hover:shadow-xl transition-all transform hover:-translate-y-2">
                      <div className="p-6 flex flex-col items-center text-center">
                        <div className="p-4 rounded-full bg-blue-200 mb-4">
                          <DynamicIcon name={value.icon} />
                        </div>
                        <h3 className="text-xl font-semibold mb-2">
                          {value.title}
                        </h3>
                        <p className="text-gray-700">{value.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* -----------------------------------------
                FACTS
        ----------------------------------------- */}
        {about.facts?.length > 0 && (
          <section className="py-10 px-4 md:px-6">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">
                Company Facts
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                {about.facts.map((fact) => (
                  <motion.div
                    key={fact.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="bg-white p-6 rounded-xl shadow hover:shadow-lg transform hover:scale-105"
                  >
                    <DynamicIcon
                      name={fact.icon}
                      className="h-10 w-10 text-blue-700 mx-auto mb-2"
                    />
                    <h3 className="text-2xl font-bold">{fact.value}</h3>
                    <p className="text-gray-600">{fact.label}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

      </main>
    </div>
  );
}
