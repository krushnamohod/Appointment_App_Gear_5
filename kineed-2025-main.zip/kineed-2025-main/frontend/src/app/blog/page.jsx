import Image from "next/image";
import Link from "next/link";
import { slugify } from "@/utils/slugify";



async function getBlogs() {
  const res = await fetch("https://api.kineed.in/api/blogs", {
    cache: "no-store",
  });
  return res.json();
}

export default async function BlogListPage() {
  const blogs = await getBlogs();

  const IMG_PREFIX = "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance/";

  return (
    <div className="container min-h-screen mx-auto px-4 py-16 max-w-5xl mt-20">
      <h1 className="text-3xl font-bold text-blue-800 mb-10">Latest Blogs</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {blogs?.map((blog) => {
          const slug = slugify(blog.title, { lower: true, strict: true });

          return (
            <div
              key={blog.id}
              className="border border-gray-200 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 overflow-hidden"
            >
              <Image
                src={IMG_PREFIX + blog.image}
                alt={blog.title}
                width={400}
                height={220}
                className="w-full h-48 object-cover"
              />

              <div className="p-4">
                <h3 className="font-bold text-blue-800 mb-2 line-clamp-2">
                  {blog.title}
                </h3>

                <p className="text-gray-600 text-sm line-clamp-3 mb-3">
                  {blog.description}
                </p>

                <Link
                  href={`/blog/${slug}`}
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  Read More →
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
