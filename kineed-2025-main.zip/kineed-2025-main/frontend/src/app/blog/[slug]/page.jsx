import Image from "next/image";
import Link from "next/link";
import { slugify } from "@/utils/slugify";
import {
  CalendarIcon,
  User,
  Facebook,
  Linkedin,
} from "lucide-react";

// Your media URL prefix
const IMG_PREFIX =
  "https://media.bizonance.in/api/v1/image/download/eca82cda-d4d7-4fe5-915a-b0880bb8de74/bizonance/";

// Fetch ALL blogs because backend has no slug endpoint
async function getAllBlogs() {
  const res = await fetch("https://api.kineed.in/api/blogs", {
    cache: "no-store",
  });
  return res.json();
}

// Find blog by matching slug with slugified title
async function getBlogBySlug(slug) {
  const blogs = await getAllBlogs();

  return blogs.find(
    (b) =>
      slugify(b.title, { lower: true, strict: true }) === slug
  );
}

export async function generateMetadata({ params }) {
  const blog = await getBlogBySlug(params.slug);

  return {
    title: blog?.title || "Blog",
    description: blog?.description?.slice(0, 150) || "",
  };
}

export default async function BlogPage({ params }) {
  const blog = await getBlogBySlug(params.slug);

  if (!blog) {
    return (
      <div className="container mx-auto px-4 py-20 max-w-3xl">
        <h1 className="text-3xl font-bold text-red-600">
          Blog not found
        </h1>
        <Link href="/blog" className="text-blue-600 mt-4 block">
          ← Back to Blog
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl mt-20">
      <article>
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-blue-800 mb-4 leading-tight">
            {blog.title}
          </h1>

          <div className="flex flex-wrap items-center text-gray-500 gap-4 mb-6">
            <div className="flex items-center">
              <User className="h-4 w-4 mr-1" />
              <span>{blog.author || "Admin"}</span>
            </div>

            <div className="flex items-center">
              <CalendarIcon className="h-4 w-4 mr-1" />
              <span>{blog.createdAt?.slice(0, 10)}</span>
            </div>
          </div>

          {/* Main Image */}
          <div className="w-full overflow-hidden rounded-xl mb-6">
            <Image
              src={IMG_PREFIX + blog.image}
              alt={blog.title}
              width={900}
              height={500}
              className="w-full h-auto rounded-xl object-cover"
              priority
            />
          </div>
        </header>

        {/* Blog Description */}
        <div className="prose prose-blue max-w-none mb-12">
          <p>{blog.description}</p>
        </div>

        {/* Share Section */}
        <div className="mt-10 pt-6 border-t border-gray-200">
          <h3 className="font-medium text-gray-700 mb-2">
            Share this article:
          </h3>
          <div className="flex gap-3">
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-all">
              <Facebook className="h-5 w-5 text-gray-700" />
            </button>
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-all">
              <Linkedin className="h-5 w-5 text-gray-700" />
            </button>
          </div>
        </div>

        {/* Back to Blog */}
        <div className="mt-12 pt-6 border-t border-gray-200">
          <Link
            href="/blog"
            className="text-blue-600 hover:text-blue-800 font-medium"
          >
            ← Back to Blog
          </Link>
        </div>
      </article>
    </div>
  );
}
