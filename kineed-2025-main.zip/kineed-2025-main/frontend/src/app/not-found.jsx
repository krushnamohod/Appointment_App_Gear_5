"use client";

import Image from "next/image";
import Link from "next/link";
// import Button from "../"

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-10 text-center bg-gray-50">


      {/* Title */}
      <h1 className="text-4xl font-bold text-gray-800 mb-3">
        404 – Page Not Found
      </h1>

      {/* Small Description */}
      <p className="text-gray-500 max-w-md mb-8">
        The page you are looking for does not exist or may have been moved.
        Please check the URL or return to the homepage.
      </p>

      {/* Back to Home Button */}
      <Link
        href="/"
        className="mt-4 px-5 py-2 bg-blue-200 text-blue-900 rounded-lg hover:bg-blue-300 transition"
      >
        Back to Home
      </Link>
    </div>
  );
}
