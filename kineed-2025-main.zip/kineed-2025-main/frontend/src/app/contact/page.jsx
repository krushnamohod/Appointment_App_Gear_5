"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Phone, Mail, MapPin, Clock, Calendar } from "lucide-react";
import { FaFacebook, FaInstagram } from "react-icons/fa";

export default function ContactPage() {
  const [info, setInfo] = useState(null);

  const [form, setForm] = useState({
    name: "",
    email: "",
    mobile: "",
    message: "",
  });

  const [status, setStatus] = useState({ type: "", message: "" });
  const [loading, setLoading] = useState(false);

  const CONTACT_INFO_URL = "https://api.kineed.in/api/contact";
  const CONTACT_FORM_URL = "https://api.kineed.in/api/contactfrom"; // FIXED

  // ----------------------------------------------------
  // FETCH CONTACT INFO
  // ----------------------------------------------------
  useEffect(() => {
    fetchContactInfo();
  }, []);

  const fetchContactInfo = async () => {
    try {
      const res = await fetch(CONTACT_INFO_URL);
      const data = await res.json();

      // Extract the correct nested object
      const finalInfo = data?.data?.contactInfo;
      setInfo(finalInfo);
    } catch (err) {
      console.error("Failed to load contact info:", err);
    }
  };

  // ----------------------------------------------------
  // HANDLE INPUTS
  // ----------------------------------------------------
  const handleChange = (e) => {
    setForm({ ...form, [e.target.id]: e.target.value });
  };

  // ----------------------------------------------------
  // SUBMIT FORM
  // ----------------------------------------------------
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: "", message: "" });

    try {
      const res = await fetch(CONTACT_FORM_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok) {
        setStatus({
          type: "error",
          message: data.error || "Failed to send message.",
        });
        return;
      }

      setStatus({ type: "success", message: "Message sent successfully!" });
      setForm({ name: "", email: "", mobile: "", message: "" });
    } catch (err) {
      console.error("Submit error:", err);
      setStatus({ type: "error", message: "Something went wrong." });
    } finally {
      setLoading(false);
    }
  };

  // ----------------------------------------------------
  // LOADING UI
  // ----------------------------------------------------
  if (!info) {
    return (
      <div className="p-10 text-center text-gray-500">
        Loading contact information...
      </div>
    );
  }

  // ----------------------------------------------------
  // RENDER PAGE
  // ----------------------------------------------------
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1 mt-20">
        {/* Hero Section */}
        <section className="py-10 text-center px-2">
          <div className="container max-w-4xl mx-auto">
            <h2 className="text-2xl font-semibold mb-2">Contact Us</h2>
            <p className="mt-3 text-gray-600 text-lg">
              We're here to help! Reach out with any questions or inquiries.
            </p>
          </div>
        </section>

        {/* Contact Information */}
        <section className="py-10 px-4">
          <div className="container max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Phone */}
            <div className="bg-white border border-blue-100 rounded-xl shadow-lg p-6 text-center">
              <div className="p-4 rounded-full bg-blue-100 w-fit mx-auto mb-4">
                <Phone className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Phone</h3>
              <p className="text-gray-500 mb-2">Call us directly</p>
              <a href={`tel:${info.phone}`} className="font-medium text-lg">
                {info.phone}
              </a>

              {/* Secondary Phone */}
              {info.secondaryPhone && (
                <div className="mt-2 text-gray-700">{info.secondaryPhone}</div>
              )}
            </div>

            {/* Email */}
            <div className="bg-white border border-blue-100 rounded-xl shadow-lg p-6 text-center">
              <div className="p-4 rounded-full bg-blue-100 w-fit mx-auto mb-4">
                <Mail className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Email</h3>
              <p className="text-gray-500 mb-2">Send us an email anytime</p>
              <a href={`mailto:${info.email}`} className="font-medium text-lg">
                {info.email}
              </a>
            </div>

            {/* Address */}
            <div className="bg-white border border-blue-100 rounded-xl shadow-lg p-6 text-center">
              <div className="p-4 rounded-full bg-blue-100 w-fit mx-auto mb-4">
                <MapPin className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Address</h3>
              <address className="text-gray-700 not-italic">
                {info.address}
              </address>
            </div>
          </div>
        </section>

        {/* Business Hours */}
        <section className="py-10 px-4">
          <div className="container max-w-4xl mx-auto">
            <h2 className="text-2xl font-semibold text-center mb-6">
              Business Hours
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white border border-blue-100 rounded-xl shadow-lg p-6 flex items-center gap-4">
                <div className="p-4 rounded-full bg-blue-100">
                  <Calendar className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">Weekdays</h3>
                  <p className="text-gray-500">{info.businessDays}</p>
                </div>
              </div>

              <div className="bg-white border border-blue-100 rounded-xl shadow-lg p-6 flex items-center gap-4">
                <div className="p-4 rounded-full bg-blue-100">
                  <Clock className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">Working Time</h3>
                  <p className="text-gray-500">{info.businessHours}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Map (Optional) */}
        {info.mapUrl && (
          <section className="py-10 px-4">
            <div className="container max-w-3xl mx-auto text-center">
              <h3 className="text-2xl font-semibold mb-6">Our Map Location</h3>
              <div className="aspect-video w-full border rounded-xl overflow-hidden shadow-md">
                <iframe
                  src={info.mapUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                />
              </div>
            </div>
          </section>
        )}

        {/* Contact Form */}
        <section className="py-12 px-4">
          <div className="container max-w-3xl mx-auto">
            <div className="bg-white border border-blue-100 rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-semibold text-center mb-2">
                Send Us a Message
              </h3>
              <p className="text-center text-gray-500 mb-6">
                We will respond as soon as possible.
              </p>

              {status.message && (
                <div
                  className={`p-3 rounded-lg text-center mb-4 ${
                    status.type === "success"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {status.message}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm">Name</label>
                    <input
                      id="name"
                      value={form.name}
                      onChange={handleChange}
                      className="w-full p-3 border rounded-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm">Email</label>
                    <input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={handleChange}
                      className="w-full p-3 border rounded-lg"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm">Mobile</label>
                  <input
                    id="mobile"
                    value={form.mobile}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg"
                    required
                  />
                </div>

                <div>
                  <label className="text-sm">Message</label>
                  <textarea
                    id="message"
                    rows={5}
                    value={form.message}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg"
                    required
                  ></textarea>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full py-3 rounded-lg font-semibold ${
                    loading
                      ? "bg-blue-300 cursor-not-allowed"
                      : "bg-blue-200 text-blue-900 hover:bg-blue-600"
                  }`}
                >
                  {loading ? "Sending..." : "Send Message"}
                </button>
              </form>
            </div>
          </div>
        </section>

        {/* Social Media */}
        <section className="py-10 text-center">
          <h2 className="text-2xl font-semibold mb-4">Connect With Us</h2>

          <div className="flex justify-center gap-6">
            {info.facebook && (
              <Link href={info.facebook} target="_blank">
                <div className="p-4 bg-blue-100 rounded-full hover:bg-blue-700 hover:scale-110 transition">
                  <FaFacebook className="h-6 w-6 text-blue-900" />
                </div>
              </Link>
            )}

            {info.instagram && (
              <Link href={info.instagram} target="_blank">
                <div className="p-4 bg-blue-100 rounded-full hover:bg-pink-600 hover:scale-110 transition">
                  <FaInstagram className="h-6 w-6 text-blue-900" />
                </div>
              </Link>
            )}

            {info.twitter && (
              <Link href={info.twitter} target="_blank">
                <div className="p-4 bg-blue-100 rounded-full hover:bg-sky-500 hover:scale-110 transition">
                  <FaTwitter className="h-6 w-6 text-blue-900" />
                </div>
              </Link>
            )}

            {info.linkedin && (
              <Link href={info.linkedin} target="_blank">
                <div className="p-4 bg-blue-100 rounded-full hover:bg-blue-800 hover:scale-110 transition">
                  <FaLinkedin className="h-6 w-6 text-blue-900" />
                </div>
              </Link>
            )}

            {info.youtube && (
              <Link href={info.youtube} target="_blank">
                <div className="p-4 bg-blue-100 rounded-full hover:bg-red-600 hover:scale-110 transition">
                  <FaYoutube className="h-6 w-6 text-blue-900" />
                </div>
              </Link>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
