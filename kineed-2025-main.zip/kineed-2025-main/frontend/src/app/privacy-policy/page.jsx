import Link from "next/link"
import Address from "@/components/address"

export default function PrivacyPolicy() {
  return (
    <>
    <div className="container mx-auto px-4 py-12 max-w-4xl mt-20">
      <h1 className="text-3xl font-bold text-blue-800 mb-4">Privacy Policy</h1>

      <div className="prose prose-blue max-w-none">
        {/* <p className="text-gray-600 mb-6">Last Updated: May 2, 2025</p> */}

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Introduction</h2>
          <p>
            Grutikaagro.com ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains
            how we collect, use, disclose, and safeguard your information when you visit our website, including any
            other media form, media channel, mobile website, or mobile application related or connected to
            Grutikaagro.com (collectively, the "Site").
          </p>
          <p className="mt-4">
            Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please
            do not access the Site. We reserve the right to make changes to this Privacy Policy at any time and for any
            reason. Any changes or modifications will be effective immediately upon posting the updated Privacy Policy
            on the Site, and you waive the right to receive specific notice of each such change or modification.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Information We Collect</h2>

          <h3 className="text-xl font-medium text-blue-600 mb-3">Personal Data</h3>
          <p>
            We may collect personal information that you voluntarily provide to us when you register on the Site,
            express an interest in obtaining information about us or our products, when you participate in activities on
            the Site, or otherwise when you contact us. The personal information we collect may include:
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4">
            <li>Name and contact data (such as email address, phone number, billing and shipping address)</li>
            <li>Credentials (such as passwords and security questions)</li>
            <li>Payment data (such as credit card information and billing address)</li>
            <li>Profile data (such as username, purchase history, and preferences)</li>
          </ul>

          <h3 className="text-xl font-medium text-blue-600 mb-3">Automatically Collected Information</h3>
          <p>
            When you visit our Site, we automatically collect certain information about your device, including
            information about your web browser, IP address, time zone, and some of the cookies that are installed on
            your device. Additionally, as you browse the Site, we collect information about the individual web pages
            that you view, what websites or search terms referred you to the Site, and information about how you
            interact with the Site.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">How We Use Your Information</h2>
          <p>We may use the information we collect from you for various purposes, including to:</p>
          <ul className="list-disc pl-6 mt-2 mb-4">
            <li>Process and fulfill your orders for our aloe vera products</li>
            <li>Create and manage your account</li>
            <li>Send you order confirmations, updates, and support messages</li>
            <li>Respond to your comments, questions, and requests</li>
            <li>Send you technical notices, updates, security alerts, and administrative messages</li>
            <li>Communicate with you about products, services, offers, promotions, and events</li>
            <li>Monitor and analyze trends, usage, and activities in connection with our Site</li>
            <li>Detect, investigate, and prevent fraudulent transactions and other illegal activities</li>
            <li>Personalize your experience on our Site and deliver content relevant to your interests</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Disclosure of Your Information</h2>
          <p>
            We may share information we have collected about you in certain situations. Your information may be
            disclosed as follows:
          </p>

          <h3 className="text-xl font-medium text-blue-600 mb-3">By Law or to Protect Rights</h3>
          <p>
            If we believe the release of information about you is necessary to respond to legal process, to investigate
            or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we
            may share your information as permitted or required by any applicable law, rule, or regulation.
          </p>

          <h3 className="text-xl font-medium text-blue-600 mb-3 mt-4">Third-Party Service Providers</h3>
          <p>
            We may share your information with third parties that perform services for us or on our behalf, including
            payment processing, data analysis, email delivery, hosting services, customer service, and marketing
            assistance.
          </p>

          <h3 className="text-xl font-medium text-blue-600 mb-3 mt-4">Marketing Communications</h3>
          <p>
            With your consent, or with an opportunity for you to withdraw consent, we may share your information with
            third parties for marketing purposes.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Security of Your Information</h2>
          <p>
            We use administrative, technical, and physical security measures to help protect your personal information.
            While we have taken reasonable steps to secure the personal information you provide to us, please be aware
            that despite our efforts, no security measures are perfect or impenetrable, and no method of data
            transmission can be guaranteed against any interception or other type of misuse.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Your Rights Regarding Your Information</h2>
          <p>Depending on your location, you may have certain rights regarding your personal information, including:</p>
          <ul className="list-disc pl-6 mt-2 mb-4">
            <li>The right to access personal information we hold about you</li>
            <li>The right to request that we correct any inaccurate personal information</li>
            <li>The right to request that we delete your personal information</li>
            <li>The right to opt-out of marketing communications</li>
          </ul>
          <p>To exercise these rights, please contact us using the contact information provided below.</p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">Contact Us</h2>
          <p>If you have questions or comments about this Privacy Policy, please contact us at:</p>
          <Address />
        </section>
      </div>

      <div className="mt-12 pt-6 border-t border-gray-200">
        <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
          ← Back to Home
        </Link>
      </div>
    </div>
    </>
  )
}
