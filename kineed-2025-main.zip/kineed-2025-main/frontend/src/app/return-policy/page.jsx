import Link from "next/link"
import Address from "@/components/address"


export default function ReturnPolicy() {
  return (
    <>

      <div className="container mx-auto px-4 py-12 max-w-4xl mt-20">
        <h1 className="text-3xl font-bold text-blue-800 mb-4">
          Returns, Refunds, Cancellations, Exchanges & Shipping Policy
        </h1>

        <div className="prose prose-blue max-w-none">
          {/* <p className="text-gray-600 mb-6">Last Updated: May 13, 2025</p> */}

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">What We Will Do Together</h2>
            <ol className="list-decimal pl-6 space-y-2">
              <li>
                Raise a return or replacement request within <strong>7 days</strong> from delivery if you’ve received
                wrong or expired product(s). Use the contact form or Chat option on our website.
              </li>
              <li>
                For damaged or missing items, raise a request within <strong>2 days</strong> from the delivery date.
              </li>
              <li>We’ll review your request within <strong>2 working days</strong>.</li>
              <li>
                If approved, we will arrange a pickup via our courier partner. If pickup is unavailable at your
                location, self-ship the item and we will reimburse the courier charges via PhonePe.
              </li>
              <li>
                After receiving and verifying the product(s), we will process a replacement or refund depending on
                stock availability.
              </li>
              <li>
                Replacement orders will usually be delivered within 5 to 8 business days.
              </li>
            </ol>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">
              Conditions Eligible for Return/Replacement
            </h2>
            <ul className="list-disc pl-6">
              <li>Wrong product delivered</li>
              <li>Expired product delivered</li>
              <li>Damaged product (physical damage or tampered packaging)</li>
              <li>Incomplete order with missing products</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">
              Conditions Where Return/Replacement Is Not Accepted
            </h2>
            <ul className="list-disc pl-6">
              <li>Opened, used, or altered products</li>
              <li>Missing original packaging, labels, or mono cartons</li>
              <li>Request raised after 7 days of delivery</li>
              <li>Damage or missing report after 2 days of delivery</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">How Are Returns Processed?</h2>
            <p>
              Once a return is requested, our courier partner will arrange pickup within 5–7 business days. After the
              product is returned to our warehouse and passes a quality check, we initiate a refund or replacement.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Order Cancellations</h2>
            <p>
              Orders can be cancelled from the <strong>My Account</strong> section using the “Cancel” button until the
              order status is marked as <strong>“Ready to Ship.”</strong>
            </p>
            <p className="mt-4">
              Ghrutika Agroceuticals reserves the right to cancel any order without prior notice. Order verification may
              be done via call or email.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Refunds</h2>
            <ul className="list-disc pl-6">
              <li>
                For prepaid orders, refunds will be credited to the original payment method within 7 business days.
              </li>
              <li>
                For Cash on Delivery orders, customers must provide bank details to receive the refund.
              </li>
              <li>
                In case of returns, refunds are initiated after the product reaches our warehouse and passes the
                quality check. The entire process may take up to 2 weeks.
              </li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Partial Returns</h2>
            <p>
              Yes, you can return part of your order if the products meet the return conditions and are returned within
              7 days of delivery.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Shipping Policy</h2>
            <ul className="list-disc pl-6">
              <li>We deliver all over India via trusted logistics partners.</li>
              <li>Orders are shipped within 1–2 business days from order placement.</li>
              <li>
                Delivery typically takes 3–7 business days depending on your location and courier availability.
              </li>
              <li>Tracking details are sent via SMS/email once the order is dispatched.</li>
              <li>Free shipping may apply to select items or above a certain cart value.</li>
              <li>
                In case of unforeseen delays (weather, remote areas, etc.), we will inform you at the earliest.
              </li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Need Help?</h2>
            <p>Contact us if you have any questions about your order or return:</p>
            <Address />
          </section>
        </div>

        <div className="mt-12 pt-6 border-t border-gray-200">
          <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
            ← Back to Home
          </Link>
        </div>
      </div>
    </>
  )
}
