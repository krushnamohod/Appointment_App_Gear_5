"use client";
import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import ProductCard from "@/components/Productcard";
import Loading from "@/utils/loading";

const CategoryProducts = () => {
  const { category } = useParams();
  const decodedCategory = decodeURIComponent(category);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await fetch("https://api.kineed.in/api/products");
        const data = await res.json();

        if (data.status === "success") {
          const filtered = data.data.products.filter(
            (p) => p.category === decodedCategory
          );
          setProducts(filtered);
        }
      } catch (err) {
        console.error("Failed to fetch products:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, [decodedCategory]);

  if (loading) return <Loading />;

  return (
    <section className="py-10 mt-15">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-xl font-medium mb-6">{decodedCategory}</h1>

        {products.length === 0 ? (
          <p>No products found.</p>
        ) : (
          <div className="flex flex-wrap justify-center gap-6">

            {products.map((product) => (
              <div key={product.id} className="min-w-[180px] max-w-[180px]">
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default CategoryProducts;
