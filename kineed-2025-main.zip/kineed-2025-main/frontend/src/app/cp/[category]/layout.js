// app/category/[category]/layout.js
import React from "react";
import { products } from "@/lib/products";

export default function CategoryLayout({ children }) {
  return <>{children}</>;
}

// Dynamic SEO Metadata for Category Page
export async function generateMetadata({ params }) {
  const category = decodeURIComponent(params.category);

  // Get products in this category
  const categoryProducts = products.filter((p) => p.category === category);

  // Title: category name + number of products
  const title = `Best ${category} Products | Explore premium-quality kitchen appliances at KINEED. Shop durable, efficient, and modern products with fast delivery.`;

  // Description: basic description including product count
  const description =
    categoryProducts.length > 0
      ? `Explore ${categoryProducts.length} amazing products in the ${category} category. Find the best deals and offers today!`
      : `Currently, there are no products in the ${category} category. Check back later for new arrivals.`;

  // Optional: SEO keywords based on products
  const keywords =
    categoryProducts.length > 0
      ? categoryProducts.map((p) => p.name).join(", ")
      : category;

  return {
    title,
    description,
    keywords,
    openGraph: {
      title,
      description,
      url: `/category/${encodeURIComponent(category)}`,
      siteName: "Your Store Name",
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
    },
  };
}
