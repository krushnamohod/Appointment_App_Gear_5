"use client";
import { useState } from "react";
import Header from "@/components/Header";
import Homepage from "@/components/Home";
import ProductsSection from "@/components/Products";
import Categories from "@/components/Categories";
import ReviewsSection from "@/components/ReviewsSection";

export default function Home() {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (product, qty) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        if (qty === 0) {
          // Remove item if quantity is 0
          return prev.filter((item) => item.id !== product.id);
        }
        // Update quantity
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: qty } : item
        );
      } else if (qty > 0) {
        return [...prev, { ...product, quantity: qty }];
      }
      return prev;
    });
  };

  const removeFromCart = (productId) => {
  setCartItems((prev) => prev.filter((item) => item.id !== productId));
};

  return (
    <>
      <Header cartItems={cartItems} addToCart={addToCart} removeFromCart={removeFromCart} />
      <Homepage />
      <Categories />
      <ProductsSection addToCart={addToCart} cartItems={cartItems} />
      <ReviewsSection />
    </>
  );
}
