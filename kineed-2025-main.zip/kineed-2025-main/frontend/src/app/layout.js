import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer"
import Back from "@/components/BackToTop"
import SocialFloatingButton from "@/components/SocialFloatingButton";


const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "KINEED Kitchen Appliances",
  icons: {
    icon: "/KINEED Logo.jpg", // path to your icon in the public folder
  },
  description: "Your Trusted Partner for Modern Kitchen Solutions",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Header />
        {children}
        <Footer />
        <SocialFloatingButton />
        <Back />
      </body>
    </html>
  );
}
