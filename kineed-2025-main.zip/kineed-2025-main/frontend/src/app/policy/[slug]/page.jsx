import { slugify } from "@/utils/slugify";

async function getPolicies() {
  const res = await fetch("https://api.kineed.in/api/policy", {
    cache: "no-store",
  });
  return res.json();
}

export default async function PolicyPage({ params }) {
  const { slug } = params;
  const policies = await getPolicies();

  const policy = policies.find((p) => slugify(p.name) === slug);

  if (!policy) {
    return (
      <div className="p-10">
        <h1 className="text-2xl font-semibold">Policy Not Found</h1>
      </div>
    );
  }

  return (
    <div className="max-w-3xl min-h-screen mx-auto px-6 py-20 leading-relaxed">
      {/* Title */}
      <h1 className="text-4xl font-bold text-blue-900 mb-4">
        {policy.name}
      </h1>

      {/* Subtitle */}
      {policy.subtitle && (
        <p className="text-gray-700 text-lg mb-10">{policy.subtitle}</p>
      )}

      {/* Description Renderer */}
      <div className="space-y-4">
        {policy.description.map((item, idx) => {
          // Heading
          if (item.heading) {
            return (
              <h2
                key={idx}
                className="text-2xl font-bold text-blue-900 mt-8 mb-2"
              >
                {item.heading}
              </h2>
            );
          }

          // Subheading
          if (item.subheading) {
            return (
              <h3
                key={idx}
                className="text-xl font-semibold text-blue-700 mt-6 mb-2"
              >
                {item.subheading}
              </h3>
            );
          }

          // Content Paragraph
          if (item.content) {
            return (
              <p
                key={idx}
                className="text-gray-800 text-base whitespace-pre-line mb-3"
              >
                {item.content}
              </p>
            );
          }

          // Bullet Points
          if (item.point) {
            return (
              <ul
                key={idx}
                className="list-disc ml-6 text-gray-800 text-base space-y-1"
              >
                <li>{item.point}</li>
              </ul>
            );
          }

          return null;
        })}
      </div>
    </div>
  );
}
