"use client";
import React, { useRef, useEffect, useState } from "react";
import Productcard from "@/components/Productcard";
import { getDiscountPercentage } from "@/utils/getDiscountPercentage";
import Loading from "@/utils/loading";
import { ChevronLeft, ChevronRight } from "lucide-react";

export function RelatedProducts({
  currentProductId,
  currentCategory,
  onViewDetails,
}) {
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const scrollRef = useRef(null); // Single scroll container ref

  useEffect(() => {
    async function fetchRelatedProducts() {
      try {
        const res = await fetch("https://api.kineed.in/api/products");
        const data = await res.json();

        if (data.status === "success") {
          const filtered = data.data.products.filter(
            (p) => p.category === currentCategory && p.id !== currentProductId
          );
          setRelatedProducts(filtered);
        }
      } catch (err) {
        console.error("Failed to fetch related products:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchRelatedProducts();
  }, [currentProductId, currentCategory]);

  const handleProductClick = (id) => {
    onViewDetails(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const scroll = (direction) => {
    if (!scrollRef.current) return;

    const amount = 250; // Scroll size
    scrollRef.current.scrollBy({
      left: direction === "left" ? -amount : amount,
      behavior: "smooth",
    });
  };

  if (loading) return <Loading />;
  if (!relatedProducts.length) return null;

  return (
    <div className="mt-16">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">
        Similar Products
      </h2>

      <div className="relative w-full">
        {/* LEFT BUTTON */}
        {relatedProducts.length > 3 && (
          <button
            onClick={() => scroll("left")}
            className="absolute left-0 top-1/2 -translate-y-1/2 bg-white border-2 border-blue-400 shadow-md rounded-full p-2 z-10 hover:bg-gray-100"
          >
            <ChevronLeft className="h-5 w-5 text-gray-700" />
          </button>
        )}

        {/* SCROLLABLE ROW */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth px-10 py-4"
        >
          {relatedProducts.map((product) => (
            <div
              key={product.id}
              className="min-w-[180px] max-w-[180px]"
            >
              <Productcard
                product={product}
                onClick={() => handleProductClick(product.id)}
                getDiscountPercentage={getDiscountPercentage}
              />
            </div>
          ))}
        </div>

        {/* RIGHT BUTTON */}
        {relatedProducts.length > 3 && (
          <button
            onClick={() => scroll("right")}
            className="absolute right-0 top-1/2 -translate-y-1/2 bg-white border-blue-400 border-2 shadow-md rounded-full p-2 z-10 hover:bg-gray-100"
          >
            <ChevronRight className="h-5 w-5 text-gray-700" />
          </button>
        )}
      </div>
    </div>
  );
}
