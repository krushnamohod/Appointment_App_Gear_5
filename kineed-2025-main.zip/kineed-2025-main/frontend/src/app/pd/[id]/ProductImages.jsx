"use client";
import React, { useState } from "react";
import Image from "next/image";

export default function ProductImages({ product, selectedImage, onSelectImage }) {
  const [zoomed, setZoomed] = useState(false);
  const [position, setPosition] = useState({ x: 50, y: 50 });

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setPosition({ x, y });
  };

  // Fallback image logic
  const hasImages = product.images && product.images.length > 0;
  const mainImage = hasImages
    ? product.images[selectedImage]
    : product.mainImage || "/placeholder.svg";

  return (
    <div className="space-y-4">
      {/* Main Image */}
      <div
        className="relative h-80 md:h-96 rounded-lg bg-white overflow-hidden"
        onMouseEnter={() => setZoomed(true)}
        onMouseLeave={() => setZoomed(false)}
        onMouseMove={handleMouseMove}
      >
        <Image
          src={mainImage}
          alt={product.name}
          fill
          className={`object-contain p-4 transition-transform duration-200 ${
            zoomed ? "scale-250" : "scale-100"
          }`}
          style={{ transformOrigin: `${position.x}% ${position.y}%` }}
          priority
        />
      </div>

      {/* Thumbnails — show only if images exist */}
      {hasImages && (
        <div className="flex justify-center space-x-3 overflow-x-auto py-2 px-2">
          {product.images.map((image, index) => (
            <button
              key={index}
              className={`relative w-20 h-20 rounded-md overflow-hidden flex-shrink-0 ${
                selectedImage === index
                  ? "ring-2 ring-blue-700 ring-offset-2"
                  : "border border-gray-200 hover:ring-1 hover:ring-gray-300"
              }`}
              onClick={() => onSelectImage(index)}
            >
              <Image
                src={image || "/placeholder.svg"}
                alt={`${product.name} thumbnail ${index + 1}`}
                fill
                className="object-contain"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
