"use client";
import React, { useState, useEffect } from "react";
import { Check, Truck, Shield, RotateCcw } from "lucide-react";

import StarRating from "@/utils/StarRating";
import { getDiscountPercentage } from "@/utils/getDiscountPercentage";
import QuantitySelector from "@/utils/QuantitySelector";

export default function ProductInfo({
  product,
  selectedColor,
  setSelectedColor,
  quantity,
  addToCart,
  setQuantity,
}) {
  const [qty, setQty] = useState(0);
  const [info, setInfo] = useState(null);

  // Load cart item quantity from localStorage by ID
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedCart = localStorage.getItem("cartItems");

      if (storedCart) {
        const parsed = JSON.parse(storedCart);
        const item = parsed.find((i) => i.id === product.id); // FIX → ID ONLY

        if (item) setQty(item.quantity);
        else setQty(0);
      }
    }

    const handleCartUpdated = () => {
      const storedCart = localStorage.getItem("cartItems");

      if (storedCart) {
        const parsed = JSON.parse(storedCart);
        const item = parsed.find((i) => i.id === product.id); // FIX → ID ONLY

        if (item) setQty(item.quantity);
        else setQty(0);
      } else {
        setQty(0);
      }
    };

    window.addEventListener("cartUpdated", handleCartUpdated);
    return () => window.removeEventListener("cartUpdated", handleCartUpdated);
  }, [product.id]); // FIX → use product.id

  // Fetch contact info
  const CONTACT_INFO_URL = "https://api.kineed.in/api/contact";

  useEffect(() => {
    const fetchContactInfo = async () => {
      try {
        const res = await fetch(CONTACT_INFO_URL);
        const data = await res.json();
        setInfo(data?.data?.contactInfo);
      } catch (err) {
        console.error("Failed to load contact info:", err);
      }
    };
    fetchContactInfo();
  }, []);

  const updateCartInLocalStorage = (product, quantity) => {
    if (typeof window === "undefined") return;

    let storedCart = localStorage.getItem("cartItems");
    let cart = storedCart ? JSON.parse(storedCart) : [];

    const index = cart.findIndex((i) => i.id === product.id); // FIX → ID ONLY

    if (index !== -1) {
      if (quantity > 0) cart[index].quantity = quantity;
      else cart.splice(index, 1);
    } else if (quantity > 0) {
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        originalPrice: product.originalPrice,
        image: product.images?.[0] || "",
        quantity,
      });
    }

    localStorage.setItem("cartItems", JSON.stringify(cart));
    window.dispatchEvent(new Event("cartUpdated"));
  };

  const handleIncrease = (e) => {
    e.stopPropagation();
    const newQty = qty + 1;
    setQty(newQty);
    updateCartInLocalStorage(product, newQty);
    if (addToCart) addToCart(product, newQty);
  };

  const handleDecrease = (e) => {
    e.stopPropagation();
    const newQty = qty - 1;
    setQty(newQty);
    updateCartInLocalStorage(product, newQty);
    if (addToCart) addToCart(product, newQty);
  };

  const handleAdd = (e) => {
    e.stopPropagation();
    setQty(1);
    updateCartInLocalStorage(product, 1);
    if (addToCart) addToCart(product, 1);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">{product.name}</h1>
        <div className="flex items-center mt-2">
          <StarRating rating={product.rating} />
        </div>
      </div>

      {/* Price + Quantity */}
      <div className="flex items-center space-x-3">
        <span className="text-xl font-bold">₹{product.price.toFixed(2)}</span>
        <span className="text-gray-400 line-through text-sm">
          ₹{product.originalPrice.toFixed(2)}
        </span>
        <span className="bg-green-200 text-green-900 px-2 py-1 rounded text-sm font-semibold">
          {getDiscountPercentage(product.originalPrice, product.price)}% OFF
        </span>

        <QuantitySelector
          quantity={qty}
          onIncrease={handleIncrease}
          onDecrease={handleDecrease}
          onAdd={handleAdd}
        />
      </div>

      {/* Stock Status */}
      <div className="flex items-center">
        {product.inStock ? (
          <div className="flex items-center space-x-2 text-green-600">
            <Check className="h-5 w-5" />
            <span className="font-medium">In Stock</span>
          </div>
        ) : (
          <span className="text-red-500 font-medium">Out of Stock</span>
        )}
      </div>

      <p className="text-gray-600 whitespace-pre-line">{product.description}</p>

      {info && info.whatsapp && (
        <a
          href={`https://wa.me/91${info.whatsapp}?text=Hello! I'm interested in "${product.name}" (Price: ${product.price}).`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 bg-green-200 hover:bg-green-300 text-green-900 font-semibold px-4 py-2 rounded-lg transition-colors"
        >
          WhatsApp Enquiry
        </a>
      )}

      {/* Badges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
        <div className="flex items-center space-x-2 text-gray-600">
          <Truck className="h-5 w-5" />
          <span className="text-sm">Free shipping over ₹999</span>
        </div>
        <div className="flex items-center space-x-2 text-gray-600">
          <Shield className="h-5 w-5" />
          <span className="text-sm">2-Year Warranty</span>
        </div>
        <div className="flex items-center space-x-2 text-gray-600">
          <RotateCcw className="h-5 w-5" />
          <span className="text-sm">30-Day Returns</span>
        </div>
      </div>
    </div>
  );
}
