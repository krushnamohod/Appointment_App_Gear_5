"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useRouter } from "next/navigation";
import ProductImages from "./ProductImages";
import ProductInfo from "./ProductInfo";
import { ProductTabs } from "./ProductTabs";
import { RelatedProducts } from "./RelatedProducts";
import Loading from "@/utils/loading";
import ProductNotFound from "@/utils/ProductNotFound";
import { slugify } from "@/utils/slugify";

function ProductContent({ slug }) {
  const router = useRouter();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState("");
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (!slug) return;

    async function fetchProduct() {
      try {
        const res = await fetch("https://api.kineed.in/api/products");
        const data = await res.json();

        if (data.status === "success") {
          const found = data.data.products.find(
            (p) => slugify(p.name) === slug
          );

          if (found) {
            setProduct(found);
            setSelectedColor(found.colors?.[0] || "");
          }
        }
      } catch (err) {
        console.error("Failed to fetch product:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchProduct();
  }, [slug]);

  if (loading) return <Loading />;
  if (!product)
    return <ProductNotFound onBackToProducts={() => router.push("/")} />;

  return (
    <div className="min-h-screen mt-20 flex flex-col bg-gray-50">
      <main className="flex-1 py-12 px-4 md:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            <ProductImages
              product={product}
              selectedImage={selectedImage}
              onSelectImage={setSelectedImage}
            />
            <ProductInfo
              product={product}
              selectedColor={selectedColor}
              setSelectedColor={setSelectedColor}
              quantity={quantity}
              setQuantity={setQuantity}
            />
          </div>

          <ProductTabs product={product} />

          <RelatedProducts
            currentProductId={product.id}
            currentCategory={product.category}
            onViewDetails={(id, name) =>
              router.push(`/product-details/${slugify(name)}`)
            }
          />
        </div>
      </main>
    </div>
  );
}

export default function Page({ params }) {
  const resolvedParams = React.use(params); // REQUIRED in Next.js 15+
  const slug = resolvedParams.id;

  return (
    <Suspense fallback={<Loading />}>
      <ProductContent slug={slug} />
    </Suspense>
  );
}
