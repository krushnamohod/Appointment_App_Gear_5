"use client";
import { products } from "@/lib/products";
import React, { useState, useEffect, Suspense } from "react";

import { Check, Truck, Shield, RotateCcw, Minus, Plus } from "lucide-react";

export function ProductTabs({ product }) {
  const [activeTab, setActiveTab] = useState("features");

  return (
    <div className="mt-12">
      <div className="flex border-b border-gray-300">
        <button
          className={`px-4 py-2 font-semibold ${
            activeTab === "features"
              ? "border-b-2 border-blue-500 text-blue-500"
              : "text-gray-600"
          }`}
          onClick={() => setActiveTab("features")}
        >
          Highlights
        </button>

        <button
          className={`px-4 py-2 font-semibold ${
            activeTab === "specifications"
              ? "border-b-2 border-blue-500 text-blue-500"
              : "text-gray-600"
          }`}
          onClick={() => setActiveTab("specifications")}
        >
          Product Details
        </button>
        <button
          className={`px-4 py-2 font-semibold ${
            activeTab === "reviews"
              ? "border-b-2 border-blue-500 text-blue-500"
              : "text-gray-600"
          }`}
          onClick={() => setActiveTab("reviews")}
        >
          Reviews
        </button>
      </div>

      <div className="mt-4">
        {activeTab === "features" && (
          <ul className="space-y-2">
            {product.features.map((feature, index) => (
              <li key={index} className="flex items-start space-x-2">
                <Check className="h-5 w-5 text-blue-500 mt-1" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        )}

        {activeTab === "specifications" && (
          <div className="space-y-2">
            {product.specifications.map((spec, index) => {
              // If backend returns string: "Label / Value"
              const [label, value] = spec.split("/").map((x) => x.trim());

              return (
                <div
                  key={index}
                  className="grid grid-cols-3 py-1 border-b border-gray-200"
                >
                  <div className="font-medium">{label}</div>
                  <div className="col-span-2">{value}</div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === "reviews" && (
          <div className="text-center py-8 text-gray-600">
            <p>No reviews yet. Be the first to review this product!</p>
          </div>
        )}
      </div>
    </div>
  );
}
