import { slugify } from "@/utils/slugify";

export default function ProductDetailsLayout({ children }) {
  return <>{children}</>;
}

export async function generateMetadata({ params }) {
  const resolvedParams = await params; // REQUIRED in Next.js 15+
  const slug = resolvedParams.id;

  // Fetch product list from your API
  const res = await fetch("https://api.kineed.in/api/products", {
    next: { revalidate: 0 }, // No cache – always live
  });

  const data = await res.json();

  if (!data?.status || !data?.data?.products) {
    return {
      title: "Products | KINEED Kitchen Appliances",
      description: "Your trusted partner for modern kitchen solutions.",
    };
  }

  // Find correct product
  const product = data.data.products.find(
    (p) => slugify(p.name) === slug
  );

  if (!product) {
    return {
      title: "Product Not Found | KINEED Kitchen Appliances",
      description: "This product does not exist on KINEED Kitchen Appliances.",
      robots: "noindex, nofollow",
    };
  }

  // PRODUCT IMAGE HANDLING
  const mainImage = product.mainImage || product.images?.[0] || "/default-product.jpg";

  const absoluteImage = mainImage.startsWith("http")
    ? mainImage
    : `https://kineed.in${mainImage}`;

  const url = `https://kineed.in/product-details/${slug}`;

  const priceText = product.price ? `at just ₹${product.price}` : "";

  // FINAL TITLE AND DESCRIPTION FOR SEO
  const title = product
    ? `${product.name} ${priceText} | Buy Online at KINEED Kitchen Appliances`
    : "Product Not Found | KINEED Kitchen Appliances";

  const description = product
    ? `Buy ${product.name} ${priceText} from KINEED Kitchen Appliances. ${
        product.description?.trim() ||
        "Experience premium quality, long-lasting performance, and modern features for your kitchen."
      }`
    : "Explore premium-quality kitchen appliances at KINEED. Shop durable, efficient, and modern products with fast delivery.";

  // JSON-LD Product Schema
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    image: absoluteImage,
    description: product.description || description,
    brand: {
      "@type": "Brand",
      name: product.brand || "KINEED Kitchen Appliances",
    },
    offers: {
      "@type": "Offer",
      priceCurrency: "INR",
      price: product.price || "0",
      availability: "https://schema.org/InStock",
      url: url,
    },
  };

  return {
    title,
    description,

    keywords: [
      product.name,
      `buy ${product.name} online`,
      `${product.name} price`,
      product.category,
      product.brand,
      "KINEED Kitchen Appliances",
      "kitchen appliances",
      "modern kitchen products",
    ].join(", "),

    alternates: { canonical: url },

    openGraph: {
      title,
      description,
      url,
      type: "website",
      images: [{ url: absoluteImage, width: 800, height: 600 }],
    },

    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [absoluteImage],
    },

    icons: {
      icon: absoluteImage, // PRODUCT IMAGE AS FAVICON
      shortcut: absoluteImage,
      apple: absoluteImage,
    },

    robots: "index, follow",

    // JSON-LD injection
    other: {
      "application/ld+json": JSON.stringify(jsonLd),
    },
  };
}
