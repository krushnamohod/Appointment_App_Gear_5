"use client";

import { useState } from "react";

export default function SupportPage() {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    message: "",
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const API_URL = "https://api.kineed.in/api/enquiries";

  const handleChange = (e) => {
    const { id, value } = e.target;
    setForm((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    if (!form.name || !form.phone || !form.email || !form.message) {
      setError("Please fill all required fields.");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          phone: form.phone,
          email: form.email,
          subject: "Customer Support Contact",
          message: form.message,
          address: form.address,
        }),
      });

      const data = await res.json();

      if (res.ok && data.status === "success") {
        setSuccess("Your enquiry has been submitted successfully!");
        setForm({
          name: "",
          phone: "",
          email: "",
          address: "",
          message: "",
        });
      } else {
        setError("Failed to submit enquiry. Please try again.");
      }
    } catch (err) {
      console.error(err);
      setError("Something went wrong.");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-white">
      <main className="flex-1 mt-10">
        <section className="py-10 px-2">
          <div className="container max-w-3xl mx-auto mt-10">
            <div className="bg-white rounded-2xl shadow-lg border border-blue-100 p-6">
              <h3 className="text-2xl font-semibold text-center">
                Contact Our Support Team
              </h3>
              <p className="text-center text-gray-800 mb-8">
                Fill out the form below to get in touch
              </p>

              {success && (
                <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-lg">
                  {success}
                </div>
              )}

              {error && (
                <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg">
                  {error}
                </div>
              )}

              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="flex flex-col">
                    <label className="text-sm font-medium text-gray-700">
                      Your Name *
                    </label>
                    <input
                      id="name"
                      type="text"
                      value={form.name}
                      onChange={handleChange}
                      className="mt-1 p-3 border border-gray-300 rounded-lg 
                        focus:ring-1 focus:ring-blue-600 focus:outline-none"
                      placeholder="Your name"
                      required
                    />
                  </div>

                  <div className="flex flex-col">
                    <label className="text-sm font-medium text-gray-700">
                      Mobile Number *
                    </label>
                    <input
                      id="phone"
                      type="text"
                      maxLength={10}
                      value={form.phone}
                      onChange={handleChange}
                      className="mt-1 p-3 border border-gray-300 rounded-lg
                        focus:ring-1 focus:ring-blue-600 focus:outline-none"
                      placeholder="Your mobile number"
                      required
                    />
                  </div>
                </div>

                <div className="flex flex-col">
                  <label className="text-sm font-medium text-gray-700">
                    Email ID *
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    className="mt-1 p-3 border border-gray-300 rounded-lg 
                      focus:ring-1 focus:ring-blue-600 focus:outline-none"
                    placeholder="Your email"
                    required
                  />
                </div>

                <div className="flex flex-col">
                  <label className="text-sm font-medium text-gray-700">
                    Your Address
                  </label>
                  <input
                    id="address"
                    type="text"
                    value={form.address}
                    onChange={handleChange}
                    className="mt-1 p-3 border border-gray-300 rounded-lg 
                      focus:ring-1 focus:ring-blue-600 focus:outline-none"
                    placeholder="Write your complete address"
                  />
                </div>

                <div className="flex flex-col">
                  <label className="text-sm font-medium text-gray-700">
                    Your Message *
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    value={form.message}
                    onChange={handleChange}
                    className="mt-1 p-3 border border-gray-300 rounded-lg 
                      focus:ring-1 focus:ring-blue-600 focus:outline-none"
                    placeholder="Please share your issue or enquiry"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-lg bg-blue-200 text-blue-900 font-semibold 
                    hover:bg-blue-700 disabled:opacity-60 disabled:cursor-not-allowed
                    transition duration-300"
                >
                  {loading ? "Sending..." : "Send Message"}
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
