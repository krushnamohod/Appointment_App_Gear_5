"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { ShoppingCart, CreditCard, Home } from "lucide-react";

export default function CheckoutPage() {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState("online");
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    address: "",
    pincode: "",
    city: "",
    state: "",
  });

  useEffect(() => {
    const saved = localStorage.getItem("checkoutCart");
    if (saved) {
      setCartItems(JSON.parse(saved));
    }
    setLoading(false);
  }, []);

  const totalAmount = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const updateForm = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const validateForm = () => {
    return (
      form.fullName.trim() &&
      form.phone.trim().length === 10 &&
      form.address.trim() &&
      form.pincode.trim().length === 6 &&
      form.city.trim() &&
      form.state.trim()
    );
  };

  // ======================
  // Phone pe Payment Handler
  // ======================
  const handlePhonePePayment = async () => {
    try {
      const payload = {
        customerName: form.fullName,
        customerEmail:
          form.fullName.split(" ").join("").toLowerCase() + "@example.com", // or get email separately
        customerPhone: form.phone,
        items: cartItems,
        totalAmount: totalAmount,
      };

      const res = await fetch("https://api.kineed.in/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!data.ok) {
        alert("Failed to create order: " + data.error);
        return;
      }

      // Redirect user to PhonePe checkout (IMPORTANT)
      window.location.href = data.checkoutUrl;
    } catch (err) {
      console.error(err);
      alert("Payment failed to initiate.");
    }
  };

  const handlePlaceOrder = () => {
    if (!validateForm()) {
      alert("Please fill all details correctly.");
      return;
    }

    if (paymentMethod === "online") {
      handlePhonePePayment();
    } else {
      alert("Order placed with Cash on Delivery (COD)");
    }
  };

  if (loading)
    return (
      <div className="p-6 text-center text-gray-600 text-lg">
        Loading checkout...
      </div>
    );

  return (
    <div className="min-h-screen bg-gray-100 mt-30 py-10 px-4 md:px-10">
      <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-2xl overflow-hidden">
        <div className="md:flex">
          {/* LEFT SIDE — FORM */}
          <div className="w-full md:w-2/3 p-6 md:p-10 border-r border-gray-200">
            <h2 className="text-2xl font-semibold mb-6">Checkout Details</h2>

            {/* Contact */}
            <div className="grid md:grid-cols-2 gap-5">
              <div>
                <label className="text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <input
                  type="text"
                  value={form.fullName}
                  onChange={(e) => updateForm("fullName", e.target.value)}
                  className="input"
                  placeholder="Your name"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">
                  Phone
                </label>
                <input
                  type="number"
                  value={form.phone}
                  onChange={(e) => updateForm("phone", e.target.value)}
                  className="input"
                  placeholder="10-digit number"
                />
              </div>
            </div>

            {/* Address */}
            <div className="mt-5">
              <label className="text-sm font-medium text-gray-700">
                Address
              </label>
              <textarea
                value={form.address}
                onChange={(e) => updateForm("address", e.target.value)}
                className="input h-24 resize-none"
                placeholder="Street, locality..."
              />
            </div>

            <div className="grid md:grid-cols-3 gap-5 mt-5">
              <div>
                <label className="text-sm font-medium text-gray-700">
                  Pincode
                </label>
                <input
                  type="number"
                  value={form.pincode}
                  onChange={(e) => updateForm("pincode", e.target.value)}
                  className="input"
                  placeholder="6-digit pincode"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">
                  City
                </label>
                <input
                  type="text"
                  value={form.city}
                  onChange={(e) => updateForm("city", e.target.value)}
                  className="input"
                  placeholder="City"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">
                  State
                </label>
                <input
                  type="text"
                  value={form.state}
                  onChange={(e) => updateForm("state", e.target.value)}
                  className="input"
                  placeholder="State"
                />
              </div>
            </div>

            {/* Payment Method */}
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-3">Payment Method</h3>
              <div className="flex gap-4">
                {/* Online */}
                <div
                  onClick={() => setPaymentMethod("online")}
                  className={`flex items-center gap-3 border rounded-xl px-4 py-3 cursor-pointer w-1/2 ${
                    paymentMethod === "online"
                      ? "border-blue-600 bg-blue-50"
                      : "border-gray-300"
                  }`}
                >
                  <CreditCard />
                  <span className="font-medium text-gray-700">
                    Online Payment
                  </span>
                </div>

                {/* COD */}
                <div
                  onClick={() => setPaymentMethod("cod")}
                  className={`flex items-center gap-3 border rounded-xl px-4 py-3 cursor-pointer w-1/2 ${
                    paymentMethod === "cod"
                      ? "border-green-600 bg-green-50"
                      : "border-gray-300"
                  }`}
                >
                  <Home />
                  <span className="font-medium text-gray-700">
                    Cash on Delivery
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT SIDE — ORDER SUMMARY */}
          <div className="w-full md:w-1/3 p-6 md:p-8 bg-gray-50">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between bg-white p-3 rounded-lg shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <Image
                      src={item.mainImage || "/placeholder.jpg"}
                      width={60}
                      height={60}
                      alt={item.name}
                      className="rounded-md object-cover"
                    />
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-gray-600">
                        Qty: {item.quantity}
                      </p>
                    </div>
                  </div>
                  <p className="font-semibold">₹{item.price * item.quantity}</p>
                </div>
              ))}
            </div>

            <div className="border-t mt-6 pt-4">
              <div className="flex justify-between text-lg font-semibold mb-4">
                <span>Total</span>
                <span>₹{totalAmount}</span>
              </div>

              <button
                onClick={handlePlaceOrder}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl shadow-md flex items-center justify-center gap-2"
              >
                <ShoppingCart size={22} />
                {paymentMethod === "cod" ? "Place COD Order" : "Pay Securely"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .input {
          width: 100%;
          margin-top: 4px;
          padding: 10px 14px;
          border: 1px solid #d1d5db;
          border-radius: 8px;
          outline: none;
          transition: border 0.2s;
        }
        .input:focus {
          border-color: #2563eb;
        }
      `}</style>
    </div>
  );
}
